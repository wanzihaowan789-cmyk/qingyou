#!/usr/bin/env python3
"""青柚学伴题库审计：结构、答案二次计算、选择题选项一致性。

用法：
  python3 audit-items.py           # 完整报告
  python3 audit-items.py --quiet   # 只输出摘要与问题

退出码：0 通过；1 发现结构错误或数值答案不一致。
"""

import json
import math
import os
import re
import sys
from fractions import Fraction

from math_equiv import values_equal as equiv_values_equal

BASE = os.path.dirname(os.path.abspath(__file__))
SUB = {"₂": 2, "₃": 3, "₄": 4, "₅": 5, "₁₀": 10}


def load_data():
    text = open(os.path.join(BASE, "data.js"), encoding="utf-8").read()
    return json.loads(text[text.index("{"):text.rindex("}") + 1])


def norm(value):
    text = str(value).strip()
    return text.replace("−", "-").replace(" ", "").replace("\u00a0", "")


def value_of_answer(item):
    if item.get("type") == "choice":
        letters = str(item.get("answer", "")).upper()
        options = item.get("options") or []
        if len(letters) == 1:
            index = ord(letters) - ord("A")
            if 0 <= index < len(options):
                return options[index]
    return item.get("answer")


def values_equal(expected, actual):
    """数值等价（1/2 = 0.5）或写法等价（(1,3] = 1<x≤3），规则与 app.js 同源。"""
    return equiv_values_equal(expected, actual)


def frac_str(num, den):
    if den == 0:
        return None
    if den < 0:
        num, den = -num, -den
    g = math.gcd(abs(num), den)
    num //= g
    den //= g
    return str(num) if den == 1 else "%d/%d" % (num, den)


def odd_roots(b, c):
    disc = b * b - 4 * c
    if disc < 0:
        return None
    root = math.isqrt(disc)
    if root * root != disc:
        return None
    return ((-b - root) // 2, (-b + root) // 2)


def parse_quadratic(expr):
    if "x²" not in expr:
        return None
    rest = expr.split("x²", 1)[1]
    b = 0
    c = 0
    match_b = re.search(r"([+−])(\d*)x", rest)
    if match_b:
        sign = -1 if match_b.group(1) == "−" else 1
        number = match_b.group(2)
        b = sign * (int(number) if number else 1)
    match_c = re.search(r"([+−])(\d+)$", rest)
    if match_c:
        c = (-1 if match_c.group(1) == "−" else 1) * int(match_c.group(2))
    return b, c


# ---------- 数值题二次独立计算 ----------

def check_k2_3(item):
    match = re.search(r"不等式 (.+?)([<>≤≥])0 的解集是", item["stem"])
    if not match:
        return None
    parsed = parse_quadratic(match.group(1))
    if not parsed:
        return None
    roots = odd_roots(parsed[0], parsed[1])
    if not roots:
        return None
    r1, r2 = roots
    op = match.group(2)
    if op == "<":
        return "(%d,%d)" % (r1, r2)
    if op == "≤":
        return "[%d,%d]" % (r1, r2)
    if op == ">":
        return "(-∞,%d)∪(%d,+∞)" % (r1, r2)
    return "(-∞,%d]∪[%d,+∞)" % (r1, r2)


def check_k4_1(item):
    match = re.search(r"^(\d+)\^\((\d+)/(\d+)\) 的值是", item["stem"])
    if match:
        base, m, n = int(match.group(1)), int(match.group(2)), int(match.group(3))
        return str(round(base ** (m / n)))
    match = re.search(r"^\(1/(\d+)\)\^\(−1/(\d+)\) 的值是", item["stem"])
    if match:
        base, n = int(match.group(1)), int(match.group(2))
        return str(round(base ** (1 / n)))
    return None


def check_k4_3(item):
    match = re.search(r"^log([₂₃₄₅₁₀]+)(\d+) 的值是", item["stem"])
    if match:
        base = SUB[match.group(1)]
        value = int(match.group(2))
        return str(round(math.log(value, base)))
    match = re.search(r"^lg(\d+)\+lg(\d+) 的值是", item["stem"])
    if match:
        return str(round(math.log10(int(match.group(1)) * int(match.group(2)))))
    match = re.search(r"^log([₂₃₄₅₁₀]+)(\d+)\+log([₂₃₄₅₁₀]+)(\d+) 的值是", item["stem"])
    if match:
        base1 = SUB[match.group(1)]
        left = int(match.group(2))
        base2 = SUB[match.group(3)]
        right = int(match.group(4))
        return str(round(math.log(left, base1) + math.log(right, base2)))
    return None


def check_k6_1(item):
    match = re.search(r"a=\((-?\d+),(-?\d+)\)，则 \|a\|=", item["stem"])
    if match:
        x, y = int(match.group(1)), int(match.group(2))
        return str(round(math.sqrt(x * x + y * y)))
    match = re.search(r"a=\((-?\d+),(-?\d+)\)，b=\((-?\d+),(-?\d+)\)，则 a\+b=", item["stem"])
    if match:
        x1, y1, x2, y2 = [int(match.group(i)) for i in range(1, 5)]
        return "(%d,%d)" % (x1 + x2, y1 + y2)
    match = re.search(r"a=\((-?\d+),(-?\d+)\)，b=\((-?\d+),(-?\d+)\)，则 a−b=", item["stem"])
    if match:
        x1, y1, x2, y2 = [int(match.group(i)) for i in range(1, 5)]
        return "(%d,%d)" % (x1 - x2, y1 - y2)
    return None


def check_k6_2(item):
    match = re.search(r"a=\((-?\d+),(-?\d+)\)，b=\((-?\d+),(-?\d+)\)，则 a·b=", item["stem"])
    if not match:
        return None
    x1, y1, x2, y2 = [int(match.group(i)) for i in range(1, 5)]
    return str(x1 * x2 + y1 * y2)


def check_k9_4(item):
    match = re.search(r"数据 ([\d,]+) 的方差是", item["stem"])
    if not match:
        return None
    values = [int(x) for x in match.group(1).split(",")]
    mean = Fraction(sum(values), len(values))
    variance = sum((Fraction(v) - mean) ** 2 for v in values) / len(values)
    return frac_str(variance.numerator, variance.denominator)


def check_k10_3(item):
    match = re.search(r"A、B 相互独立，P\(A\)=([\d.]+)，P\(B\)=([\d.]+)，则 P\(AB\)=", item["stem"])
    if match:
        return str(round(float(match.group(1)) * float(match.group(2)), 2))
    match = re.search(r"A、B 互斥，P\(A\)=([\d.]+)，P\(B\)=([\d.]+)，则 P\(A∪B\)=", item["stem"])
    if match:
        return str(round(float(match.group(1)) + float(match.group(2)), 2))
    return None


def check_k12_1(item):
    match = re.search(r"过点 \((-?\d+),(-?\d+)\) 和 \((-?\d+),(-?\d+)\) 的直线斜率是", item["stem"])
    if match:
        x1, y1, x2, y2 = [int(match.group(i)) for i in range(1, 5)]
        return frac_str(y2 - y1, x2 - x1)
    match = re.search(r"倾斜角为 (\d+)° 的直线斜率是", item["stem"])
    if match:
        mapping = {"0": "0", "30": "√3/3", "45": "1", "60": "√3", "120": "−√3", "135": "−1", "150": "−√3/3"}
        return mapping.get(match.group(1))
    return None


def check_k12_4(item):
    match = re.search(r"圆 \(x([+−]\d+)\)²\+\(y([+−]\d+)\)²=(\d+) 的圆心是", item["stem"])
    if match:
        a = -int(match.group(1).replace("−", "-"))
        b = -int(match.group(2).replace("−", "-"))
        return "(%d,%d)" % (a, b)
    match = re.search(r"圆 \(x([+−]\d+)\)²\+\(y([+−]\d+)\)²=(\d+) 的半径是", item["stem"])
    if match:
        return str(round(math.sqrt(int(match.group(3)))))
    return None


def check_k12_5(item):
    match = re.search(r"圆半径为 (\d+)，圆心到直线的距离为 (\d+)，则弦长是", item["stem"])
    if not match:
        return None
    radius, distance = int(match.group(1)), int(match.group(2))
    value = radius * radius - distance * distance
    if value < 0:
        return None
    return str(2 * math.isqrt(value))


def check_k13_1(item):
    match = re.search(r"椭圆 x²/(\d+)\+y²/(\d+)=1 的(焦距|离心率|长轴长|短轴长|c)", item["stem"])
    if not match:
        return None
    a2, b2 = int(match.group(1)), int(match.group(2))
    a = math.isqrt(a2)
    b = math.isqrt(b2)
    c = math.isqrt(a2 - b2)
    kind = match.group(3)
    if kind == "焦距":
        return str(2 * c)
    if kind == "离心率":
        return frac_str(c, a)
    if kind == "长轴长":
        return str(2 * a)
    if kind == "短轴长":
        return str(2 * b)
    return str(c)


def check_k14_2(item):
    match = re.search(r"a_1=(-?\d+)，d=(-?\d+)，则 a_(\d+)=", item["stem"])
    if match:
        a1, d, n = int(match.group(1)), int(match.group(2)), int(match.group(3))
        return str(a1 + (n - 1) * d)
    match = re.search(r"a_1=(-?\d+)，d=(-?\d+)，则 S_(\d+)=", item["stem"])
    if match:
        a1, d, n = int(match.group(1)), int(match.group(2)), int(match.group(3))
        return str(n * (2 * a1 + (n - 1) * d) // 2)
    return None


def check_k14_3(item):
    match = re.search(r"a_1=(\d+)，q=(\d+)，则 a_(\d+)=", item["stem"])
    if match:
        a1, q, n = int(match.group(1)), int(match.group(2)), int(match.group(3))
        return str(a1 * q ** (n - 1))
    match = re.search(r"a_1=(\d+)，q=(\d+)，则 S_(\d+)=", item["stem"])
    if match:
        a1, q, n = int(match.group(1)), int(match.group(2)), int(match.group(3))
        return str(a1 * (q ** n - 1) // (q - 1))
    return None


def check_k15_3(item):
    match = re.search(r"f\(x\)=(.+?) 的极小值是", item["stem"])
    if not match:
        return None
    parsed = parse_quadratic(match.group(1))
    if not parsed:
        return None
    b, c = parsed
    return str(c - b * b // 4)


def check_k17_3(item):
    match = re.search(r"X~B\((\d+),([\d.]+)\)，则 E\(X\)=", item["stem"])
    if match:
        return str(round(int(match.group(1)) * float(match.group(2)), 2))
    match = re.search(r"X~B\((\d+),([\d.]+)\)，则 P\(X=(\d+)\)=", item["stem"])
    if match:
        n, p, k = int(match.group(1)), float(match.group(2)), int(match.group(3))
        return str(round(math.comb(n, k) * p ** k * (1 - p) ** (n - k), 4))
    return None


def check_k18_2(item):
    match = re.search(r"经过样本中心 \((\d+),(\d+)\)，b̂=([\d.]+)，则 â=", item["stem"])
    if match:
        xbar, ybar, slope = float(match.group(1)), float(match.group(2)), float(match.group(3))
        return str(round(ybar - slope * xbar, 2))
    match = re.search(r"ŷ=([\d.]+)x([+−][\d.]+)，当 x=(\d+) 时 ŷ=", item["stem"])
    if match:
        slope = float(match.group(1))
        intercept = float(match.group(2).replace("−", "-"))
        x = int(match.group(3))
        return str(round(slope * x + intercept, 2))
    return None


def radian_text(angle):
    value = Fraction(angle, 180)
    num, den = value.numerator, value.denominator
    if num == 0:
        return "0"
    if den == 1:
        return "π" if num == 1 else "%dπ" % num
    return ("π/%d" % den) if num == 1 else ("%dπ/%d" % (num, den))


def fmt_pi(value):
    num, den = value.numerator, value.denominator
    if num == 0:
        return "0"
    if den == 1:
        return "π" if num == 1 else "%dπ" % num
    return ("π/%d" % den) if num == 1 else ("%dπ/%d" % (num, den))


def parse_int_set(text):
    inner = text.strip()
    if inner.startswith("{") and inner.endswith("}"):
        inner = inner[1:-1]
    if not inner.strip():
        return set()
    return {int(part) for part in inner.split(",")}


def fmt_int_set(values):
    return "{" + ",".join(str(value) for value in sorted(values)) + "}"


def parse_complex(text):
    text = text.replace("−", "-").replace(" ", "")
    if text == "i":
        return 0, 1
    if text == "-i":
        return 0, -1
    match = re.fullmatch(r"(-?\d+)([+-]\d+)?i", text)
    if match:
        if match.group(2) is None:
            return 0, int(match.group(1))
        return int(match.group(1)), int(match.group(2))
    match = re.fullmatch(r"([+-]\d+)i", text)
    if match:
        return 0, int(match.group(1))
    return int(text), 0


def fmt_complex(real, imag):
    if imag == 0:
        return str(real)
    if imag == 1:
        return ("%d+i" % real) if real else "i"
    if imag == -1:
        return ("%d-i" % real) if real else "-i"
    if real == 0:
        return "%s%di" % ("-" if imag < 0 else "", abs(imag))
    return "%d%s%di" % (real, "+" if imag > 0 else "-", abs(imag))


def check_k1_1(item):
    match = re.search(r"集合 \{x∈Z \| \|x\|≤(\d+)\} 的元素个数是", item["stem"])
    if match:
        return str(2 * int(match.group(1)) + 1)
    match = re.search(r"集合 \{x \| x²=(-?\d+)\} 的元素个数是", item["stem"])
    if match:
        value = int(match.group(1))
        return "2" if value > 0 else ("1" if value == 0 else "0")
    return None


def check_k1_2(item):
    match = re.search(r"集合 A 有 (\d+) 个元素，则 A 的(子集|真子集)个数是", item["stem"])
    if not match:
        return None
    n = int(match.group(1))
    return str(2 ** n if match.group(2) == "子集" else 2 ** n - 1)


def check_k1_3(item):
    match = re.search(r"A=\{([^}]*)\}，B=\{([^}]*)\}，则 A([∩∪])B=", item["stem"])
    if match:
        left = parse_int_set(match.group(1))
        right = parse_int_set(match.group(2))
        result = left & right if match.group(3) == "∩" else left | right
        return fmt_int_set(result) if result else "∅"
    match = re.search(r"全集 U=\{([^}]*)\}，A=\{([^}]*)\}，则 ∁_?U A=", item["stem"])
    if match:
        universe = parse_int_set(match.group(1))
        left = parse_int_set(match.group(2))
        result = universe - left
        return fmt_int_set(result) if result else "∅"
    return None


def check_k1_4(item):
    match = re.search(r"用区间表示集合 \{x \| (-?\d+)([<≤])x([<≤])(-?\d+)\}", item["stem"])
    if not match:
        return None
    left = "[" if match.group(2) == "≤" else "("
    right = "]" if match.group(3) == "≤" else ")"
    return "%s%s,%s%s" % (left, match.group(1), match.group(4), right)


def check_k5_1(item):
    match = re.search(r"^(\d+)° 化为弧度是", item["stem"])
    if match:
        return radian_text(int(match.group(1)))
    match = re.search(r"半径为 (\d+)、圆心角为 (\d+) rad 的弧长是", item["stem"])
    if match:
        return str(int(match.group(1)) * int(match.group(2)))
    match = re.search(r"半径为 (\d+)、圆心角为 (\d+) rad 的扇形面积是", item["stem"])
    if match:
        radius, alpha = int(match.group(1)), int(match.group(2))
        return frac_str(alpha * radius * radius, 2)
    return None


def check_k5_2(item):
    match = re.search(r"已知 sinα=(\d+)/(\d+) 且 α 在(第[一二三四]象限)，则 (cosα|tanα)=", item["stem"])
    if not match:
        return None
    opposite, hypotenuse = int(match.group(1)), int(match.group(2))
    quadrant = match.group(3)
    adjacent = math.isqrt(hypotenuse * hypotenuse - opposite * opposite)
    if match.group(4) == "cosα":
        sign = 1 if quadrant in ("第一象限", "第四象限") else -1
        return frac_str(sign * adjacent, hypotenuse)
    sign = 1 if quadrant in ("第一象限", "第三象限") else -1
    return frac_str(sign * opposite, adjacent)


def check_k5_4(item):
    match = re.search(r"函数 y=(\d+)sin\((\d+)x\)([+−]\d+) 的最大值是", item["stem"])
    if match:
        amplitude = int(match.group(1))
        offset = int(match.group(3).replace("−", "-"))
        return str(amplitude + offset)
    match = re.search(r"函数 y=sin\((\d+)x\) 的最小正周期是", item["stem"])
    if match:
        omega = int(match.group(1))
        return "2π" if omega == 1 else "2π/%d" % omega
    return None


def check_k5_6(item):
    match = re.search(r"函数 y=(\d+)sin\((\d+)x\+([^)]+)\) 的(振幅|最小正周期|初相)是", item["stem"])
    if not match:
        return None
    amplitude, omega = int(match.group(1)), int(match.group(2))
    phase = match.group(3)
    kind = match.group(4)
    if kind == "振幅":
        return str(amplitude)
    if kind == "最小正周期":
        return "2π" if omega == 1 else "2π/%d" % omega
    return phase


def check_k6_3(item):
    match = re.search(r"在 △ABC 中，a=(\d+)，b=(\d+)，C=(\d+)°，则 c²=", item["stem"])
    if not match:
        return None
    a, b, angle = int(match.group(1)), int(match.group(2)), int(match.group(3))
    value = a * a + b * b - 2 * a * b * math.cos(math.radians(angle))
    return str(round(value))


def check_k7_1(item):
    match = re.search(r"复数 z=(.+?) 的(实部|虚部|共轭复数)是", item["stem"])
    if not match:
        return None
    real, imag = parse_complex(match.group(1))
    kind = match.group(2)
    if kind == "实部":
        return str(real)
    if kind == "虚部":
        return str(imag)
    return fmt_complex(real, -imag)


def check_k7_2(item):
    match = re.search(r"\(([^()]+)\)\+\(([^()]+)\)=", item["stem"])
    if match:
        r1, i1 = parse_complex(match.group(1))
        r2, i2 = parse_complex(match.group(2))
        return fmt_complex(r1 + r2, i1 + i2)
    match = re.search(r"\(([^()]+)\)\(([^()]+)\)=", item["stem"])
    if match:
        r1, i1 = parse_complex(match.group(1))
        r2, i2 = parse_complex(match.group(2))
        return fmt_complex(r1 * r2 - i1 * i2, r1 * i2 + i1 * r2)
    return None


def check_k7_3(item):
    match = re.search(r"复数 z=(.+?) 的模是", item["stem"])
    if match:
        real, imag = parse_complex(match.group(1))
        return str(round(math.sqrt(real * real + imag * imag)))
    match = re.search(r"复数 z=(.+?) 对应的点位于", item["stem"])
    if match:
        real, imag = parse_complex(match.group(1))
        if real > 0 and imag > 0:
            return "第一象限"
        if real < 0 and imag > 0:
            return "第二象限"
        if real < 0 and imag < 0:
            return "第三象限"
        return "第四象限"
    return None


def check_k8_1(item):
    match = re.search(r"(\d+) (棱柱|棱锥)有几个(面|棱|顶点)", item["stem"])
    if not match:
        return None
    n = int(match.group(1))
    kind = match.group(2)
    part = match.group(3)
    if kind == "棱柱":
        return str({"面": n + 2, "棱": 3 * n, "顶点": 2 * n}[part])
    return str({"面": n + 1, "棱": 2 * n, "顶点": n + 1}[part])


def check_k8_2(item):
    match = re.search(r"半径为 (\d+) 的球(体积|表面积)是", item["stem"])
    if match:
        radius = int(match.group(1))
        if match.group(2) == "体积":
            return fmt_pi(Fraction(4 * radius ** 3, 3))
        return fmt_pi(Fraction(4 * radius * radius, 1))
    match = re.search(r"底面半径为 (\d+)、高为 (\d+) 的(圆柱|圆锥)体积是", item["stem"])
    if match:
        radius, height = int(match.group(1)), int(match.group(2))
        if match.group(3) == "圆柱":
            return fmt_pi(Fraction(radius * radius * height, 1))
        return fmt_pi(Fraction(radius * radius * height, 3))
    return None


def check_k9_1(item):
    match = re.search(r"总体 (\d+) 人，抽取 (\d+) 人，抽样比是", item["stem"])
    if not match:
        return None
    return frac_str(int(match.group(2)), int(match.group(1)))


def check_k9_2(item):
    match = re.search(r"某组频率为 ([\d.]+)，组距为 (\d+)，则直方图纵轴高度是", item["stem"])
    if match:
        return "%g" % (float(match.group(1)) / int(match.group(2)))
    match = re.search(r"某组纵轴高度为 ([\d.]+)，组距为 (\d+)，则该组频率是", item["stem"])
    if match:
        return "%g" % (float(match.group(1)) * int(match.group(2)))
    return None


def check_k9_3(item):
    match = re.search(r"数据 ([\d,]+) 的(平均数|中位数|众数)是", item["stem"])
    if not match:
        return None
    values = [int(x) for x in match.group(1).split(",")]
    kind = match.group(2)
    if kind == "平均数":
        return frac_str(sum(values), len(values))
    if kind == "中位数":
        ordered = sorted(values)
        return str(ordered[len(ordered) // 2])
    counts = {}
    for value in values:
        counts[value] = counts.get(value, 0) + 1
    return str(max(counts, key=counts.get))


def check_k10_1(item):
    match = re.search(r"若 P\(A\)=([\d.]+)，则 P\(Ā\) 等于", item["stem"])
    if not match:
        return None
    return str(round(1 - float(match.group(1)), 1))


def check_k10_2(item):
    events = {
        "出现偶数": 3, "出现奇数": 3, "出现大于 4 的数": 2,
        "出现小于 5 的数": 4, "出现质数": 3, "出现 3 的倍数": 2,
    }
    match = re.search(r"掷一枚均匀骰子，(.+?)的概率是", item["stem"])
    if match and match.group(1) in events:
        return frac_str(events[match.group(1)], 6)
    match = re.search(r"袋中有 (\d+) 个红球、(\d+) 个白球，任取 1 个，取到([红白])球的概率是", item["stem"])
    if match:
        red, white = int(match.group(1)), int(match.group(2))
        count = red if match.group(3) == "红" else white
        return frac_str(count, red + white)
    match = re.search(r"从 1 到 (\d+) 中任取一个数，取到 (\d+) 的倍数的概率是", item["stem"])
    if match:
        total, multiple = int(match.group(1)), int(match.group(2))
        return frac_str(total // multiple, total)
    return None


def check_k10_4(item):
    match = re.search(r"某事件在 (\d+) 次试验中发生了 (\d+) 次，频率是", item["stem"])
    if match:
        return str(round(int(match.group(2)) / int(match.group(1)), 2))
    match = re.search(r"频率稳定在 ([\d.]+)，估计其概率为", item["stem"])
    if match:
        return match.group(1)
    return None


def check_k11_1(item):
    match = re.search(r"向量 a=\((-?\d+),(-?\d+),(-?\d+)\)，则 \|a\|=", item["stem"])
    if match:
        x, y, z = [int(match.group(i)) for i in range(1, 4)]
        return str(round(math.sqrt(x * x + y * y + z * z)))
    match = re.search(r"a=\((-?\d+),(-?\d+),(-?\d+)\)，b=\((-?\d+),(-?\d+),(-?\d+)\)，则 a·b=", item["stem"])
    if match:
        values = [int(match.group(i)) for i in range(1, 7)]
        return str(values[0] * values[3] + values[1] * values[4] + values[2] * values[5])
    match = re.search(r"a=\((-?\d+),(-?\d+),(-?\d+)\)，b=\((-?\d+),(-?\d+),(-?\d+)\)，则 a\+b=", item["stem"])
    if match:
        values = [int(match.group(i)) for i in range(1, 7)]
        return "(%d,%d,%d)" % (values[0] + values[3], values[1] + values[4], values[2] + values[5])
    return None


def check_k12_2(item):
    match = re.search(r"过点 \((-?\d+),(-?\d+)\)、斜率为 (-?\d+) 的点斜式方程是", item["stem"])
    if match:
        x0, y0, k = int(match.group(1)), int(match.group(2)), int(match.group(3))
        y_part = ("−%d" % y0) if y0 >= 0 else ("+%d" % (-y0))
        x_part = ("−%d" % x0) if x0 >= 0 else ("+%d" % (-x0))
        return "y%s=%d(x%s)" % (y_part, k, x_part)
    match = re.search(r"斜率为 (-?\d+)、过点 \((-?\d+),(-?\d+)\) 的斜截式方程是", item["stem"])
    if match:
        k, x0, y0 = int(match.group(1)), int(match.group(2)), int(match.group(3))
        b = y0 - k * x0
        return "y=%dx%s%d" % (k, "+" if b >= 0 else "−", abs(b))
    return None


def check_k12_3(item):
    match = re.search(r"点 \((-?\d+),(-?\d+)\) 到直线 3x\+4y([+-]\d+)=0 的距离是", item["stem"])
    if match:
        x0, y0, c = int(match.group(1)), int(match.group(2)), int(match.group(3))
        return str(abs(3 * x0 + 4 * y0 + c) // 5)
    match = re.search(r"直线 y=(-?\d+)x([+−]\d+) 与 y=(-?\d+)x([+−]\d+) 的位置关系是", item["stem"])
    if match:
        k1 = int(match.group(1))
        k2 = int(match.group(3))
        return "平行" if k1 == k2 else "相交"
    match = re.search(r"直线 y=(-?\d+)x([+−]\d+) 与斜率为 ([^ ]+) 的直线位置关系是", item["stem"])
    if match:
        k1 = int(match.group(1))
        try:
            k2 = Fraction(match.group(3).replace("−", "-"))
        except (ValueError, ZeroDivisionError):
            return None
        return "垂直" if Fraction(k1) * k2 == -1 else "相交"
    return None


def check_k13_2(item):
    match = re.search(r"双曲线 x²/(\d+)−y²/(\d+)=1 的(c 等于|渐近线是|离心率是)", item["stem"])
    if not match:
        return None
    a2, b2 = int(match.group(1)), int(match.group(2))
    a, b = math.isqrt(a2), math.isqrt(b2)
    c = math.isqrt(a2 + b2)
    kind = match.group(3)
    if kind == "c 等于":
        return str(c)
    if kind == "渐近线是":
        return "y=±(%d/%d)x" % (b, a)
    return frac_str(c, a)


def check_k13_3(item):
    match = re.search(r"抛物线 y²=(\d+)x 的(焦点坐标是|准线方程是|焦点到准线的距离是)", item["stem"])
    if not match:
        return None
    value = int(match.group(1))
    p = value // 2
    kind = match.group(2)
    if kind == "焦点坐标是":
        return "(%d,0)" % (p // 2)
    if kind == "准线方程是":
        return "x=-%d" % (p // 2)
    return str(p)


def check_k14_1(item):
    match = re.search(r"数列 a_n=(\d+)n([+−]\d+)，则 a_(\d+)=", item["stem"])
    if match:
        p = int(match.group(1))
        q = int(match.group(2).replace("−", "-"))
        n = int(match.group(3))
        return str(p * n + q)
    match = re.search(r"数列 ([\d,]+),… 的通项公式是", item["stem"])
    if match:
        terms = [int(x) for x in match.group(1).split(",")]
        p = terms[1] - terms[0]
        q = terms[0] - p
        if q == 0:
            return "%dn" % p
        return "%dn%s%d" % (p, "+" if q > 0 else "-", abs(q))
    return None


def check_k14_4(item):
    match = re.search(r"1\+2\+3\+…\+(\d+) 等于", item["stem"])
    if match:
        n = int(match.group(1))
        return str(n * (n + 1) // 2)
    match = re.search(r"1\+3\+5\+…\+(\d+) 等于", item["stem"])
    if match:
        last = int(match.group(1))
        n = (last + 1) // 2
        return str(n * n)
    match = re.search(r"2\+4\+6\+…\+(\d+) 等于", item["stem"])
    if match:
        last = int(match.group(1))
        n = last // 2
        return str(n * (n + 1))
    return None


def check_k15_1(item):
    match = re.search(r"^\(x\^(\d+)\)'=", item["stem"])
    if match:
        n = int(match.group(1))
        return ("%dx^%d" % (n, n - 1)) if n - 1 != 1 else ("%dx" % n)
    match = re.search(r"^\((\d+)x²([+−]\d+)x([+−]\d+)\)'=", item["stem"])
    if match:
        a = int(match.group(1))
        b = int(match.group(2).replace("−", "-"))
        return "%dx%s%d" % (2 * a, "+" if b >= 0 else "−", abs(b))
    basics = {
        "(sinx)'=": "cosx",
        "(cosx)'=": "−sinx",
        "(e^x)'=": "e^x",
        "(lnx)'=": "1/x",
    }
    return basics.get(item["stem"])


def check_k15_2(item):
    match = re.search(r"f\(x\)=(.+?) 的单调(递减|递增)区间是", item["stem"])
    if not match:
        return None
    parsed = parse_quadratic(match.group(1))
    if not parsed:
        return None
    b = parsed[0]
    axis = -b // 2
    if match.group(2) == "递减":
        return "(-∞,%d)" % axis
    return "(%d,+∞)" % axis


def check_k15_4(item):
    match = re.search(r"周长为 (\d+) 的矩形面积最大值是", item["stem"])
    if match:
        side = int(match.group(1)) // 4
        return str(side * side)
    match = re.search(r"利润函数 L\(x\)=−x²\+(\d+)x\+(\d+) 的最大值是", item["stem"])
    if match:
        b, c = int(match.group(1)), int(match.group(2))
        return str(c + b * b // 4)
    return None


def check_k16_1(item):
    match = re.search(r"完成一件事有 (\d+) 类互斥办法，分别有 (.+?)，共有多少种办法", item["stem"])
    if match:
        return str(sum(int(x) for x in re.findall(r"(\d+) 种", match.group(2))))
    match = re.search(r"完成一件事需要 (\d+) 步，每步分别有 (.+?) 选择，共有多少种方法", item["stem"])
    if match:
        product = 1
        for x in re.findall(r"(\d+) 种", match.group(2)):
            product *= int(x)
        return str(product)
    return None


def check_k16_2(item):
    match = re.search(r"从 (\d+) 个不同元素中取 (\d+) 个排成一列", item["stem"])
    if not match:
        return None
    n, m = int(match.group(1)), int(match.group(2))
    value = 1
    for i in range(m):
        value *= (n - i)
    return str(value)


def check_k16_3(item):
    match = re.search(r"从 (\d+) 个不同元素中取 (\d+) 个，共有多少种取法", item["stem"])
    if not match:
        return None
    return str(math.comb(int(match.group(1)), int(match.group(2))))


def check_k16_4(item):
    match = re.search(r"\(x\+(\d+)\)\^(\d+) 展开式中 x\^(\d+) 的系数是", item["stem"])
    if not match:
        return None
    a, n, k = int(match.group(1)), int(match.group(2)), int(match.group(3))
    return str(math.comb(n, n - k) * a ** (n - k))


def check_k17_1(item):
    match = re.search(r"P\(A\)=([\d.]+)，P\(AB\)=([\d.]+)，则 P\(B\|A\)=", item["stem"])
    if not match:
        return None
    return str(round(float(match.group(2)) / float(match.group(1)), 2))


def check_k17_2(item):
    match = re.search(r"P\(0\)=([\d.]+)，P\(1\)=([\d.]+)，P\(2\)=([\d.]+)，则 E\(X\)=", item["stem"])
    if match:
        p0, p1, p2 = [float(match.group(i)) for i in range(1, 4)]
        return str(round(0 * p0 + 1 * p1 + 2 * p2, 1))
    match = re.search(r"P\(0\)=([\d.]+)，P\(1\)=([\d.]+)，则 P\(2\)=", item["stem"])
    if match:
        p0, p1 = float(match.group(1)), float(match.group(2))
        return str(round(1 - p0 - p1, 1))
    return None


CHECKS = {
    "K2.3": check_k2_3,
    "K4.1": check_k4_1,
    "K4.3": check_k4_3,
    "K6.1": check_k6_1,
    "K6.2": check_k6_2,
    "K9.4": check_k9_4,
    "K10.3": check_k10_3,
    "K12.1": check_k12_1,
    "K12.4": check_k12_4,
    "K12.5": check_k12_5,
    "K13.1": check_k13_1,
    "K14.2": check_k14_2,
    "K14.3": check_k14_3,
    "K15.3": check_k15_3,
    "K17.3": check_k17_3,
    "K18.2": check_k18_2,
    "K1.1": check_k1_1,
    "K1.2": check_k1_2,
    "K1.3": check_k1_3,
    "K1.4": check_k1_4,
    "K5.1": check_k5_1,
    "K5.2": check_k5_2,
    "K5.4": check_k5_4,
    "K5.6": check_k5_6,
    "K6.3": check_k6_3,
    "K7.1": check_k7_1,
    "K7.2": check_k7_2,
    "K7.3": check_k7_3,
    "K8.1": check_k8_1,
    "K8.2": check_k8_2,
    "K9.1": check_k9_1,
    "K9.2": check_k9_2,
    "K9.3": check_k9_3,
    "K10.1": check_k10_1,
    "K10.2": check_k10_2,
    "K10.4": check_k10_4,
    "K11.1": check_k11_1,
    "K12.2": check_k12_2,
    "K12.3": check_k12_3,
    "K13.2": check_k13_2,
    "K13.3": check_k13_3,
    "K14.1": check_k14_1,
    "K14.4": check_k14_4,
    "K15.1": check_k15_1,
    "K15.2": check_k15_2,
    "K15.4": check_k15_4,
    "K16.1": check_k16_1,
    "K16.2": check_k16_2,
    "K16.3": check_k16_3,
    "K16.4": check_k16_4,
    "K17.1": check_k17_1,
    "K17.2": check_k17_2,
}


def audit(data):
    items = data["items"]
    kp_ids = {kp["id"] for kp in data["knowledge"]}
    ids = {}
    stems = {}
    structure = []
    option_issues = []
    numeric_checked = 0
    numeric_failed = []
    short_explain = []

    for item in items:
        item_id = item.get("id", "")
        ids[item_id] = ids.get(item_id, 0) + 1
        if item.get("kpId") not in kp_ids:
            structure.append("%s：未知考点 %s" % (item_id, item.get("kpId")))
        if item.get("answer") is None or str(item.get("answer")).strip() == "":
            structure.append("%s：答案为空" % item_id)
        item_type = item.get("type")
        if item_type not in ("choice", "judge", "multi", "fill", "solve"):
            structure.append("%s：未知题型 %s" % (item_id, item_type))
        if item_type in ("choice", "judge", "multi"):
            options = item.get("options")
            if not isinstance(options, list) or len(options) < 2:
                structure.append("%s：选项不足" % item_id)
            else:
                answer = str(item.get("answer", "")).upper()
                upper = chr(ord("A") + len(options) - 1)
                letters = set(answer) if item_type == "multi" else {answer}
                for letter in letters:
                    if letter < "A" or letter > upper:
                        structure.append("%s：答案 %s 越界" % (item_id, answer))
                normalized = [norm(option) for option in options]
                if len(set(normalized)) != len(normalized):
                    option_issues.append("%s：选项文本重复" % item_id)
                numeric = []
                for option in options:
                    text = norm(option)
                    try:
                        numeric.append(Fraction(text))
                    except (ValueError, ZeroDivisionError):
                        pass
                if len(numeric) != len(set(numeric)):
                    option_issues.append("%s：选项数值等价" % item_id)
                if item_type in ("choice", "multi"):
                    positives = set()
                    for line in item.get("explain", "").split("\n"):
                        match_line = re.match(r"([A-D])、(.+)", line.strip())
                        if not match_line:
                            continue
                        text = match_line.group(2)
                        if any(word in text for word in ("错", "不一定", "不成立", "不正确", "不符合", "不满足", "无法")):
                            continue
                        if re.search(r"(?:，|,)?\s*(?:对|正确|成立|符合)[。；]?$", text):
                            positives.add(match_line.group(1))
                    if positives and positives != set(answer):
                        option_issues.append(
                            "%s：解析标为“对”的选项 %s 与答案 %s 不一致" % (
                                item_id, "".join(sorted(positives)), answer))
        if len(item.get("explain", "")) < 40:
            short_explain.append(item_id)
        stem_key = item.get("stem", "").strip()
        stems[stem_key] = stems.get(stem_key, 0) + 1

        checker = CHECKS.get(item.get("kpId"))
        if checker and item_id.startswith("q_gen_"):
            try:
                expected = checker(item)
            except Exception:
                expected = None
            if expected is not None:
                numeric_checked += 1
                actual = value_of_answer(item)
                if not values_equal(expected, actual):
                    numeric_failed.append(
                        "%s：应为 %s，实际 %s | %s" % (item_id, expected, actual, item.get("stem")))

    for item_id, count in ids.items():
        if count > 1:
            structure.append("%s：ID 重复 %d 次" % (item_id, count))
    duplicate_stems = [(stem, count) for stem, count in stems.items() if count > 1]

    return {
        "total": len(items),
        "generated": sum(1 for item in items if item["id"].startswith("q_gen_")),
        "structure": structure,
        "option_issues": option_issues,
        "numeric_checked": numeric_checked,
        "numeric_failed": numeric_failed,
        "duplicate_stems": duplicate_stems,
        "short_explain": short_explain,
    }


def main():
    quiet = "--quiet" in sys.argv
    data = load_data()
    report = audit(data)
    print("=== 题库审计 ===")
    print("题数 %d（生成题 %d）" % (report["total"], report["generated"]))
    print("结构问题 %d" % len(report["structure"]))
    print("选项问题 %d" % len(report["option_issues"]))
    print("数值二次校验 %d 道，失败 %d 道" % (
        report["numeric_checked"], len(report["numeric_failed"])))
    print("重复题干 %d 组" % len(report["duplicate_stems"]))
    print("短解析 %d 道" % len(report["short_explain"]))
    print("---")
    groups = [
        ("结构", report["structure"]),
        ("选项", report["option_issues"]),
        ("数值答案", report["numeric_failed"]),
    ]
    for label, issues in groups:
        for issue in issues:
            print("[%s] %s" % (label, issue))
    for stem, count in report["duplicate_stems"]:
        print("[重复题干] %s × %d" % (stem[:40], count))
    failed = bool(report["structure"] or report["numeric_failed"])
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())