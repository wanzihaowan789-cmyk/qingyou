# 青柚学伴 · 项目交接文档

> 用途：把「和 AI 协作开发」的上下文压缩成可交接的文档，方便在 CodeArts 客户端继续开发。
> 最后更新：2026-11-12

---

## 1. 我们在做什么

给妹妹（**0 基础、目标及格**）做的高一数学诊断复习网站，不是刷题海工具，而是一条闭环：

```
诊断（她差在哪） → 给原因（分主次） → 干预（对应练习/概念卡） → 复测（分数有没有降） → 趋势（长期有没有用）
```

核心设计原则（已确认的用户偏好）：

- **质量 > 数量**，答案必须正确且通俗
- 基础题优先，中档题需要「基础达标」才解锁
- 解析必须分步，不能只写「答案是 X」
- 界面要对标商业产品（不是学生作业风格）

---

## 2. 现在到什么程度

**线上地址**：https://wanzihaowan789-cmyk.github.io/qingyou/

| 指标 | 现状 |
|---|---|
| 题库 | 1815 题（人工 349 + 参数化生成 1466） |
| 考点 | 76 个，覆盖 18 章 |
| 概念卡 | 76 张，全部带例题（3–5 步） |
| 答案白名单 | 276 道题自动生成 accept 等价写法 |
| 首屏体积 | 337 题 + 76 卡，gzip 约 99KB |
| 后台加载 | 1466 生成题，gzip 约 53KB |
| 首屏可交互 | 本地 0.6s / 线上 2–5s（CDN 波动） |
| 自检 | 38 项全过（本地 + 线上各跑一遍） |

---

## 3. 技术架构

- **纯静态**：单页应用，无后端、无框架、无外部依赖（除 Google Fonts 可选）
- **数据**：全部存浏览器 `localStorage`，按「学习档案」隔离
- **部署**：GitHub Pages，`main` 分支根目录
- **分包**：`data.core.js`（首屏）+ `data.bulk.js`（首屏渲染后异步加载）

不支持：账号登录、跨设备同步、服务端存储。跨设备靠「导出/导入」。

---

## 4. 文件结构

```
qingyou/
├── index.html              多文件开发版入口
├── style.css               全部样式
├── app.js                  全部逻辑（约 4200 行）
├── data.js                 合并产物（勿手改）
├── data.base.js            原始人工题库（合并基底）
├── content/
│   ├── part0-7.json        各批人工题
│   ├── part8-manual.json   2026-11 新增的 12 道情境题
│   ├── zz-generated.json   生成题（可重新生成）
│   ├── examples*.json      76 个例题
│   ├── config/weights.json 76 个考点权重（2–5）
│   └── patches/explain*.json 解析补丁
├── build-data.py           合并题库 + 权重 + 例题 + 白名单 + 自动审计
├── build-deploy.py         生成线上分包（deploy/）
├── build-standalone.py     生成单文件版（分发用）
├── math_equiv.py           答案等价规则（Python 侧，与 app.js 同源）
├── audit-items.py          题库审计（结构/选项/数值二次计算）
├── validate-items.py       外部题库导入校验
├── publish.py              发布到 GitHub（走 Contents API，不依赖 git 协议）
├── verify.py               综合验收（10 项）
├── selfcheck.py            自检上（17 项：加载/今日/概念卡/错题台）
├── selfcheck2.py           自检下（14 项：答题/档案/归因/干预/布局）
├── analyze-priority.py     生成「人工重写优先级清单」
├── docs/priority-rewrite.md 优先级清单产物
├── CHANGELOG.md            变更记录（25 条 bug + 性能 + v2 迭代，查改动看这份）
├── deploy/                 【线上发布目录】5 个文件 + README.txt
└── qingyou-standalone.html 单文件版（双击即开，离线用）
```

**线上只发布 deploy/ 里的 5 个文件**，其余是开发资产。

**GitHub 仓库实际托管的是产物，不是源码**（2026-11-12 核对）：远端根目录只有
`index.html` / `app.js` / `style.css` / `data.core.js` / `data.bulk.js` / `README.txt` / `HANDOFF.md`
七个文件，没有 `data.js`、`content/`、构建脚本。所以「代码在 GitHub」这句话只对产物成立，
源码必须另有备份。

---

## 5. 功能清单（已实现）

### 今日页
- 连续学习卡：连续天数、今日 N/5 进度条、三个徽章
- 「开始今天的 N 题」按钮：优先到期复习，否则选权重最高/练得最少的考点抽 5 题
- 「当前最该补」：只显示归因引擎的第一主因
- 及格诊断卡、今日到期复习列表

### 概念卡
- 76 张，按 18 章分组，章节下拉筛选
- 默认折叠，展开后：它从哪来/要点/易错/例题/自检/去练 2 道
- 实时搜索（140ms 防抖，输入不失焦）、关键词高亮、计数
- 收藏 + 「只看收藏」筛选（按钮 id `fav-filter`）
- 考点掌握状态徽章：待复习 / 复习中 / 已掌握
- **考点达标进度**：`基础题 2/3 · 答对 1 道 · 再答对 1 道就达标`

### 错题台
- 双视图：按考点聚合（默认）/ 按题目看板
- 聚合排序：`待复习题数 × (考点权重+1)`
- 「最该先补的 3 个考点」提示条
- 主要错因 + 对应建议（按 L0–L4）
- 展开原题、练 2 道、拖拽改状态

### 答题
- 题型：单选 / 多选 / 判断 / 填空 / 解答
- 「卡住了？看提示」：先回忆概念要点 + 例题思路
- 答错 → 直接展示 5 个错因（各带白话说明），底部保留「其实我算对了」改判
- 提交后自动定位到结果区（瞬间定位，不是平滑滚动）
- 等价判分：区间↔不等式、集合无序、空集、分数↔小数、无穷、判断题 A/正确 互认

### 画像页
- 学习档案：新建 / 切换 / 重命名 / 删除，各自独立进度
- **成绩归因**：六类原因打分排序，主因/次因/并列主因，带证据与干预入口
- **干预闭环**：点「去补」记录基线 → 练 3 题 → 自动复算 → 前后对比条
- **补练趋势**：同一原因多次干预的分数折线（SVG）
- 及格诊断报告：估分/150、距及格差多少、先补三个考点、错因分布
- 导出/导入：按当前档案，文件名带档案名+日期

### 数据与工程
- 学习档案隔离：`qingyou_state_v1:<profileId>`
- 旧数据自动迁移到第一个档案
- 导入题库（JSON，支持数组或 `{items:[]}`）
- 构建内置审计，不通过直接终止

---

## 6. 接手必须知道的 8 个机制

### 6.1 答案等价是「双实现」，改一处必须改两处
- 前端：`app.js` 的 `normalizeAnswer` / `answerCandidates` / `valuesEqual`
- 后端：`math_equiv.py` 的 `norm` / `forms` / `values_equal`
- 两边不同步会导致「审计通过但学生被判错」

### 6.2 归因引擎（`diagnoseReasons`）
六类原因，各自用客观证据打分：

| key | 名称 | 主要证据 |
|---|---|---|
| concept | 概念没建立 | 看提示仍错、概念判断类题错、同考点全错 |
| method | 方法不会迁移 | 基础题对中档题错、看提示后能做对 |
| calc | 计算不稳 | 答案接近正确值（差≤2 或符号反）、概念题对计算题错 |
| read | 审题漏条件 | 含「定义域/范围/恒成立」的题错误率显著更高 |
| review | 复习没跟上 | 逾期记录数 × 逾期天数 |
| speed | 熟练度不够 | 正确但耗时 >90s、复习后掉回错题 |

- 至少 8 条答题记录才出结论
- 证据为空的原因不显示
- 前两名分差 <25% 时标「并列主因」

### 6.3 干预闭环
- 点「去补」→ 记录 `state.intervention = {key, baseline, results:[]}`
- 每答一题 `trackIntervention` 追加
- 满 3 题或手动结束 → `finishIntervention` 复算 `afterScore`
- 结果写入 `state.interventionHistory`（最多 30 条）
- 趋势图 = 第一次 baseline + 每次 afterScore

### 6.4 学习档案
- `qingyou_profiles_v1`：`{active, list:[{id,name}]}`
- 状态 key：`qingyou_state_v1:<id>`
- 切换档案会 `saveState()` → 改 active → `loadState()` → 刷新所有视图

### 6.5 数学排版渲染器（`mathFragment`）
- 纯 DOM 拼接，不用 innerHTML
- 支持 `a/b`（竖排分数）、`√(...)`、`^上标`、`_下标`
- 只做展示，不改数据
- 调试钩子：`window.QY_MATH`（需 `window.QY_DEBUG=true`）

### 6.6 线上分包
- `build-deploy.py` 按 **id 前缀 `q_gen_`** 拆 core / bulk
- ⚠️ 如果以后导入大量新题且 id 不是 `q_gen_` 开头，会全部塞进首屏导致首屏爆炸
- **正确做法**：改成「每考点保留 2 道进 core，其余进 bulk」

### 6.7 判断题答案宽容
`normalizeJudge`：`A / 对 / 正确 / √` 互认，`B / 错 / 错误 / ×` 互认。

### 6.8 难度分配
`build-data.py` 原来强制「每考点前 2 道=基础，其余=中档」，会覆盖人工标注。
**已改为：题目自带 `level` 时以标注为准。**

---

## 7. 常用命令

```bash
# 改完题库后
python3 build-data.py          # 合并 + 审计（失败会中断）
python3 build-standalone.py    # 单文件版
python3 build-deploy.py        # 线上分包

# 发布（不需要 git，走 API）
GITHUB_TOKEN=xxx python3 publish.py "提交说明"

# 验收
python3 verify.py                                    # 本地 10 项
python3 selfcheck.py                                 # 本地 17 项
python3 selfcheck2.py                                # 本地 14 项
python3 selfcheck.py --url https://... --slow        # 线上

# 内容规划
python3 analyze-priority.py    # 刷新优先重写清单
```

**Windows / PowerShell（没有 bash 时用这套，脚本已放在项目根）**：

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1      # 单文件版 + 分包 + 回归，三步串起来
powershell -ExecutionPolicy Bypass -File .\serve.ps1      # 本地预览 http://127.0.0.1:8123/
$env:GITHUB_TOKEN = "github_pat_xxx"
powershell -ExecutionPolicy Bypass -File .\publish.ps1 "提交说明"
```

> 三个 `.ps1` 必须保存为 **UTF-8 with BOM**，否则 PowerShell 5.1 按 ANSI 解析，中文会吃掉引号导致语法错误（本轮已踩）。

---

## 8. 优化历程（时间线）

| 阶段 | 内容 |
|---|---|
| 1 | 题库建设：1803 题、76 考点、76 例题、审计接入构建 |
| 2 | 界面：概念卡折叠/章节下拉、及格诊断、连续学习卡 |
| 3 | 概念卡搜索收藏、数学排版渲染器、答案白名单 |
| 4 | 审计规则与前端对齐（`math_equiv.py`）、accept 自动补齐 276 道 |
| 5 | 错题台按考点聚合（排序、先补提示、错因建议） |
| 6 | 学习档案（同设备多人独立进度） |
| 7 | **成绩归因引擎**（六类原因、客观证据、分主次） |
| 8 | **干预闭环 + 补练趋势**（基线→3 题→对比→折线） |
| 9 | 考点达标进度（还差几题达标） |
| 10 | 首批人工情境题 12 道（对数/三角/正余弦定理），三个考点跌出优先级前 7 |
| 11 | v2 视觉与交互：宽屏两栏、吸顶头部、答题快捷键、每日目标、达标提示前置、趋势平台期 |

---

## 9. 已知问题与限制

1. **旧数据没有耗时和原始答案**，归因精度低于新数据（新答题才采集 `ms`/`answer`）
2. **90 秒「慢」的阈值是估的**，需要真实使用一周后校准
3. **干预复算用全局诊断分数**，补一个原因会带动其他原因变化
4. **GitHub Pages CDN 有缓存**，发布后可能 2–10 分钟才生效
5. **环境会被回收**（云端沙箱会话），代码在 GitHub + 本地备份，不会丢
6. **5000 题外部资料不可用**：PDF/docx 转出来的公式结构全部丢失（详见第 10 节）

---

## 10. 关于那批 5000 题（结论已定，别再尝试）

试过 4 种数据形态，全部失败：

| 数据 | 结果 |
|---|---|
| PDF 逐页文本 CSV | `e^{ln3}` → `eln3`，指数/分数/底数全丢 |
| 原卷版 CSV | 同上，且无答案 |
| Word 版 CSV | 公式变成 `[公式]` 占位符 |
| 客户端生成的 items.json | 5362 题，84% LaTeX 残留、73% 上下标丢失、68% 分数丢失，**完全无问题仅 74 道（1.4%）** |

**根因**：docx 的公式是 OMML 对象，普通文本抽取必然丢失，需要专门解析 `m:oMath` XML 节点。

**结论**：这批资料只能当「题型大纲」用，不能当题库。她的题应该由我们手写。

---

## 11. 下一步待办（按价值排序）

1. **内容**：按 `docs/priority-rewrite.md` 重写高频考点（前 7 名仍是 86% 生成题）
2. **诊断精度**：用妹妹真实数据校准阈值与权重
3. **复习页**：显示「这个考点还差几题达标」（概念卡已有，错题台有简版）
4. **趋势**：可以加「多次干预的斜率」判断是否进入平台期

---

## 12. 在客户端继续开发

```bash
git clone https://github.com/wanzihaowan789-cmyk/qingyou.git
cd qingyou
```

客户端打开这个目录后：

- 改代码 → `python3 build-standalone.py && python3 build-deploy.py`
- 跑 `python3 verify.py` / `selfcheck.py` 确认没坏
- 发布需要 **GitHub Personal Access Token**（Contents: Read and write），
  通过环境变量给：`GITHUB_TOKEN=xxx python3 publish.py "说明"`
- **不要**把 token 写进任何文件（仓库是公开的）

- 依赖：
  - Python 3（构建、审计、发布）
  - Playwright + Chromium（只在跑自检时需要）
  - Node.js（跑 `tools/smoke.js` 无浏览器回归，可选但推荐）

---

## 13. 踩过的坑（避免重复）

| 坑 | 现象 | 正确做法 |
|---|---|---|
| `pkill -f "xxx 8000"` | 把执行命令的 shell 自己杀了 | 用精确路径或先查 PID |
| `host.textContent=''` 重建工具栏 | 搜索框每输入一个字就失焦 | 工具栏只建一次，只重绘结果区 |
| 平滑滚动 + 自动点击 | 元素持续移动，点击落空 | 改 `scrollIntoView({block:'nearest'})` 瞬间定位 |
| 全局把 `-` 换成 `−` | 8 个考点的审计正则失配，校验从 1185 掉到 1076 | 只换补集符号，负号保持原样 |
| 默认章节锁定第一组 | 「只看收藏」显示 0 张 | 默认进「全部」，开收藏时清空章节 |
| git 协议推送 | 反复 `Failed to connect port 443` | 用 `publish.py` 走 API |
| 测试断言写死题数 | 加题后全量回归失败 | 断言改 `>=`，或同步更新数字 |
| 示例数据被判「未使用」 | 加载示例后刷新没了 | 这是设计：只有真实作答才落盘 |
| 目录里的 `app.js` 只有 42KB | 与本文档「4200 行」的描述对不上，功能是早期版 | 先比字节数（`Get-Item app.js`），以 zip 解压的 138KB 版为准 |

---

## 14. 交付物位置

- 线上：https://wanzihaowan789-cmyk.github.io/qingyou/
- 仓库：https://github.com/wanzihaowan789-cmyk/qingyou
- 单文件离线版：`qingyou-standalone.html`（约 960KB，双击即开）
- 文档：`HANDOFF.md`（交接看这份）+ `CHANGELOG.md`（查改动、查 bug 修复看那份）
---

## 15. v2 迭代（2026-11-12：视觉 + 交互）

**背景**：接手时目录里解压出的 `app.js` 只有 42KB / 1491 行，是早期版本；zip 内的 138KB / 4200 行才是线上版。本轮以 zip 解压版为准。

### 视觉
- 桌面容器 720 → 1120px；今日页 1024px 起两栏（左复习队列 / 右侧连续学习、最该补、及格诊断）
- 设计令牌重做：阴影三档、焦点 ring、缓动曲线；头部吸顶 + 毛玻璃
- 报告 hero 渐变 + 光斑；卡片 hover 微位移；品牌色块标记
- 全局 `:focus-visible`；收藏按钮触控目标补到 6×8
- 移动端答题层加拖拽把手；`prefers-reduced-motion` 降级

### 交互
- 答题层：点遮罩关闭、顶部进度条、A–D 选题、Enter 提交、Ctrl+Enter 提交解答题、Esc 关闭
- 主视图：数字键 1–4 切换；tab 支持 ←/→/Home/End
- 每日目标可切 3 / 5 / 8，存 `state.profile.dailyGoal`（随档案导出）
- 概念卡折叠状态直接显示「还差 N 道达标」
- 补练趋势新增最近一次变化量判断（继续下降 / 平台期 / 回升）

### 回归
```bash
python build-standalone.py && python build-deploy.py
node tools/smoke.js .    # 在 qingyou/ 目录执行：4 视图 + 目标切换 + 答题 + 快捷键
```
`tools/smoke.js` 是开发辅助（无浏览器 DOM 桩），不进部署包。

### 这轮没做
- 深色模式：CSS 仍有约 60 处硬编码浅色，直接加 `prefers-color-scheme` 会脏
- 生成题替换（第 11 节第 1 项仍是最高价值的内容工作）
- 归因阈值校准（需要真实使用数据）
