#!/usr/bin/env python3
"""把 deploy/ 发布到 GitHub 仓库（走 Contents API，不依赖 git 协议）。

用法：
  GITHUB_TOKEN=github_pat_xxx python3 publish.py [提交说明]

环境变量：
  GITHUB_TOKEN  GitHub Personal Access Token（需 Contents: Read and write）
  GITHUB_OWNER  仓库所有者，默认 wanzihaowan789-cmyk
  GITHUB_REPO   仓库名，默认 qingyou
"""

import base64
import json
import os
import sys
import urllib.error
import urllib.request

BASE = os.path.dirname(os.path.abspath(__file__))
DEPLOY = os.path.join(BASE, "deploy")
FILES = ["index.html", "style.css", "app.js", "data.core.js", "data.bulk.js", "README.txt"]
DEFAULT_MSG = "更新站点"


def api(token, path, method="GET", payload=None):
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=json.dumps(payload).encode() if payload else None,
        method=method,
    )
    req.add_header("Authorization", "Bearer " + token)
    req.add_header("Accept", "application/vnd.github+json")
    if payload:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=90) as resp:
            return resp.status, json.loads(resp.read().decode() or "{}")
    except urllib.error.HTTPError as err:
        return err.code, json.loads(err.read().decode() or "{}")


def main():
    token = os.environ.get("GITHUB_TOKEN", "").strip()
    if not token:
        print("缺少 GITHUB_TOKEN 环境变量")
        sys.exit(1)
    owner = os.environ.get("GITHUB_OWNER", "wanzihaowan789-cmyk")
    repo = os.environ.get("GITHUB_REPO", "qingyou")
    message = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_MSG

    published = []
    for name in FILES:
        path = os.path.join(DEPLOY, name)
        if not os.path.exists(path):
            print("跳过缺失文件：%s" % name)
            continue
        content = base64.b64encode(open(path, "rb").read()).decode()
        status, body = api(token, "/repos/%s/%s/contents/%s" % (owner, repo, name))
        payload = {"message": message + " · " + name, "content": content, "branch": "main"}
        if status == 200 and body.get("sha"):
            payload["sha"] = body["sha"]
        status, resp = api(token, "/repos/%s/%s/contents/%s" % (owner, repo, name), "PUT", payload)
        ok = status in (200, 201)
        print("%-14s %s %s" % (name, status, "ok" if ok else resp.get("message", "")))
        published.append(ok)

    if all(published):
        print("\n全部发布完成：https://%s.github.io/%s/" % (owner.lower(), repo))
        print("GitHub Pages 通常 1~3 分钟完成重建，期间可能短暂返回 404。")
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()