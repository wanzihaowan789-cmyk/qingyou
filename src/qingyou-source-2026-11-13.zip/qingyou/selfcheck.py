"""青柚学伴 · 全功能自检

用法：
  python3 selfcheck.py                          # 本地 deploy
  python3 selfcheck.py --url https://xxx --slow # 线上

输出每一项的结果，最后汇总失败列表。
"""

import argparse
import sys
import time

from playwright.sync_api import sync_playwright

EXE = "/root/.cache/ms-playwright/chromium-1243/chrome-linux/chrome"
DEFAULT_URL = "file:///workspace/qingyou/deploy/index.html"

RESULTS = []


def record(name, ok, detail=""):
    RESULTS.append((name, ok, detail))
    mark = "PASS" if ok else "FAIL"
    print(f"  [{mark}] {name}" + (" — " + detail if detail else ""))
    return ok


def run(name, fn):
    try:
        detail = fn()
        record(name, True, detail or "")
    except AssertionError as err:
        record(name, False, str(err)[:200])
    except Exception as err:  # noqa: BLE001
        record(name, False, f"{type(err).__name__}: {str(err)[:180]}")


def goto(page, url, slow):
    page.goto(url, timeout=180000 if slow else 40000, wait_until="load")
    page.wait_for_timeout(700 if slow else 350)
    try:
        page.wait_for_function(
            "() => window.QY_DATA && window.QY_DATA.items && window.QY_DATA.items.length >= 1815",
            timeout=90000 if slow else 20000)
    except Exception:
        pass


def reset(page):
    page.evaluate("localStorage.clear();")
    page.reload()
    page.wait_for_timeout(500)


def wait_full(page, timeout=20000):
    try:
        page.wait_for_function(
            "() => window.QY_DATA && window.QY_DATA.items.length >= 1815",
            timeout=timeout)
    except Exception:
        pass


# ---------------- 模块 1：加载与数据 ----------------
def check_load(page):
    ok = page.title() == "青柚学伴"
    assert ok, f"标题是 {page.title()!r}"
    return page.title()


def check_tabs(page):
    count = page.locator(".tab").count()
    assert count == 4, f"tab 数量 {count}"
    views = page.evaluate("[...document.querySelectorAll('.tab')].map(t=>t.getAttribute('data-view'))")
    assert views == ["today", "cards", "board", "profile"], views
    return "/".join(views)


def check_data(page):
    stats = page.evaluate("""() => ({
      items: window.QY_DATA.items.length,
      cards: window.QY_DATA.cards.length,
      kps: window.QY_DATA.knowledge.length,
      withExample: window.QY_DATA.cards.filter(c=>c.example).length,
      withAccept: window.QY_DATA.items.filter(i=>Array.isArray(i.accept)&&i.accept.length).length
    })""")
    assert stats["items"] == 1815, stats
    assert stats["cards"] == 76, stats
    assert stats["kps"] == 76, stats
    assert stats["withExample"] == 76, stats
    return f"{stats['items']} 题 / {stats['cards']} 卡 / 例题 {stats['withExample']} / 白名单 {stats['withAccept']}"


# ---------------- 模块 2：今日页 ----------------
def check_today(page):
    reset(page)
    page.locator('.tab[data-view="today"]').click()
    page.wait_for_timeout(400)
    streak = page.locator(".streak-card").count()
    assert streak == 1, f"连续学习卡 {streak}"
    return page.locator(".streak-goal").inner_text()


def check_today_start(page):
    btn = page.locator("button", has_text="开始今天的")
    assert btn.count() == 1, f"开练按钮 {btn.count()}"
    label = btn.inner_text()
    btn.click()
    page.wait_for_selector(".quiz-stem", timeout=8000)
    progress = page.locator("#quiz-progress").inner_text()
    page.keyboard.press("Escape")
    page.wait_for_timeout(300)
    assert "/ 5 题" in progress, progress
    return f"{label} → {progress}"


# ---------------- 模块 3：概念卡 ----------------
def check_cards_base(page):
    page.locator('.tab[data-view="cards"]').click()
    page.wait_for_timeout(400)
    count = page.locator(".card").count()
    assert count == 76, f"卡片 {count}"
    groups = page.locator(".chapter-title").count()
    assert groups >= 2, f"章节标题 {groups}"
    select_val = page.locator("#chapter-select").input_value()
    assert select_val == "", f"默认章节 {select_val}"
    return f"76 张 / {groups} 个章节分组"


def check_cards_search(page):
    page.locator(".card-search").click()
    for ch in ["定", "义", "域"]:
        page.keyboard.type(ch)
        page.wait_for_timeout(200)
        active = page.evaluate("document.activeElement && document.activeElement.id")
        assert active == "card-search", "输入时失焦"
    page.wait_for_timeout(400)
    count = page.locator(".card").count()
    assert count == 5, f"命中 {count}"
    marks = page.locator(".kw-hit").count()
    assert marks >= 5, f"高亮 {marks}"
    badge = page.locator("#card-toolbar-count").inner_text()
    assert "命中 5" in badge, badge
    return f"命中 5 张，高亮 {marks} 处"


def check_cards_favorite(page):
    page.locator("#fav-filter").click()
    page.wait_for_timeout(300)
    empty = page.locator("#card-results .empty-title").count()
    assert empty == 1, "无收藏时未显示空态"
    page.locator("button", has_text="清空搜索").click()
    page.wait_for_timeout(300)
    page.locator("#fav-filter").click()
    page.wait_for_timeout(300)
    page.locator(".card-favorite").first.click()
    page.wait_for_timeout(300)
    on = page.locator(".card-favorite.is-on").count()
    assert on == 1, f"收藏标记 {on}"
    title = page.locator(".card-title").first.inner_text().strip()
    page.reload()
    page.wait_for_timeout(700)
    wait_full(page)
    page.locator('.tab[data-view="cards"]').click()
    page.wait_for_timeout(400)
    page.locator("#fav-filter").click()
    page.wait_for_timeout(300)
    count = page.locator(".card").count()
    assert count == 1, f"刷新后收藏 {count}"
    assert page.locator(".card-title").inner_text().strip() == title, "收藏卡片不一致"
    page.locator("#fav-filter").click()
    page.wait_for_timeout(300)
    return f"收藏「{title}」持久化正常"


def check_cards_fold(page):
    summary = page.locator(".card-summary").first
    before = page.locator(".card-detail").first.is_visible()
    summary.click()
    page.wait_for_timeout(250)
    after = page.locator(".card-detail").first.is_visible()
    assert before != after, "折叠未切换"
    if after:
        summary.click()
        page.wait_for_timeout(200)
    return "展开/收起正常"


def check_cards_example(page):
    summary = page.locator(".card-summary").first
    summary.click()
    page.wait_for_timeout(300)
    btn = page.locator("button", has_text="看一道例题").first
    assert btn.count() == 1, "无例题按钮"
    btn.click()
    page.wait_for_timeout(300)
    visible = page.locator(".example-stack, .example-stem").count()
    assert visible >= 1, "例题未展开"
    return "例题可展开"


def check_cards_status(page):
    page.evaluate("""() => {
      const d = window.QY_DATA;
      const pl = JSON.parse(localStorage.getItem('qingyou_profiles_v1'));
      const at = new Date().toISOString();
      const byKp = {};
      for (const it of d.items) if (it.type !== 'solve') (byKp[it.kpId] = byKp[it.kpId] || []).push(it);
      const kps = ['K1.1','K1.2','K1.3'];
      const mk = (id, kp, stage, correct) => ({id, itemId:byKp[kp][0].id, kpId:kp, at, correct,
        layer: correct?'':'L0', ef:2.5, interval:1, dueAt:'2026-11-20', stage, reviews:0, streak:0, lastVariantId:''});
      const records = [mk('s1',kps[0],'new',false), mk('s2',kps[1],'scheduled',false), mk('s3',kps[2],'mastered',true)];
      localStorage.setItem('qingyou_state_v1:'+pl.active, JSON.stringify({version:1,profile:{},records,history:[]}));
    }""")
    page.reload()
    page.wait_for_timeout(700)
    wait_full(page)
    page.locator('.tab[data-view="cards"]').click()
    page.wait_for_timeout(400)
    todo = page.locator(".kp-status.is-todo").count()
    doing = page.locator(".kp-status.is-doing").count()
    done = page.locator(".kp-status.is-done").count()
    assert (todo, doing, done) == (1, 1, 1), f"{todo}/{doing}/{done}"
    return "待复习/复习中/已掌握各 1"


# ---------------- 模块 4：错题台 ----------------
SEED_BOARD = """() => {
  const d = window.QY_DATA;
  const pl = JSON.parse(localStorage.getItem('qingyou_profiles_v1'));
  const at = new Date().toISOString();
  const pad = n => String(n).padStart(2,'0');
  const day = o => { const t=new Date(); const x=new Date(t.getFullYear(),t.getMonth(),t.getDate()+o);
    return x.getFullYear()+'-'+pad(x.getMonth()+1)+'-'+pad(x.getDate()); };
  const byKp = {};
  for (const it of d.items) if (['fill','choice'].includes(it.type)) (byKp[it.kpId] = byKp[it.kpId] || []).push(it);
  const kps = Object.keys(byKp).filter(k => byKp[k].length >= 2).slice(0, 3);
  const records = [], history = [];
  let n = 0;
  const add = (kp, item, stage, due, layer) => { n+=1; records.push({id:'rb'+n, itemId:item, kpId:kp, at,
    correct: stage==='mastered', layer: layer||'', ef:2.5, interval:1, dueAt:due, stage, reviews:1, streak:0, lastVariantId:''}); };
  add(kps[0], byKp[kps[0]][0].id, 'new', day(-1), 'L1');
  add(kps[0], byKp[kps[0]][1].id, 'scheduled', day(2), 'L1');
  add(kps[1], byKp[kps[1]][0].id, 'new', day(0), 'L0');
  add(kps[2], byKp[kps[2]][0].id, 'mastered', day(5), '');
  history.push({id:'bh1', itemId:byKp[kps[0]][0].id, kpId:kps[0], at, correct:false, layer:'L1', hintUsed:false});
  history.push({id:'bh2', itemId:byKp[kps[0]][1].id, kpId:kps[0], at, correct:false, layer:'L1', hintUsed:false});
  localStorage.setItem('qingyou_state_v1:'+pl.active, JSON.stringify({version:1,profile:{},records,history}));
}"""


def check_board(page):
    reset(page)
    page.evaluate(SEED_BOARD)
    page.reload()
    page.wait_for_timeout(800)
    wait_full(page)
    page.locator('.tab[data-view="board"]').click()
    page.wait_for_timeout(500)
    cards = page.locator(".kp-board-card").count()
    assert cards == 3, f"聚合卡 {cards}"
    first_meta = page.locator(".kp-board-card").first.locator(".kp-board-meta").inner_text()
    assert "待复习 2 道" in first_meta, first_meta
    urgent = page.locator(".kp-urgent-list li").count()
    assert urgent == 2, f"最该先补 {urgent}"
    layer = page.locator(".kp-board-card").first.locator(".kp-board-layer").inner_text()
    assert "方法想不到" in layer, layer
    return f"3 个考点，排序与错因正确"


def check_board_detail(page):
    first = page.locator(".kp-board-card").first
    first.locator("button", has_text="道原题").click()
    page.wait_for_timeout(300)
    items = first.locator(".board-card").count()
    assert items == 2, f"展开原题 {items}"
    first.locator("button", has_text="收起原题").click()
    page.wait_for_timeout(200)
    return "原题可展开/收起"


def check_board_switch(page):
    page.locator(".board-mode-btn", has_text="按题目").click()
    page.wait_for_timeout(400)
    cols = page.locator(".board-column").count()
    assert cols == 3, f"看板列 {cols}"
    cards = page.locator(".board-card").count()
    assert cards == 4, f"看板卡 {cards}"
    page.locator(".board-mode-btn", has_text="按考点").click()
    page.wait_for_timeout(300)
    back = page.locator(".kp-board-card").count()
    assert back == 3, f"切回后 {back}"
    return "双视图切换正常"


def check_board_practice(page):
    page.locator(".kp-board-card").first.locator("button", has_text="练 2 道").click()
    page.wait_for_selector(".quiz-stem", timeout=8000)
    title = page.locator("#quiz-title").inner_text()
    page.keyboard.press("Escape")
    page.wait_for_timeout(300)
    return f"打开「{title}」的练习"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default=DEFAULT_URL)
    parser.add_argument("--slow", action="store_true")
    args = parser.parse_args()

    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=EXE)
        page = browser.new_page(viewport={"width": 1280, "height": 950})
        page.add_init_script("window.QY_DEBUG = true;")
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        t0 = time.time()
        goto(page, args.url, args.slow)
        load_ms = time.time() - t0

        print("== 1. 加载与数据 ==")
        run("页面标题", lambda: check_load(page))
        run("四个主导航", lambda: check_tabs(page))
        run("题库数据完整性", lambda: check_data(page))

        print("== 2. 今日页 ==")
        run("连续学习卡", lambda: check_today(page))
        run("今日开练入口", lambda: check_today_start(page))

        print("== 3. 概念卡 ==")
        run("默认 76 张与章节分组", lambda: check_cards_base(page))
        run("实时搜索与高亮", lambda: check_cards_search(page))
        run("收藏与持久化", lambda: check_cards_favorite(page))
        run("卡片折叠", lambda: check_cards_fold(page))
        run("例题展开", lambda: check_cards_example(page))
        run("掌握状态徽章", lambda: check_cards_status(page))

        print("== 4. 错题台 ==")
        run("按考点聚合", lambda: check_board(page))
        run("展开原题", lambda: check_board_detail(page))
        run("双视图切换", lambda: check_board_switch(page))
        run("进错题练习", lambda: check_board_practice(page))

        record("首屏加载时间", load_ms < 60, f"{load_ms:.1f}s（含等待题库）")
        record("控制台无报错", not errors, str(errors[:2]))

        browser.close()

    total = len(RESULTS)
    passed = sum(1 for _, ok, _ in RESULTS if ok)
    print(f"\n=== {passed}/{total} 通过 ===")
    if passed != total:
        print("失败项：")
        for name, ok, detail in RESULTS:
            if not ok:
                print(f"  - {name}: {detail}")
    sys.exit(0 if passed == total else 1)


if __name__ == "__main__":
    main()