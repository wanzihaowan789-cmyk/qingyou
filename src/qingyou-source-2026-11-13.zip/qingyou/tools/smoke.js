#!/usr/bin/env node
/**
 * 无浏览器冒烟测试：用极简 DOM 桩加载 data.js + app.js，
 * 然后模拟四个 tab 点击、每日目标切换、开启答题、按 A 键选题、
 * 提交答案，确认没有运行期异常。
 *
 * 用法：node tools/smoke.js <项目目录>
 */
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const BASE = process.argv[2] || path.join(__dirname, '..');

/* ---------------- 极简 DOM ---------------- */

class ClassList {
  constructor() { this.set = new Set(); }
  add() { for (const c of arguments) this.set.add(c); }
  remove() { for (const c of arguments) this.set.delete(c); }
  toggle(c, force) {
    if (force === undefined) {
      if (this.set.has(c)) this.set.delete(c); else this.set.add(c);
    } else if (force) {
      this.set.add(c);
    } else {
      this.set.delete(c);
    }
    return this.set.has(c);
  }
  contains(c) { return this.set.has(c); }
}

class Node {
  constructor(tag) {
    this.tagName = String(tag).toUpperCase();
    this.children = [];
    this.parentNode = null;
    this.classList = new ClassList();
    this.style = {};
    this.attrs = {};
    this._text = '';
    this.hidden = false;
    this.disabled = false;
    this.value = '';
    this.files = [];
    this._handlers = {};
  }
  set className(v) {
    this._className = String(v);
    this.classList = new ClassList();
    this._className.split(/\s+/).filter(Boolean).forEach((c) => this.classList.add(c));
  }
  get className() { return this._className || ''; }
  set id(v) { this.attrs.id = String(v); }
  get id() { return this.attrs.id || ''; }
  set textContent(v) { this._text = String(v); this.children = []; }
  get textContent() {
    return this._text + this.children.map((c) => c.textContent).join('');
  }
  appendChild(node) { node.parentNode = this; this.children.push(node); return node; }
  insertBefore(node) { node.parentNode = this; this.children.unshift(node); return node; }
  removeChild(node) { this.children = this.children.filter((n) => n !== node); return node; }
  setAttribute(k, v) { this.attrs[k] = String(v); }
  getAttribute(k) { return Object.prototype.hasOwnProperty.call(this.attrs, k) ? this.attrs[k] : null; }
  removeAttribute(k) { delete this.attrs[k]; }
  addEventListener(type, fn) { (this._handlers[type] || (this._handlers[type] = [])).push(fn); }
  removeEventListener() {}
  dispatch(type, extra) {
    const event = Object.assign({ type, target: this, currentTarget: this, preventDefault() {}, stopPropagation() {} }, extra || {});
    (this._handlers[type] || []).forEach((fn) => fn.call(this, event));
  }
  focus() {}
  click() { this.dispatch('click'); }
  scrollIntoView() {}
  querySelector(sel) { return findOne(this, sel); }
  querySelectorAll(sel) { return findAll(this, sel); }
}

function parseSelector(sel) {
  const out = { tag: null, classes: [], attrs: [] };
  const m = /^([a-zA-Z0-9]*)((?:[.#][\w-]+|\[[^\]]+\])*)$/.exec(sel.trim());
  if (!m) return out;
  if (m[1]) out.tag = m[1].toUpperCase();
  const rest = m[2] || '';
  const re = /([.#])([\w-]+)|\[([\w-]+)(?:=["']?([^"'\]]*)["']?)?\]/g;
  let hit;
  while ((hit = re.exec(rest))) {
    if (hit[1] === '.') out.classes.push(hit[2]);
    else if (hit[1] === '#') out.attrs.push(['id', hit[2]]);
    else out.attrs.push([hit[3], hit[4] === undefined ? null : hit[4]]);
  }
  return out;
}

function matches(node, sel) {
  const q = parseSelector(sel);
  if (q.tag && node.tagName !== q.tag) return false;
  for (const c of q.classes) if (!node.classList.contains(c)) return false;
  for (const [k, v] of q.attrs) {
    const val = node.getAttribute(k);
    if (val === null) return false;
    if (v !== null && val !== v) return false;
  }
  return true;
}

function walk(node, sel, out) {
  for (const child of node.children) {
    if (matches(child, sel)) out.push(child);
    walk(child, sel, out);
  }
  return out;
}

function findOne(root, sel) { return walk(root, sel, [])[0] || null; }
function findAll(root, sel) { return walk(root, sel, []); }

/* ---------------- 文档树 ---------------- */

const byId = {};
const body = new Node('body');

function make(tag, id, attrs) {
  const n = new Node(tag);
  if (id) n.id = id;
  Object.assign(n.attrs, attrs || {});
  if (id) byId[id] = n;
  body.appendChild(n);
  return n;
}

const tabs = ['today', 'cards', 'board', 'profile'].map((v) => {
  const n = make('button', 'tab-' + v, { 'data-view': v });
  n.className = 'tab' + (v === 'today' ? ' is-active' : '');
  return n;
});

const views = ['today', 'cards', 'board', 'profile'].map((v) => {
  const n = make('section', 'view-' + v, { 'data-view': v });
  n.className = 'view' + (v === 'today' ? ' is-active' : '');
  return n;
});

['today-content', 'cards-guide', 'card-list', 'board-content', 'profile-content',
  'cards-notice', 'toast', 'quiz-title', 'quiz-progress', 'quiz-body',
  'export-btn', 'import-btn', 'import-file', 'import-bank-btn', 'import-bank-file',
  'seed-btn'].forEach((id) => make('div', id));

const quizModal = make('div', 'quiz-modal');
quizModal.hidden = true;
make('button', 'quiz-close');

/* 用闭包存监听器：vm 上下文里 this 可能被包装，不能依赖 this */
const docHandlers = {};

const documentStub = {
  body,
  documentElement: body,
  _handlers: docHandlers,
  addEventListener(type, fn) {
    (docHandlers[type] || (docHandlers[type] = [])).push(fn);
  },
  dispatch(type, extra) {
    const event = Object.assign({ type, target: body, preventDefault() {}, stopPropagation() {} }, extra || {});
    (docHandlers[type] || []).forEach((fn) => fn(event));
    (body._handlers[type] || []).forEach((fn) => fn(event));
  },
  getElementById(id) {
    if (byId[id]) return byId[id];
    /* 动态创建后挂到 body 上的节点（如 card-results）也要能查到 */
    return findOne(body, '#' + id);
  },
  createElement(tag) { return new Node(tag); },
  createTextNode(text) { const n = new Node('#text'); n._text = String(text); return n; },
  createDocumentFragment() { return new Node('fragment'); },
  querySelector(sel) {
    if (sel === '.tab.is-active') return tabs.find((t) => t.classList.contains('is-active')) || null;
    if (sel.indexOf('.tab') === 0) return tabs.find((t) => matches(t, sel)) || null;
    if (sel.indexOf('.view') === 0) return views.find((v) => matches(v, sel)) || null;
    return findOne(body, sel);
  },
  querySelectorAll(sel) {
    if (sel === '.tab') return tabs.slice();
    if (sel === '.view') return views.slice();
    return findAll(body, sel);
  }
};

const store = {};
const windowStub = {
  document: documentStub,
  localStorage: {
    getItem(k) { return Object.prototype.hasOwnProperty.call(store, k) ? store[k] : null; },
    setItem(k, v) { store[k] = String(v); },
    removeItem(k) { delete store[k]; }
  },
  setTimeout(fn) { return 0; },
  clearTimeout() {},
  addEventListener() {},
  documentElement: body,
  location: { href: 'http://localhost/' }
};
windowStub.window = windowStub;

const sandbox = Object.assign(Object.create(null), {
  window: windowStub,
  document: documentStub,
  localStorage: windowStub.localStorage,
  setTimeout: windowStub.setTimeout,
  clearTimeout: windowStub.clearTimeout,
  console,
  Math,
  Date,
  JSON,
  String,
  Number,
  Array,
  Object,
  RegExp,
  parseInt,
  parseFloat,
  isNaN,
  Blob: function Blob() {},
  URL: { createObjectURL() { return ''; }, revokeObjectURL() {} },
  FileReader: function FileReader() {},
  SVG_NS: 'http://www.w3.org/2000/svg'
});

vm.createContext(sandbox);

function run(file, transform) {
  let code = fs.readFileSync(path.join(BASE, file), 'utf8');
  if (transform) code = transform(code);
  vm.runInContext(code, sandbox, { filename: file });
}

const errors = [];
function step(name, fn) {
  try {
    fn();
    console.log('  OK   ' + name);
  } catch (err) {
    errors.push(name + ' -> ' + err.message);
    console.log('  FAIL ' + name + ' -> ' + err.message);
  }
}

console.log('加载 data.js + app.js');
run('data.js');
run('app.js');

console.log('检查初始化结果');
step('app 已挂载', () => {
  if (!sandbox.window.__QY_APP_LOADED) throw new Error('__QY_APP_LOADED 未设置');
});
step('今日页已渲染', () => {
  const host = byId['today-content'];
  if (!host.children.length) throw new Error('today-content 为空');
});
step('每日目标已渲染', () => {
  const host = byId['today-content'];
  if (!findOne(host, '.goal-row')) throw new Error('缺少 goal-row');
});
step('连续学习卡存在', () => {
  if (!findOne(byId['today-content'], '.streak-card')) throw new Error('缺少 streak-card');
});

console.log('切换四个视图');
for (const v of ['cards', 'board', 'profile', 'today']) {
  step('切到 ' + v, () => {
    const tab = tabs.find((t) => t.getAttribute('data-view') === v);
    tab.dispatch('click');
    const view = views.find((x) => x.getAttribute('data-view') === v);
    if (!view.classList.contains('is-active')) throw new Error('视图未激活');
  });
}

step('概念卡已渲染且带达标提示', () => {
  const host = byId['card-list'];
  if (!host.children.length) throw new Error('card-list 为空');
  if (!findOne(host, '.card-goal-chip')) throw new Error('缺少 card-goal-chip');
});

step('画像页已渲染', () => {
  const host = byId['profile-content'];
  if (!host.children.length) throw new Error('profile-content 为空');
});

step('切换每日目标到 8 题', () => {
  const chips = findAll(byId['today-content'], '.goal-chip');
  const target = chips.find((c) => c.textContent.indexOf('8') === 0);
  if (!target) throw new Error('找不到 8 题 chip');
  target.dispatch('click');
  const stateKey = Object.keys(store).filter((k) => k.indexOf('qingyou_state_v1') === 0)[0];
  const stored = JSON.parse(store[stateKey] || '{}');
  if (!stored.profile || stored.profile.dailyGoal !== 8) {
    throw new Error('dailyGoal 未写入，key=' + stateKey + ' profile=' + JSON.stringify(stored.profile));
  }
});

step('打开答题弹层并答题', () => {
  const start = findOne(byId['today-content'], '.streak-cta') ||
    findOne(byId['today-content'], '.review-card');
  if (!start) throw new Error('没有可点的开始按钮');
  start.dispatch('click');
  if (quizModal.hidden) throw new Error('弹层未打开');
  const bodyNode = byId['quiz-body'];
  if (!bodyNode.children.length) throw new Error('quiz-body 为空');
  const bar = findOne(bodyNode, '.quiz-progressbar');
  if (!bar) throw new Error('缺少进度条');
});

step('A 键选题 + Enter 提交', () => {
  const option = findOne(byId['quiz-body'], '.option-btn');
  if (!option) {
    const input = findOne(byId['quiz-body'], '#quiz-answer-input');
    if (!input) throw new Error('既没有选项也没有输入框');
    input.value = '1';
    input.dispatch('keydown', { key: 'Enter' });
    return;
  }
  /* 全局快捷键走 document 层，模拟真实按键 */
  documentStub.dispatch('keydown', { key: 'a' });
  const first = findOne(byId['quiz-body'], '.option-btn');
  if (!first.classList.contains('is-selected')) throw new Error('A 键没有选中第一个选项');
  documentStub.dispatch('keydown', { key: 'Enter' });
  if (!findOne(byId['quiz-body'], '.quiz-result')) throw new Error('Enter 没有触发判卷');
});

step('Esc 关闭答题层，数字键 4 切到画像页', () => {
  documentStub.dispatch('keydown', { key: 'Escape' });
  if (!quizModal.hidden) throw new Error('Esc 没有关闭答题层');
  documentStub.dispatch('keydown', { key: '4' });
  const view = views.find((v) => v.getAttribute('data-view') === 'profile');
  if (!view.classList.contains('is-active')) throw new Error('数字键切换失败');
});

console.log('');
if (errors.length) {
  console.log('失败 ' + errors.length + ' 项：');
  errors.forEach((e) => console.log('  - ' + e));
  process.exit(1);
}
console.log('全部通过');