﻿# 青柚学伴 · 发布到 GitHub Pages
# 用法：
#   $env:GITHUB_TOKEN = "github_pat_xxx"      # Contents: Read and write
#   powershell -ExecutionPolicy Bypass -File .\publish.ps1 "本次改动说明"
#
# 注意：只推送 deploy/ 里的 6 个文件到仓库根，源码资产不会上传。
#       需要源码备份请用 git（见 HANDOFF.md 第 12 节）。
param([string]$Message = '更新站点')

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

if (-not $env:GITHUB_TOKEN) {
    Write-Host '缺少 GITHUB_TOKEN。' -ForegroundColor Yellow
    Write-Host '1) GitHub → Settings → Developer settings → Personal access tokens'
    Write-Host '2) 勾选 Contents: Read and write，生成 token'
    Write-Host '3) 执行：$env:GITHUB_TOKEN = "github_pat_xxx"'
    exit 1
}

if (-not (Test-Path (Join-Path $PSScriptRoot 'deploy\index.html'))) {
    Write-Host 'deploy/ 不完整，先跑 build.ps1' -ForegroundColor Yellow
    exit 1
}

python publish.py $Message