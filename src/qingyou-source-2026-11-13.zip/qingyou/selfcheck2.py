"""青柚学伴 · 全功能自检（下）：答题 / 画像与档案 / 归因与干预 / 布局"""

import argparse
import sys

from playwright.sync_api import sync_playwright

EXE = "/root/.cache/ms-playwright/chromium-1243/chrome-linux/chrome"
DEFAULT_URL = "file:///workspace/qingyou/deploy/index.html"
RESULTS = []


def record(name, ok, detail=""):
    RESULTS.append((name, ok, detail))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (" — " + detail if detail else ""))


def run(name, fn):
    try:
        record(name, True, fn() or "")
    except AssertionError as err:
        record(name, False, str(err)[:200])
    except Exception as err:  # noqa: BLE001
        record(name, False, f"{type(err).__name__}: {str(err)[:180]}")


def wait_full(page, timeout=25000):
    try:
        page.wait_for_function(
            "() => window.QY_DATA && window.QY_DATA.items.length >= 1815", timeout=timeout)
    except Exception:
        pass


def reset(page, url_loaded=False):
    page.evaluate("localStorage.clear();")
    page.reload()
    page.wait_for_timeout(600)


# ---------------- 答题 ----------------
def open_quiz(page, kp_search="定义域"):
    page.locator('.tab[data-view="cards"]').click()
    page.wait_for_selector(".card", timeout=15000)
    page.wait_for_timeout(300)
    page.locator("#card-search").fill(kp_search)
    page.wait_for_timeout(450)
    page.locator(".card-summary").first.click()
    page.wait_for_timeout(250)
    page.locator("button", has_text="去练 2 道").first.click()
    page.wait_for_selector(".quiz-stem", timeout=10000)
    page.wait_for_timeout(400)


def close_quiz(page):
    page.keyboard.press("Escape")
    page.wait_for_timeout(300)


def check_quiz_choice(page):
    reset(page)
    open_quiz(page)
    has_options = page.locator(".option-btn").count() > 0
    if not has_options:
        page.locator("#quiz-answer-input").fill("1")
    else:
        page.locator(".option-btn").first.click()
    page.locator("button", has_text="提交答案").click()
    page.wait_for_timeout(600)
    result = page.locator(".quiz-result").count()
    assert result == 1, "提交后无结果区"
    verdict = page.locator(".quiz-verdict").count()
    close_quiz(page)
    return f"{'选择题' if has_options else '填空题'}判定正常（verdict {verdict}）"


def check_quiz_hint(page):
    open_quiz(page)
    btn = page.locator("button", has_text="看提示")
    assert btn.count() == 1, "无提示按钮"
    btn.click()
    page.wait_for_timeout(300)
    hidden = page.locator(".quiz-hint").is_visible()
    assert hidden, "提示未展开"
    text = page.locator(".quiz-hint").inner_text()
    close_quiz(page)
    assert len(text) > 10, text
    return "提示可展开且有内容"


def check_quiz_layer(page):
    open_quiz(page)
    if page.locator(".option-btn").count() > 0:
        page.locator(".option-btn").last.click()
    else:
        page.locator("#quiz-answer-input").fill("999")
    page.locator("button", has_text="提交答案").click()
    page.wait_for_timeout(700)
    # 填空题会先问“你写的答案算对吗”，点“我答错了”才展开错因
    if page.locator(".layer-btn:visible").count() == 0 and page.locator("button", has_text="我答错了").count() > 0:
        page.locator("button", has_text="我答错了").click()
        page.wait_for_timeout(400)
    visible = page.locator(".layer-btn:visible").count()
    assert visible == 5, f"可见错因按钮 {visible}"
    labels = page.locator(".layer-btn-label").count()
    hints = page.locator(".layer-btn-hint").count()
    assert labels == 5 and hints == 5, f"{labels}/{hints}"
    page.locator(".layer-btn").first.click(force=True)
    page.wait_for_timeout(500)
    done = page.locator(".quiz-done").count()
    assert done == 1, f"记录提示 {done}"
    close_quiz(page)
    return f"5 个错因带说明，记录成功"


def check_quiz_math(page):
    rendered = page.evaluate("""() => {
      const box = document.createElement('div');
      box.appendChild(window.QY_MATH('f(x)=1/x，√(2x−6)，8^(2/3)'));
      return { frac: box.querySelectorAll('.math-frac').length,
               sqrt: box.querySelectorAll('.math-sqrt').length,
               sup: box.querySelectorAll('sup').length };
    }""")
    assert rendered["frac"] == 2 and rendered["sqrt"] == 1 and rendered["sup"] == 1, rendered
    return "分数/根号/上标各 1 处"


def check_quiz_equiv(page):
    cases = [
        ("(1,3]", "1<x≤3", True),
        ("x>1", "(1,+∞)", True),
        ("{2,4}", "{4,2}", True),
        ("1/2", "0.5", True),
        ("(1,3]", "[1,3]", False),
        ("1/2", "0.4", False),
    ]
    bad = []
    for answer, user, expect in cases:
        got = page.evaluate(
            "([a,u]) => window.QY_ANSWER.correct({answer:a, type:'fill'}, u)", [answer, user])
        if got != expect:
            bad.append(f"{answer}⇐{user}")
    assert not bad, ", ".join(bad)
    return "6 组等价/防误伤"


# ---------------- 画像与档案 ----------------
def check_profile_archive(page):
    reset(page)
    page.locator('.tab[data-view="profile"]').click()
    page.wait_for_timeout(500)
    assert page.locator(".profile-switcher").count() == 1, "无档案卡"
    page.once("dialog", lambda d: d.accept("妹妹"))
    page.locator("button", has_text="新建档案").click()
    page.wait_for_timeout(700)
    chips = [c.strip() for c in page.locator(".profile-chip").all_inner_texts()]
    assert len(chips) == 2 and "妹妹" in chips, chips
    # 切回默认档案
    page.locator(".profile-chip").first.click()
    page.wait_for_timeout(600)
    active = page.locator(".profile-chip.is-active").inner_text().strip()
    assert active != "妹妹", active
    return f"档案：{'、'.join(chips)}，可切换"


def check_profile_report(page):
    assert page.locator(".report-hero").count() == 1 or page.locator(".empty-state").count() >= 1
    return "报告或空态存在"


BUILD_CONCEPT = """(mode) => {
  const d = window.QY_DATA;
  const pl = JSON.parse(localStorage.getItem('qingyou_profiles_v1'));
  const at = new Date().toISOString();
  const COND = /定义域|值域|取值范围|范围|条件|恒成立|存在|唯一|至少|至多/;
  const pick = (fn, n) => d.items.filter(fn).slice(0, n);
  const conceptItems = pick(i => i.level===1 && (i.type==='choice'||i.type==='judge') && !COND.test(i.stem), 8);
  const fillItems = pick(i => i.type==='fill' && i.level===1 && !COND.test(i.stem), 8);
  let hid = 0;
  const H = (item, correct, extra) => { hid+=1; return Object.assign({ id:'hz_'+hid, itemId:item.id,
    kpId:item.kpId, at, correct, layer: correct?'':'L0', hintUsed:false, ms:20000, answer:'',
    qtype:item.type, qlevel:item.level||1 }, extra||{}); };
  const history = [];
  conceptItems.forEach((it, i) => history.push(H(it, false, {hintUsed: i<6, ms:45000})));
  history.push(H(fillItems[0], false));
  history.push(H(fillItems[1], false));
  localStorage.setItem('qingyou_state_v1:'+pl.active,
    JSON.stringify({version:1, profile:{}, records:[], history, intervention:null, interventionHistory:[]}));
  return history.length;
}"""


def check_attribution(page):
    page.evaluate(BUILD_CONCEPT, "concept")
    page.reload()
    page.wait_for_timeout(800)
    wait_full(page)
    page.locator('.tab[data-view="profile"]').click()
    page.wait_for_timeout(600)
    blocks = page.locator(".reason-block").count()
    primary = page.locator(".reason-block.is-primary").count()
    title = page.locator(".reason-title").first.inner_text()
    evidence = page.locator(".reason-evidence li").count()
    assert blocks >= 1 and primary == 1, f"{blocks}/{primary}"
    assert "概念" in title, title
    assert evidence >= 2, f"证据 {evidence}"
    return f"主因「{title}」，{blocks} 条原因，{evidence} 条证据"


def check_intervention(page):
    page.locator(".reason-block.is-primary .btn").click()
    page.wait_for_timeout(700)
    itv = page.evaluate("""() => {
      const pl = JSON.parse(localStorage.getItem('qingyou_profiles_v1'));
      const st = JSON.parse(localStorage.getItem('qingyou_state_v1:'+pl.active));
      return st.intervention;
    }""")
    assert itv and itv["status"] == "active" and itv["baseline"] > 0, itv
    return f"基线 {itv['baseline']}，状态 {itv['status']}"


def check_intervention_compare(page):
    page.evaluate("""() => {
      const pl = JSON.parse(localStorage.getItem('qingyou_profiles_v1'));
      const key = 'qingyou_state_v1:'+pl.active;
      const st = JSON.parse(localStorage.getItem(key));
      st.intervention = { key:'concept', title:'概念没建立', startedAt:new Date().toISOString(),
        baseline:116, results:[{correct:true},{correct:true},{correct:false}], status:'done', afterScore:48,
        finishedAt:new Date().toISOString() };
      st.interventionHistory = [
        {key:'concept',title:'概念没建立',baseline:116,afterScore:48,total:3,correct:2},
        {key:'concept',title:'概念没建立',baseline:116,afterScore:30,total:3,correct:3}
      ];
      localStorage.setItem(key, JSON.stringify(st));
    }""")
    page.reload()
    page.wait_for_timeout(900)
    wait_full(page)
    page.locator('.tab[data-view="profile"]').click()
    page.wait_for_timeout(600)
    assert page.locator(".intervention").count() == 1, "无补练对比卡"
    values = page.locator(".compare-value").all_inner_texts()
    assert values == ["116", "48"], values
    verdict = page.locator(".intervention-verdict").inner_text()
    assert "下降" in verdict, verdict
    assert page.locator(".trend-card").count() == 1, "无趋势卡"
    points = page.evaluate(
        "document.querySelector('.trend-svg polyline').getAttribute('points').trim().split(/\\s+/).length")
    assert points == 3, f"折线点 {points}"
    return f"对比 116→48，趋势 {points} 个点"


# ---------------- 布局与数据 ----------------
def check_layout(page, label):
    sw = page.evaluate("document.documentElement.scrollWidth")
    vw = page.evaluate("window.innerWidth")
    assert sw <= vw + 1, f"{label} 溢出 {sw}>{vw}"
    return f"{vw}px 无溢出"


def check_export_name(page):
    page.locator('.tab[data-view="profile"]').click()
    page.wait_for_timeout(400)
    text = page.locator("#export-btn").inner_text()
    assert text == "导出当前档案", text
    return text


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default=DEFAULT_URL)
    parser.add_argument("--slow", action="store_true")
    args = parser.parse_args()

    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=EXE)
        page = browser.new_page(viewport={"width": 1280, "height": 950})
        page.add_init_script("window.QY_DEBUG = true;")
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.goto(args.url, timeout=180000 if args.slow else 40000, wait_until="load")
        page.wait_for_timeout(800)
        wait_full(page)

        print("== 5. 答题流程 ==")
        run("提交与判定", lambda: check_quiz_choice(page))
        run("提示功能", lambda: check_quiz_hint(page))
        run("错因选择", lambda: check_quiz_layer(page))
        run("数学排版渲染", lambda: check_quiz_math(page))
        run("等价答案判定", lambda: check_quiz_equiv(page))

        print("== 6. 画像 / 档案 / 归因 / 干预 ==")
        run("学习档案新建与切换", lambda: check_profile_archive(page))
        run("成绩归因", lambda: check_attribution(page))
        run("干预基线", lambda: check_intervention(page))
        run("干预对比与趋势", lambda: check_intervention_compare(page))
        run("导出按钮文案", lambda: check_export_name(page))

        print("== 7. 布局 ==")
        run("桌面 1280", lambda: check_layout(page, "桌面"))
        page.set_viewport_size({"width": 768, "height": 900})
        page.wait_for_timeout(400)
        run("平板 768", lambda: check_layout(page, "平板"))
        page.set_viewport_size({"width": 375, "height": 812})
        page.wait_for_timeout(400)
        run("手机 375", lambda: check_layout(page, "手机"))

        record("控制台无报错", not errors, str(errors[:2]))
        browser.close()

    total = len(RESULTS)
    passed = sum(1 for _, ok, _ in RESULTS if ok)
    print(f"\n=== {passed}/{total} 通过 ===")
    if passed != total:
        print("失败项：")
        for name, ok, detail in RESULTS:
            if not ok:
                print(f"  - {name}: {detail}")
    sys.exit(0 if passed == total else 1)


if __name__ == "__main__":
    main()