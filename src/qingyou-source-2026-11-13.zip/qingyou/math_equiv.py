#!/usr/bin/env python3
"""青柚学伴 · 答案等价规则（Python 侧）

与 app.js 里的 normalizeAnswer / answerCandidates 保持一致，
供 audit-items.py 做答案校验、build-data.py 生成 accept 白名单。
"""

import re
from fractions import Fraction

INF_POS = "+∞"
INF_NEG = "-∞"

_CN_WORDS = [
    ("不等于", "≠"),
    ("大于等于", "≥"),
    ("小于等于", "≤"),
    ("不小于", "≥"),
    ("不大于", "≤"),
    ("正无穷大", INF_POS),
    ("正无穷", INF_POS),
    ("+无穷", INF_POS),
    ("负无穷大", INF_NEG),
    ("负无穷", INF_NEG),
    ("-无穷", INF_NEG),
    ("无穷大", "∞"),
    ("无穷", "∞"),
    ("大于", ">"),
    ("小于", "<"),
]

_SYMBOL_MAP = str.maketrans({
    "−": "-", "–": "-", "—": "-", "－": "-",
    "×": "*", "✕": "*", "✖": "*",
    "÷": "/",
    "≥": "≥", "≤": "≤",
    "，": ",", "、": ",", "；": ";", "：": ":",
    "（": "(", "）": ")",
    "［": "[", "］": "]",
})

_INTERVAL_RE = re.compile(r"^([\[(])([^,]+),([^\]\)]+)([\]\)])$")
_NUM = r"-?\d+(?:\.\d+)?"


def norm(value):
    """归一化：中文符号转数学符号、去空白、统一全角半角。"""
    text = "" if value is None else str(value)
    text = text.strip().lower()
    for word, symbol in _CN_WORDS:
        text = text.replace(word, symbol)
    text = text.translate(_SYMBOL_MAP)
    text = text.replace(">=", "≥").replace("<=", "≤")
    text = re.sub(r"空\s*集", "∅", text)
    text = re.sub(r"\s+", "", text)
    if text == "{}":
        text = "∅"
    return text


def _interval_to_inequalities(text):
    """(1,3] → 1<x≤3 / 3≥x>1；[2,+∞) → x≥2。"""
    match = _INTERVAL_RE.match(text)
    if not match:
        return []
    left, low, high, right = match.groups()
    low_inf = low == INF_NEG
    high_inf = high in (INF_POS, "∞")
    if low_inf and high_inf:
        return []
    if low_inf:
        return ["x" + ("≤" if right == "]" else "<") + high]
    if high_inf:
        return ["x" + ("≥" if left == "[" else ">") + low]
    return [
        low + ("≤" if left == "[" else "<") + "x" + ("≤" if right == "]" else "<") + high,
        high + ("≥" if right == "]" else ">") + "x" + ("≥" if left == "[" else ">") + low,
    ]


def _inequality_to_intervals(text):
    """x>1 → (1,+∞)；a<x≤b → (a,b]。"""
    out = []
    single = re.match(r"^x([<>≤≥])(.+)$", text)
    if single:
        sign, value = single.groups()
        if re.match(r"^" + _NUM + r"$", value):
            if sign == ">":
                out.append("(" + value + ",+∞)")
            elif sign == "≥":
                out.append("[" + value + ",+∞)")
            elif sign == "<":
                out.append("(-∞," + value + ")")
            else:
                out.append("(-∞," + value + "]")
        return out

    double = re.match(r"^(.+?)([<>≤≥])x([<>≤≥])(.+)$", text)
    if double:
        low, sign_low, sign_high, high = double.groups()
        out.append(
            ("(" if sign_low == "<" else "[") + low + "," + high +
            (")" if sign_high == "<" else "]"))
        return out

    num_left = re.match(r"^(" + _NUM + r")([<>≤≥])x$", text)
    if num_left:
        bound, cmp_symbol = num_left.groups()
        if cmp_symbol == "<":
            out.append("(" + bound + ",+∞)")
        elif cmp_symbol == "≤":
            out.append("[" + bound + ",+∞)")
        elif cmp_symbol == ">":
            out.append("(-∞," + bound + ")")
        else:
            out.append("(-∞," + bound + "]")
    return out


def _sorted_set(text):
    if not (text.startswith("{") and text.endswith("}")):
        return None
    inner = text[1:-1]
    if not inner or "|" in inner or re.search(r"[x≠<>≤≥]", inner):
        return None
    parts = [part for part in inner.split(",") if part]
    if len(parts) < 2:
        return None
    return "{" + ",".join(sorted(parts)) + "}"


def forms(value):
    """返回该答案的所有等价写法（含自身）。"""
    base = norm(value)
    out = {base} if base else set()

    if base in ("∅", "{}"):
        out |= {"∅", "{}", "空集"}

    if "∞" in base:
        out.add(base.replace(INF_POS, "∞"))
        out.add(base.replace("∞", INF_POS).replace("++", "+"))

    if base.startswith("{") and base.endswith("}"):
        stripped = base[1:-1]
        out.add(stripped)
        no_domain = re.sub(r"^x[|:]", "", stripped)
        if no_domain != stripped:
            out.add(no_domain)
        sorted_set = _sorted_set(base)
        if sorted_set:
            out.add(sorted_set)
            out.add(sorted_set[1:-1])

    for form in _interval_to_inequalities(base):
        out.add(form)
    for form in _inequality_to_intervals(base):
        out.add(form)

    return {form for form in out if form}


def _as_fraction(text):
    try:
        return Fraction(norm(text))
    except (ValueError, ZeroDivisionError, TypeError):
        return None


def values_equal(expected, actual):
    """数值等价（1/2 == 0.5）或数学写法等价（(1,3] == 1<x≤3）。"""
    left_value = _as_fraction(expected)
    right_value = _as_fraction(actual)
    if left_value is not None and right_value is not None:
        return left_value == right_value
    return bool(forms(expected) & forms(actual))


def accept_list(answer, limit=6):
    """给题库写 accept 用的额外等价写法（不含标准答案本身）。"""
    base = norm(answer)
    extras = []
    for form in sorted(forms(answer)):
        if form != base and form not in extras:
            extras.append(form)
    return extras[:limit]