﻿# 青柚学伴 · 一键构建 + 回归
# 用法：powershell -ExecutionPolicy Bypass -File .\build.ps1
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

Write-Host '[1/3] 生成单文件版（双击即开）...' -ForegroundColor Cyan
python build-standalone.py

Write-Host '[2/3] 生成线上分包（deploy/）...' -ForegroundColor Cyan
python build-deploy.py

Write-Host '[3/3] 无浏览器回归测试 ...' -ForegroundColor Cyan
node tools/smoke.js .

Write-Host ''
Write-Host '完成。deploy/ 6 个文件与 qingyou-standalone.html 已更新。' -ForegroundColor Green
Write-Host '本地预览：powershell -ExecutionPolicy Bypass -File .\serve.ps1'