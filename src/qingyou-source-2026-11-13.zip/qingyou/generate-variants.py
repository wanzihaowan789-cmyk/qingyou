#!/usr/bin/env python3
"""按考点参数化生成同类型变式题，答案由程序计算，解析写成可读的步骤。

用法：
  python3 generate-variants.py --per-kp 30 --seed 20261111
  python3 validate-items.py content/zz-generated.json
  python3 build-data.py
  python3 build-standalone.py
"""

import argparse
import glob
import json
import math
import os
import random
from fractions import Fraction

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "content", "zz-generated.json")

QUADRANTS = {1: "第一象限", 2: "第二象限", 3: "第三象限", 4: "第四象限"}
SUBSCRIPT = {"2": "₂", "3": "₃", "4": "₄", "5": "₅", "10": "₁₀"}


def signed(value):
    return ("+" if value >= 0 else "−") + str(abs(value))


def quad_expr(b, c):
    text = "x²"
    if b:
        text += ("+" if b > 0 else "−") + ("" if abs(b) == 1 else str(abs(b))) + "x"
    if c:
        text += ("+" if c > 0 else "−") + str(abs(c))
    return text


def interval(r1, r2, op):
    if op == "<":
        return "(%d,%d)" % (r1, r2)
    if op == "≤":
        return "[%d,%d]" % (r1, r2)
    if op == ">":
        return "(-∞,%d)∪(%d,+∞)" % (r1, r2)
    return "(-∞,%d]∪[%d,+∞)" % (r1, r2)


def frac(num, den):
    if den < 0:
        num, den = -num, -den
    g = math.gcd(abs(num), den)
    num, den = num // g, den // g
    return str(num) if den == 1 else "%d/%d" % (num, den)


def numeric_choice(rng, stem, correct, explain):
    distractors = []
    for delta in (1, -1, 2, -2, 3, -3, 4):
        value = correct + delta
        if value != correct and value not in distractors:
            distractors.append(value)
        if len(distractors) == 3:
            break
    options = [str(correct)] + [str(value) for value in distractors]
    rng.shuffle(options)
    letter = chr(65 + options.index(str(correct)))
    return {"type": "choice", "stem": stem, "options": options, "answer": letter, "explain": explain}


def fmt_number(value):
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def as_item(rng, stem, answer, explain, integer_choice=True):
    if integer_choice and isinstance(answer, int) and rng.random() < 0.2:
        return numeric_choice(rng, stem, answer, explain)
    return {"type": "fill", "stem": stem, "answer": fmt_number(answer), "explain": explain}


def gen_quadratic_inequality(rng):
    r1, r2 = sorted(rng.sample(range(-5, 7), 2))
    b = -(r1 + r2)
    c = r1 * r2
    op = rng.choice(["<", ">", "≤", "≥"])
    stem = "不等式 %s%s0 的解集是" % (quad_expr(b, c), op)
    answer = interval(r1, r2, op)

    if op in ("<", "≤"):
        side = "取两根之间"
        detail = "含端点" if op == "≤" else "不含端点"
        warning = "如果不等号换成 ≥0，就要取两根之外。"
    else:
        side = "取两根之外"
        detail = "含端点" if op == "≥" else "不含端点"
        warning = "如果不等号换成 ≤0，就要取两根之间。"
    explain = (
        "先解方程 %s=0，因式分解得 (x%+d)(x%+d)=0，两根是 %d 和 %d。\n"
        "二次项系数为正，抛物线开口向上；求 %s0，所以%s，%s。\n"
        "因此解集是 %s。\n"
        "注意：%s"
    ) % (quad_expr(b, c), -r1, -r2, r1, r2, op, side, detail, answer, warning)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_exponent(rng):
    positive = [
        (8, 2, 3, 4, 2), (16, 1, 2, 4, 4), (16, 3, 4, 8, 2), (27, 2, 3, 9, 3),
        (4, 3, 2, 8, 2), (32, 2, 5, 4, 2), (32, 3, 5, 8, 2), (81, 3, 4, 27, 3),
        (25, 1, 2, 5, 5), (25, 3, 2, 125, 5), (64, 1, 3, 4, 4), (64, 2, 3, 16, 4),
        (64, 5, 6, 32, 2), (125, 2, 3, 25, 5), (9, 3, 2, 27, 3), (36, 1, 2, 6, 6),
        (49, 1, 2, 7, 7), (100, 3, 2, 1000, 10), (16, 1, 4, 2, 2), (81, 1, 2, 9, 9),
        (27, 1, 3, 3, 3), (64, 1, 2, 8, 8), (125, 1, 3, 5, 5),
    ]
    negative = [(4, 2, 2, 2), (8, 2, 3, 2), (9, 3, 2, 3), (16, 2, 4, 2), (25, 5, 2, 5), (27, 3, 3, 3)]
    if rng.random() < 0.25:
        base, root, n, result = rng.choice(negative)
        stem = "(1/%d)^(−1/%d) 的值是" % (base, n)
        explain = (
            "负指数表示取倒数：先看 (1/%d)^(−1/%d)，它等于 %d^(1/%d)。\n"
            "%d^(1/%d) 表示 %d 的 %d 次方根，而 %d^%d=%d。\n"
            "所以结果是 %d。\n"
            "注意：负号只负责把底数翻成倒数，不会把结果变成负数。"
        ) % (base, n, base, n, base, n, base, n, root, n, base, result)
        return as_item(rng, stem, result, explain)

    base, m, n, result, root = rng.choice(positive)
    stem = "%d^(%d/%d) 的值是" % (base, m, n)
    explain = (
        "分数指数幂的分母表示开方，分子表示乘方。\n"
        "先把 %d 写成 %d^%d，于是 %d^(%d/%d)=(%d^%d)^(%d/%d)=%d^%d=%d。\n"
        "所以答案是 %d。\n"
        "注意：分母 %d 是开 %d 次方，分子 %d 才是再乘方，别写反。"
    ) % (base, root, n, base, m, n, root, n, m, n, root, m, result, result, n, n, m)
    return as_item(rng, stem, result, explain)


def gen_logarithm(rng):
    mode = rng.random()
    if mode < 0.4:
        base = rng.choice([2, 3, 4, 5, 10])
        power = rng.randint(2, 4)
        value = base ** power
        stem = "log%s%d 的值是" % (SUBSCRIPT[str(base)], value)
        explain = (
            "对数的意思是：底数要乘几次方，才能得到真数。\n"
            "也就是问“%d 的几次方等于 %d”。\n"
            "因为 %d^%d=%d，所以 log%s%d=%d。\n"
            "注意：对数算出来的是指数，不是真数。"
        ) % (base, value, base, power, value, SUBSCRIPT[str(base)], value, power)
        return as_item(rng, stem, power, explain)
    if mode < 0.7:
        pairs = [(2, 5, 1), (4, 25, 2), (5, 20, 2), (2, 50, 2), (8, 125, 3),
                 (4, 250, 3), (25, 40, 3), (10, 10, 2), (20, 5, 2)]
        a, b, answer = rng.choice(pairs)
        stem = "lg%d+lg%d 的值是" % (a, b)
        explain = (
            "同底对数相加，等于真数相乘：lg%d+lg%d=lg(%d×%d)。\n"
            "%d×%d=%d，所以原式=lg%d。\n"
            "lg 的底数是 10，而 %d=10^%d，所以 lg%d=%d。\n"
            "注意：对数相加对应真数相乘，不是真数相加。"
        ) % (a, b, a, b, a, b, a * b, a * b, a * b, answer, a * b, answer)
        return as_item(rng, stem, answer, explain)
    base = rng.choice([2, 3, 5])
    left = rng.randint(1, 3)
    right = rng.randint(1, 3)
    answer = left + right
    stem = "log%s%d+log%s%d 的值是" % (SUBSCRIPT[str(base)], base ** left, SUBSCRIPT[str(base)], base ** right)
    explain = (
        "同底对数相加，先把真数相乘：log%s%d+log%s%d=log%s(%d×%d)。\n"
        "%d×%d=%d，所以原式=log%s%d。\n"
        "因为 %d^%d=%d，所以答案是 %d。\n"
        "注意：只在底数相同时才能这样合并。"
    ) % (SUBSCRIPT[str(base)], base ** left, SUBSCRIPT[str(base)], base ** right,
         SUBSCRIPT[str(base)], base ** left, base ** right,
         base ** left, base ** right, base ** answer,
         SUBSCRIPT[str(base)], base ** answer, base, answer, base ** answer, answer)
    return as_item(rng, stem, answer, explain)


def gen_trig_identity(rng):
    opposite, adjacent, hypotenuse = rng.choice([
        (3, 4, 5), (5, 12, 13), (8, 15, 17), (7, 24, 25),
        (9, 40, 41), (11, 60, 61), (12, 35, 37), (20, 21, 29),
    ])
    quadrant = rng.randint(1, 4)
    sin_value = frac(opposite, hypotenuse)
    ask_cos = rng.random() < 0.5
    if ask_cos:
        cos_sign = 1 if quadrant in (1, 4) else -1
        answer = frac(cos_sign * adjacent, hypotenuse)
        stem = "已知 sinα=%s 且 α 在%s，则 cosα=" % (sin_value, QUADRANTS[quadrant])
        explain = (
            "先不管符号，用 sin²α+cos²α=1 算大小：\n"
            "cos²α=1−(%d/%d)²=1−%d/%d=%d/%d，所以 |cosα|=%s。\n"
            "再判断符号：α 在%s，余弦在该象限为%s，所以 cosα=%s。\n"
            "注意：只算出 4/5 这类大小还不够，必须按象限补上正负号。"
        ) % (opposite, hypotenuse, opposite ** 2, hypotenuse ** 2,
             hypotenuse ** 2 - opposite ** 2, hypotenuse ** 2,
             frac(adjacent, hypotenuse), QUADRANTS[quadrant],
             "正" if cos_sign > 0 else "负", answer)
    else:
        tan_sign = 1 if quadrant in (1, 3) else -1
        answer = frac(tan_sign * opposite, adjacent)
        stem = "已知 sinα=%s 且 α 在%s，则 tanα=" % (sin_value, QUADRANTS[quadrant])
        explain = (
            "tanα=sinα/cosα，所以先求 cosα。\n"
            "由 sin²α+cos²α=1 得 |cosα|=%s；α 在%s，余弦为%s，所以 cosα=%s。\n"
            "于是 tanα=(%s)/(%s)=%s。\n"
            "注意：tan 的符号由 sin 和 cos 同号还是异号决定。"
        ) % (frac(adjacent, hypotenuse), QUADRANTS[quadrant],
             "正" if quadrant in (1, 4) else "负",
             frac((1 if quadrant in (1, 4) else -1) * adjacent, hypotenuse),
             sin_value, frac((1 if quadrant in (1, 4) else -1) * adjacent, hypotenuse), answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_dot_product(rng):
    x1, y1, x2, y2 = [rng.randint(-5, 5) for _ in range(4)]
    answer = x1 * x2 + y1 * y2
    stem = "a=(%d,%d)，b=(%d,%d)，则 a·b=" % (x1, y1, x2, y2)
    explain = (
        "数量积的坐标公式：横坐标相乘，加上纵坐标相乘。\n"
        "代入：%d×%d+%d×%d=%d+(%d)=%d。\n"
        "所以 a·b=%d。\n"
        "注意：数量积的结果是一个数，不是向量；结果为 0 时，两向量垂直。"
    ) % (x1, x2, y1, y2, x1 * x2, y1 * y2, answer, answer)
    return as_item(rng, stem, answer, explain)


def gen_arithmetic(rng):
    a1 = rng.randint(-5, 5)
    d = rng.choice([-4, -3, -2, 2, 3, 4])
    n = rng.randint(5, 12)
    if rng.random() < 0.5:
        answer = a1 + (n - 1) * d
        stem = "等差数列 a_1=%d，d=%d，则 a_%d=" % (a1, d, n)
        explain = (
            "从第 1 项走到第 %d 项，要走 %d 步，每步加一次公差 %d。\n"
            "所以 a_%d=a_1+(n−1)d=%d+%d×(%d)=%d。\n"
            "因此 a_%d=%d。\n"
            "注意：项数差是 n−1，不是 n，第 1 项本身不用加公差。"
        ) % (n, n - 1, d, n, a1, n - 1, d, answer, n, answer)
    else:
        answer = n * (2 * a1 + (n - 1) * d) // 2
        last = a1 + (n - 1) * d
        stem = "等差数列 a_1=%d，d=%d，则 S_%d=" % (a1, d, n)
        explain = (
            "先求末项：a_%d=a_1+(n−1)d=%d+%d×(%d)=%d。\n"
            "再用求和公式 S_n=n(a_1+a_n)/2：S_%d=%d×(%d+%d)/2=%d。\n"
            "所以前 %d 项和是 %d。\n"
            "注意：求和公式里的 n 是项数，不是末项的值。"
        ) % (n, a1, n - 1, d, last, n, n, a1, last, answer, n, answer)
    return as_item(rng, stem, answer, explain)


def gen_geometric(rng):
    a1 = rng.randint(1, 4)
    q = rng.choice([2, 3, 4])
    n = rng.randint(4, 6)
    if rng.random() < 0.5:
        answer = a1 * q ** (n - 1)
        stem = "等比数列 a_1=%d，q=%d，则 a_%d=" % (a1, q, n)
        explain = (
            "从第 1 项走到第 %d 项，要乘 %d 次公比 %d。\n"
            "所以 a_%d=a_1·q^(n−1)=%d×%d^%d=%d。\n"
            "因此 a_%d=%d。\n"
            "注意：指数是 n−1，因为第 1 项本身不乘公比。"
        ) % (n, n - 1, q, n, a1, q, n - 1, answer, n, answer)
    else:
        answer = a1 * (q ** n - 1) // (q - 1)
        stem = "等比数列 a_1=%d，q=%d，则 S_%d=" % (a1, q, n)
        explain = (
            "先确认公比 q=%d≠1，可以用等比求和公式。\n"
            "S_n=a_1(q^n−1)/(q−1)=%d×(%d^%d−1)/(%d−1)。\n"
            "计算得 %d。\n"
            "所以前 %d 项和是 %d。\n"
            "注意：如果 q=1，求和公式要换成 S_n=n·a_1，不能套这个式子。"
        ) % (q, a1, q, n, q, answer, n, answer)
    return as_item(rng, stem, answer, explain)


def gen_circle(rng):
    a = rng.randint(-4, 4)
    b = rng.randint(-4, 4)
    r = rng.randint(1, 6)
    if rng.random() < 0.5:
        stem = "圆 (x%s)²+(y%s)²=%d 的圆心是" % (signed(-a), signed(-b), r * r)
        answer = "(%d,%d)" % (a, b)
        explain = (
            "圆的标准方程是 (x−a)²+(y−b)²=r²，圆心就是 (a,b)。\n"
            "题中 (x%s)² 表示 x−(%d)，所以横坐标是 %d；(y%s)² 表示 y−(%d)，所以纵坐标是 %d。\n"
            "因此圆心是 (%d,%d)。\n"
            "注意：括号里是加号时，圆心坐标要取相反数，别直接抄。"
        ) % (signed(-a), a, a, signed(-b), b, b, a, b)
        return as_item(rng, stem, answer, explain, integer_choice=False)
    stem = "圆 (x%s)²+(y%s)²=%d 的半径是" % (signed(-a), signed(-b), r * r)
    explain = (
        "标准方程右边是半径的平方 r²。\n"
        "题中右边是 %d，所以 r²=%d，开平方得 r=%d。\n"
        "因此半径是 %d。\n"
        "注意：半径取正数，不要写成 ±%d。"
    ) % (r * r, r * r, r, r, r)
    return as_item(rng, stem, r, explain)


def gen_ellipse(rng):
    a, b, c = rng.choice([
        (5, 4, 3), (13, 12, 5), (10, 8, 6), (17, 15, 8), (25, 24, 7),
        (26, 24, 10), (29, 20, 21), (37, 35, 12), (41, 40, 9), (50, 48, 14),
    ])
    ask = rng.choice(["焦距", "离心率", "长轴长", "短轴长", "c"])
    head = "椭圆 x²/%d+y²/%d=1 的" % (a * a, b * b)
    base_explain = "椭圆中 a 最大，满足 a²=b²+c²。这里 a=%d，b=%d，所以 c²=%d−%d=%d，c=%d。" % (
        a, b, a * a, b * b, c * c, c)
    if ask == "焦距":
        answer = 2 * c
        explain = base_explain + "\n焦距是 2c=%d，所以答案是 %d。\n注意：焦距是 2c，不是 c。" % (2 * c, answer)
        return as_item(rng, head + "焦距是", answer, explain)
    if ask == "离心率":
        answer = frac(c, a)
        explain = base_explain + "\n离心率 e=c/a=%d/%d=%s。\n注意：离心率是 c/a，不是 a/c。" % (c, a, answer)
        return as_item(rng, head + "离心率是", answer, explain, integer_choice=False)
    if ask == "长轴长":
        answer = 2 * a
        explain = base_explain + "\n长轴长是 2a=%d。\n注意：长轴是 2a，短轴是 2b，别混。" % (2 * a)
        return as_item(rng, head + "长轴长是", answer, explain)
    if ask == "短轴长":
        answer = 2 * b
        explain = base_explain + "\n短轴长是 2b=%d。\n注意：短轴是 2b，长轴是 2a，别混。" % (2 * b)
        return as_item(rng, head + "短轴长是", answer, explain)
    explain = base_explain + "\n所以 c=%d。\n注意：c 是半焦距，不是焦距；焦距要再乘 2。" % c
    return as_item(rng, head + "c 等于", c, explain)


def gen_extremum(rng):
    b = rng.choice([-6, -4, -2, 2, 4, 6])
    c = rng.randint(-5, 5)
    answer = c - b * b // 4
    vertex = -b // 2
    stem = "f(x)=%s 的极小值是" % quad_expr(b, c)
    explain = (
        "先求导：f'(x)=2x%+d。\n"
        "令 f'(x)=0，得 x=%d。\n"
        "二次项系数 1>0，开口向上，所以 x=%d 是极小值点。\n"
        "把 x=%d 代回原式，得极小值 %d。\n"
        "注意：不能只解 f'=0 就下结论，还要看开口方向或导数是否变号。"
    ) % (b, vertex, vertex, vertex, answer)
    return as_item(rng, stem, answer, explain)


def radian_text(angle):
    value = Fraction(angle, 180)
    num, den = value.numerator, value.denominator
    if num == 0:
        return "0"
    if den == 1:
        return "π" if num == 1 else "%dπ" % num
    return ("π/%d" % den) if num == 1 else ("%dπ/%d" % (num, den))


def gen_sampling(rng):
    total = rng.choice([400, 500, 600, 800, 1000, 1200])
    sample = rng.choice([40, 50, 60, 80, 100, 120])
    answer = frac(sample, total)
    stem = "总体 %d 人，抽取 %d 人，抽样比是" % (total, sample)
    explain = ("抽样比=样本量÷总体量。\n"
               "%d÷%d=%s（约分后）。\n"
               "所以抽样比是 %s。\n"
               "注意：分层抽样时，每一层都按同一个比例抽取。") % (
        sample, total, answer, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_histogram(rng):
    if rng.random() < 0.5:
        frequency = rng.choice([0.1, 0.15, 0.2, 0.25, 0.3, 0.4])
        width = rng.choice([2, 5, 10])
        height = frequency / width
        answer = "%g" % height
        stem = "某组频率为 %s，组距为 %d，则直方图纵轴高度是" % (frequency, width)
        explain = ("直方图纵轴表示“频率÷组距”。\n"
                   "%s÷%d=%s。\n"
                   "所以纵轴高度是 %s。\n"
                   "注意：纵轴不是频率本身，小矩形面积才是频率。") % (
            frequency, width, answer, answer)
    else:
        height = rng.choice([0.02, 0.04, 0.05, 0.08, 0.1])
        width = rng.choice([5, 10])
        frequency = height * width
        answer = "%g" % frequency
        stem = "某组纵轴高度为 %s，组距为 %d，则该组频率是" % (height, width)
        explain = ("小矩形面积=组距×纵轴高度。\n"
                   "%d×%s=%s。\n"
                   "所以该组频率是 %s。\n"
                   "注意：面积才是频率，纵轴高度不是频率。") % (
            width, height, answer, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_central_tendency(rng):
    mode = rng.choice(["mean", "median", "mode"])
    if mode == "mode":
        repeated = rng.randint(1, 9)
        others = rng.sample([x for x in range(1, 10) if x != repeated], 2)
        data = [repeated, repeated] + others
        rng.shuffle(data)
        answer = repeated
        stem = "数据 %s 的众数是" % ",".join(str(x) for x in data)
        explain = ("众数是出现次数最多的数据。\n"
                   "这组数据中 %d 出现了 2 次，其他数各出现 1 次。\n"
                   "所以众数是 %d。\n"
                   "注意：众数可能不唯一，但这组数据只有一个众数。") % (repeated, repeated)
        return as_item(rng, stem, answer, explain)
    data = sorted(rng.sample(range(1, 20), 5))
    text = ",".join(str(x) for x in data)
    if mode == "mean":
        answer = frac(sum(data), 5)
        stem = "数据 %s 的平均数是" % text
        explain = ("平均数=所有数据之和÷数据个数。\n"
                   "和=%d，个数=5，所以平均数=%s。\n"
                   "注意：平均数容易被极端值拉高或拉低。") % (sum(data), answer)
        return as_item(rng, stem, answer, explain, integer_choice=False)
    answer = data[2]
    stem = "数据 %s 的中位数是" % text
    explain = ("中位数要先把数据从小到大排列。\n"
               "这组数据已经排好，共 5 个，中间是第 3 个：%d。\n"
               "所以中位数是 %d。\n"
               "注意：数据个数为偶数时，要取中间两个数的平均。") % (answer, answer)
    return as_item(rng, stem, answer, explain)


def gen_variance(rng):
    data = [rng.randint(1, 9) for _ in range(4)]
    mean = Fraction(sum(data), 4)
    squares = sum((Fraction(x) - mean) ** 2 for x in data)
    variance = squares / 4
    answer = str(variance.numerator) if variance.denominator == 1 else "%d/%d" % (
        variance.numerator, variance.denominator)
    mean_text = str(mean.numerator) if mean.denominator == 1 else "%d/%d" % (
        mean.numerator, mean.denominator)
    text = ",".join(str(x) for x in data)
    stem = "数据 %s 的方差是" % text
    explain = ("先求平均数：(%s)÷4=%s。\n"
               "再算每个数与平均数的差的平方，求和后除以 4。\n"
               "方差=%s。\n"
               "注意：方差要先平方再平均，不能直接平均偏差。") % (
        "+".join(str(x) for x in data), mean_text, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_probability_basic(rng):
    if rng.random() < 0.6:
        probability = rng.choice([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9])
        answer = round(1 - probability, 1)
        stem = "若 P(A)=%s，则 P(Ā) 等于" % probability
        explain = ("A 与 Ā 是对立事件，二者必有一个发生。\n"
                   "所以 P(A)+P(Ā)=1。\n"
                   "P(Ā)=1−%s=%s。\n"
                   "注意：只有对立事件一定满足和为 1，互斥事件不一定。") % (
            probability, answer)
        return as_item(rng, stem, answer, explain)
    cases = [
        ("必然事件的概率是", ["1", "0", "0.5", "不确定"], "A",
         "必然事件一定发生，概率为 1。"),
        ("不可能事件的概率是", ["0", "1", "0.5", "不确定"], "A",
         "不可能事件一定不发生，概率为 0。"),
        ("随机事件的概率范围是", ["[0,1]", "(0,1)", "[0,+∞)", "R"], "A",
         "任何事件的概率都在 0 与 1 之间，包括 0 和 1。"),
    ]
    stem, options, answer, note = rng.choice(cases)
    explain = ("概率是对事件发生可能性的度量，取值在 0 到 1 之间。\n"
               "%s\n"
               "注意：概率不会小于 0，也不会大于 1。") % note
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def gen_classical(rng):
    mode = rng.choice(["dice", "balls", "numbers"])
    if mode == "dice":
        events = [
            ("出现偶数", 3, "偶数有 2、4、6，共 3 个"),
            ("出现奇数", 3, "奇数有 1、3、5，共 3 个"),
            ("出现大于 4 的数", 2, "大于 4 的有 5、6，共 2 个"),
            ("出现小于 5 的数", 4, "小于 5 的有 1、2、3、4，共 4 个"),
            ("出现质数", 3, "质数有 2、3、5，共 3 个"),
            ("出现 3 的倍数", 2, "3 的倍数有 3、6，共 2 个"),
        ]
        event, count, desc = rng.choice(events)
        answer = frac(count, 6)
        stem = "掷一枚均匀骰子，%s的概率是" % event
        explain = ("掷骰子共有 6 个等可能结果。\n"
                   "%s。\n"
                   "所以概率=%d/6=%s。\n"
                   "注意：古典概型要求每个结果等可能。") % (desc, count, answer)
        return as_item(rng, stem, answer, explain, integer_choice=False)
    if mode == "balls":
        red = rng.randint(2, 5)
        white = rng.randint(2, 5)
        total = red + white
        color = rng.choice(["红", "白"])
        count = red if color == "红" else white
        answer = frac(count, total)
        stem = "袋中有 %d 个红球、%d 个白球，任取 1 个，取到%s球的概率是" % (red, white, color)
        explain = ("袋中一共有 %d+%d=%d 个球，每个球被取到的机会相等。\n"
                   "%s球有 %d 个。\n"
                   "所以概率=%d/%d=%s。\n"
                   "注意：分母是球的总数，不是某一种颜色的数量。") % (
            red, white, total, color, count, count, total, answer)
        return as_item(rng, stem, answer, explain, integer_choice=False)
    n = rng.choice([10, 12, 15, 20])
    m = rng.choice([2, 3, 5])
    count = n // m
    answer = frac(count, n)
    stem = "从 1 到 %d 中任取一个数，取到 %d 的倍数的概率是" % (n, m)
    explain = ("1 到 %d 共有 %d 个数，每个数被取到的机会相等。\n"
               "%d 的倍数有 %d 个。\n"
               "所以概率=%d/%d=%s。\n"
               "注意：先数总个数，再数符合条件的个数。") % (
        n, n, m, count, count, n, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_independent(rng):
    left = rng.choice([0.2, 0.3, 0.4, 0.5, 0.6])
    right = rng.choice([0.3, 0.4, 0.5, 0.6, 0.7])
    if rng.random() < 0.5:
        answer = round(left * right, 2)
        stem = "A、B 相互独立，P(A)=%s，P(B)=%s，则 P(AB)=" % (left, right)
        explain = ("独立事件满足 P(AB)=P(A)P(B)。\n"
                   "%s×%s=%s。\n"
                   "注意：独立不是互斥，独立事件可以同时发生。") % (left, right, answer)
    else:
        answer = round(left + right, 2)
        stem = "A、B 互斥，P(A)=%s，P(B)=%s，则 P(A∪B)=" % (left, right)
        explain = ("互斥事件不能同时发生，P(AB)=0。\n"
                   "所以 P(A∪B)=P(A)+P(B)=%s+%s=%s。\n"
                   "注意：独立事件不能用这个加法公式。") % (left, right, answer)
    return as_item(rng, stem, answer, explain)


def gen_frequency(rng):
    if rng.random() < 0.5:
        total = rng.choice([100, 200, 500, 1000])
        count = rng.randint(10, total // 2)
        frequency = round(count / total, 2)
        stem = "某事件在 %d 次试验中发生了 %d 次，频率是" % (total, count)
        explain = ("频率=发生次数÷试验总次数。\n"
                   "%d÷%d=%s。\n"
                   "所以频率是 %s。\n"
                   "注意：频率是试验结果，会随试验次数变化。") % (
            count, total, frequency, frequency)
    else:
        frequency = rng.choice([0.42, 0.45, 0.48, 0.52, 0.55])
        stem = "某事件在大量重复试验中的频率稳定在 %s，估计其概率为" % frequency
        explain = ("大量重复试验中，频率会稳定在一个常数附近。\n"
                   "这个稳定值就是概率的估计。\n"
                   "所以估计概率为 %s。\n"
                   "注意：单次试验的频率不能直接当概率。") % frequency
    return as_item(rng, stem, frequency, explain)


def gen_space_vector(rng):
    mode = rng.choice(["dot", "add", "mod"])
    if mode == "mod":
        x, y, z, length = rng.choice([(1, 2, 2, 3), (2, 3, 6, 7), (1, 4, 8, 9), (3, 4, 12, 13), (2, 6, 9, 11)])
        x *= rng.choice([1, -1])
        y *= rng.choice([1, -1])
        z *= rng.choice([1, -1])
        stem = "向量 a=(%d,%d,%d)，则 |a|=" % (x, y, z)
        explain = ("空间向量模公式 |a|=√(x²+y²+z²)。\n"
                   "|a|=√((%d)²+(%d)²+(%d)²)=√%d=%d。\n"
                   "所以 |a|=%d。\n"
                   "注意：三个坐标都要平方，负号会被平方消掉。") % (
            x, y, z, x * x + y * y + z * z, length, length)
        return as_item(rng, stem, length, explain)
    x1, y1, z1, x2, y2, z2 = [rng.randint(-4, 4) for _ in range(6)]
    if mode == "dot":
        answer = x1 * x2 + y1 * y2 + z1 * z2
        stem = "a=(%d,%d,%d)，b=(%d,%d,%d)，则 a·b=" % (x1, y1, z1, x2, y2, z2)
        explain = ("空间向量数量积按对应坐标相乘再相加。\n"
                   "a·b=%d×%d+%d×%d+%d×%d=%d。\n"
                   "所以 a·b=%d。\n"
                   "注意：结果是一个数，不是向量。") % (
            x1, x2, y1, y2, z1, z2, answer, answer)
        return as_item(rng, stem, answer, explain)
    answer = "(%d,%d,%d)" % (x1 + x2, y1 + y2, z1 + z2)
    stem = "a=(%d,%d,%d)，b=(%d,%d,%d)，则 a+b=" % (x1, y1, z1, x2, y2, z2)
    explain = ("空间向量加法按三个坐标分别相加。\n"
               "横：%d+%d=%d；纵：%d+%d=%d；竖：%d+%d=%d。\n"
               "所以 a+b=%s。\n"
               "注意：三个分量都要算，别漏掉 z。") % (
        x1, x2, x1 + x2, y1, y2, y1 + y2, z1, z2, z1 + z2, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_space_basis(rng):
    cases = [
        ("三个向量能构成空间基底的条件是",
         ["三个向量不共面", "三个向量两两垂直", "三个向量都是单位向量", "三个向量共面"], "A",
         "空间向量基本定理：三个不共面的向量可以作基底。\n"
         "共面的三个向量只能表示同一平面内的向量。\n"
         "注意：两两垂直是常见特例，但不是必要条件。"),
        ("共面的三个向量能否构成空间基底",
         ["不能", "一定能", "与长度有关", "与方向无关"], "A",
         "空间基底要求三个向量不共面。\n"
         "共面的三个向量只能表示平面内的向量，表示不了空间所有向量。\n"
         "注意：不共面是硬条件。"),
        ("标准基 i、j、k 是否共面",
         ["不共面", "共面", "无法判断", "只共线"], "A",
         "i、j、k 分别沿 x、y、z 轴。\n"
         "它们不在同一个平面内，所以不共面。\n"
         "注意：三个不共面的向量都能作基底，不一定要两两垂直。"),
        ("两个向量能否构成空间基底",
         ["不能", "一定能", "与长度有关", "与夹角有关"], "A",
         "空间基底需要三个不共面的向量。\n"
         "两个向量最多确定一个平面，无法表示空间所有向量。\n"
         "注意：空间基底必须三个向量。"),
    ]
    stem, options, answer, explain = rng.choice(cases)
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def gen_space_angle(rng):
    cases = [
        ("两向量夹角 θ 的余弦公式是",
         ["a·b/(|a||b|)", "|a||b|/(a·b)", "a·b", "(|a|+|b|)/2"], "A",
         "两向量夹角余弦等于数量积除以两个模的乘积。\n"
         "公式：cosθ=a·b/(|a||b|)。\n"
         "注意：分母是模的乘积，不是数量积。"),
        ("线线角的取值范围是",
         ["[0,π/2]", "[0,π]", "(0,π)", "[−1,1]"], "A",
         "两条直线所成的角是锐角或直角。\n"
         "所以线线角的范围是 [0,π/2]。\n"
         "注意：异面直线所成角也在这个范围。"),
        ("二面角的取值范围是",
         ["[0,π]", "[0,π/2]", "(0,π/2)", "[−1,1]"], "A",
         "二面角可以是从 0 到 π 的任意角。\n"
         "所以范围是 [0,π]。\n"
         "注意：用向量求二面角时，要结合图形判断锐钝。"),
        ("用空间向量求线面角时，通常取",
         ["向量夹角的正弦值", "向量夹角的余弦值", "向量夹角的余切值", "向量夹角的补角"], "A",
         "线面角与直线的方向向量、平面法向量的夹角互余。\n"
         "所以常用 sinθ=|cos<a,n>| 来计算。\n"
         "注意：线面角范围是 [0,π/2]，结果取非负。"),
    ]
    stem, options, answer, explain = rng.choice(cases)
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def gen_slope(rng):
    if rng.random() < 0.5:
        x1 = rng.randint(-5, 5)
        x2 = x1 + rng.choice([-4, -3, -2, 2, 3, 4])
        y1 = rng.randint(-5, 5)
        y2 = rng.randint(-5, 5)
        answer = frac(y2 - y1, x2 - x1)
        stem = "过点 (%d,%d) 和 (%d,%d) 的直线斜率是" % (x1, y1, x2, y2)
        explain = ("斜率公式 k=(y2−y1)/(x2−x1)。\n"
                   "k=(%d−%d)/(%d−%d)=%s。\n"
                   "所以斜率是 %s。\n"
                   "注意：两点顺序要一致，都用后减前。") % (
            y2, y1, x2, x1, answer, answer)
        return as_item(rng, stem, answer, explain, integer_choice=False)
    angles = [(0, "0"), (30, "√3/3"), (45, "1"), (60, "√3"), (120, "−√3"), (135, "−1"), (150, "−√3/3")]
    angle, answer = rng.choice(angles)
    stem = "倾斜角为 %d° 的直线斜率是" % angle
    explain = ("斜率 k=tanα。\n"
               "这里 α=%d°，所以 k=tan%d°=%s。\n"
               "所以斜率是 %s。\n"
               "注意：α=90° 时 tan 不存在，斜率也不存在。") % (
        angle, angle, answer, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_line_equation(rng):
    x0 = rng.randint(-5, 5)
    y0 = rng.randint(-5, 5)
    k = rng.choice([-3, -2, -1, 2, 3])
    if rng.random() < 0.5:
        answer = "y%s=%d(x%s)" % (
            ("−%d" % y0) if y0 >= 0 else ("+%d" % (-y0)),
            k,
            ("−%d" % x0) if x0 >= 0 else ("+%d" % (-x0)))
        stem = "过点 (%d,%d)、斜率为 %d 的点斜式方程是" % (x0, y0, k)
        explain = ("点斜式 y−y0=k(x−x0)。\n"
                   "代入点 (%d,%d)、斜率 %d，得 y%s=%d(x%s)。\n"
                   "所以方程是 %s。\n"
                   "注意：括号里是 x−x0，符号别写反。") % (
            x0, y0, k,
            ("−%d" % y0) if y0 >= 0 else ("+%d" % (-y0)),
            k,
            ("−%d" % x0) if x0 >= 0 else ("+%d" % (-x0)),
            answer)
        return as_item(rng, stem, answer, explain, integer_choice=False)
    b = y0 - k * x0
    answer = "y=%dx%s%d" % (k, "+" if b >= 0 else "−", abs(b))
    stem = "斜率为 %d、过点 (%d,%d) 的斜截式方程是" % (k, x0, y0)
    explain = ("斜截式 y=kx+b。\n"
               "把点 (%d,%d) 代入：%d=%d×(%d)+b，得 b=%d。\n"
               "所以方程是 %s。\n"
               "注意：b 是纵截距，不是横截距。") % (
        x0, y0, y0, k, x0, b, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_line_relation(rng):
    if rng.random() < 0.5:
        k = rng.choice([-3, -2, 2, 3])
        b1 = rng.randint(-5, 5)
        b2 = b1 + rng.choice([-4, -3, 3, 4])
        if rng.random() < 0.5:
            stem = "直线 y=%dx%s%d 与 y=%dx%s%d 的位置关系是" % (
                k, "+" if b1 >= 0 else "−", abs(b1),
                k, "+" if b2 >= 0 else "−", abs(b2))
            answer = "平行"
            explain = ("两条直线的斜率都是 %d，斜率相等。\n"
                       "截距分别是 %d 和 %d，不相等，所以不重合。\n"
                       "因此两直线平行。\n"
                       "注意：斜率相同且截距相同才是重合。") % (k, b1, b2)
        else:
            k2 = Fraction(-1, k)
            stem = "直线 y=%dx%s%d 与斜率为 %s 的直线位置关系是" % (
                k, "+" if b1 >= 0 else "−", abs(b1), k2)
            answer = "垂直"
            explain = ("两条直线斜率乘积为 −1 时垂直。\n"
                       "%d×(%s)=−1，所以两直线垂直。\n"
                       "注意：这个判定要求两条直线斜率都存在。") % (k, k2)
        return as_item(rng, stem, answer, explain, integer_choice=False)
    x0 = rng.randint(-4, 4)
    y0 = rng.randint(-4, 4)
    offset = rng.choice([-5, -4, -3, 3, 4, 5])
    c = -(3 * x0 + 4 * y0) + 5 * offset
    answer = abs(offset)
    stem = "点 (%d,%d) 到直线 3x+4y%+d=0 的距离是" % (x0, y0, c)
    explain = ("点到直线距离 d=|Ax0+By0+C|/√(A²+B²)。\n"
               "A=3，B=4，C=%d；点 (%d,%d)。\n"
               "d=|3×%d+4×%d%+d|/√25=%d。\n"
               "所以距离是 %d。\n"
               "注意：分子要加绝对值，分母是 √(3²+4²)=5。") % (
        c, x0, y0, x0, y0, c, answer, answer)
    return as_item(rng, stem, answer, explain)


def gen_chord(rng):
    radius, distance, half = rng.choice([
        (5, 3, 4), (10, 6, 8), (13, 5, 12), (15, 9, 12), (17, 8, 15), (25, 7, 24),
    ])
    answer = 2 * half
    stem = "圆半径为 %d，圆心到直线的距离为 %d，则弦长是" % (radius, distance)
    explain = ("弦长公式：弦长=2√(r²−d²)。\n"
               "r=%d，d=%d，r²−d²=%d−%d=%d。\n"
               "弦长=2√%d=2×%d=%d。\n"
               "注意：根号里是 r²−d²，外面还要乘 2。") % (
        radius, distance, radius * radius, distance * distance,
        radius * radius - distance * distance,
        radius * radius - distance * distance, half, answer)
    return as_item(rng, stem, answer, explain)


def gen_hyperbola(rng):
    a, b, c = rng.choice([(3, 4, 5), (5, 12, 13), (6, 8, 10), (8, 15, 17), (9, 12, 15), (7, 24, 25)])
    head = "双曲线 x²/%d−y²/%d=1 的" % (a * a, b * b)
    base = ("双曲线中 c²=a²+b²。\n"
            "这里 a=%d，b=%d，c²=%d+%d=%d，c=%d。\n") % (
        a, b, a * a, b * b, c * c, c)
    mode = rng.choice(["c", "asymptote", "eccentricity"])
    if mode == "c":
        explain = base + "所以 c=%d。\n注意：双曲线是 a²+b²=c²，椭圆是 a²=b²+c²。" % c
        return as_item(rng, head + "c 等于", c, explain)
    if mode == "asymptote":
        answer = "y=±(%d/%d)x" % (b, a)
        explain = base + ("渐近线方程是 y=±(b/a)x。\n"
                          "代入 a=%d，b=%d，得 y=±(%d/%d)x。\n"
                          "注意：双曲线是 b/a，别和椭圆混。") % (a, b, b, a)
        return as_item(rng, head + "渐近线是", answer, explain, integer_choice=False)
    answer = frac(c, a)
    explain = base + ("离心率 e=c/a=%d/%d=%s。\n"
                      "注意：双曲线 e>1，椭圆 0<e<1。") % (c, a, answer)
    return as_item(rng, head + "离心率是", answer, explain, integer_choice=False)


def gen_parabola(rng):
    p = rng.choice([2, 4, 6, 8, 10, 12])
    head = "抛物线 y²=%dx 的" % (2 * p)
    base = ("抛物线 y²=2px 中，2p=%d，所以 p=%d。\n"
            "焦点是 (p/2,0)，准线是 x=−p/2。\n") % (2 * p, p)
    mode = rng.choice(["focus", "directrix", "distance"])
    if mode == "focus":
        answer = "(%d,0)" % (p // 2)
        explain = base + ("焦点横坐标是 p/2=%d。\n"
                          "所以焦点是 (%d,0)。\n"
                          "注意：焦点横坐标是 p/2，不是 p。") % (p // 2, p // 2)
        return as_item(rng, head + "焦点坐标是", answer, explain, integer_choice=False)
    if mode == "directrix":
        answer = "x=-%d" % (p // 2)
        explain = base + ("准线是 x=−p/2=−%d。\n"
                          "所以准线方程是 x=−%d。\n"
                          "注意：准线在焦点关于原点的另一侧。") % (p // 2, p // 2)
        return as_item(rng, head + "准线方程是", answer, explain, integer_choice=False)
    explain = base + ("焦点到准线的距离=p=%d。\n"
                      "注意：不是 p/2，p/2 只是焦点到原点的距离。") % p
    return as_item(rng, head + "焦点到准线的距离是", p, explain)


def gen_conic_position(rng):
    cases = [
        ("直线与椭圆相交时，交点个数最多是",
         ["2", "1", "0", "3"], "A",
         "直线与椭圆联立，会得到一个一元二次方程。\n"
         "一元二次方程最多有两个实根，所以交点最多 2 个。\n"
         "注意：相切时只有 1 个交点，相离时 0 个。"),
        ("直线与抛物线相切时，联立方程的判别式等于",
         ["0", "1", "大于 0", "小于 0"], "A",
         "相切说明联立后的方程有两个相等实根。\n"
         "两个相等实根对应判别式 Δ=0。\n"
         "注意：Δ>0 相交于两点，Δ<0 没有交点。"),
        ("直线与圆锥曲线联立后，二次项系数",
         ["可能为 0", "一定不为 0", "一定大于 0", "一定小于 0"], "A",
         "某些情况下二次项系数会消成 0，比如直线与抛物线对称轴平行。\n"
         "这时方程退化成一次方程，要单独讨论。\n"
         "注意：用判别式前先确认确实是二次方程。"),
        ("直线与圆锥曲线联立后，判别式 Δ>0 表示",
         ["有两个不同交点", "相切", "没有交点", "无法判断"], "A",
         "Δ>0 说明一元二次方程有两个不同实根。\n"
         "对应直线与圆锥曲线有两个不同交点。\n"
         "注意：Δ=0 相切，Δ<0 没有交点。"),
    ]
    stem, options, answer, explain = rng.choice(cases)
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def gen_sequence_concept(rng):
    if rng.random() < 0.5:
        p = rng.randint(1, 4)
        q = rng.randint(-3, 3)
        k = rng.randint(4, 12)
        answer = p * k + q
        expr = ("%dn" % p) if q == 0 else ("%dn%s%d" % (p, "+" if q >= 0 else "−", abs(q)))
        stem = "数列 a_n=%s，则 a_%d=" % (expr, k)
        explain = ("通项公式给出了第 n 项与序号 n 的关系。\n"
                   "把 n=%d 代入 a_n=%s，得 %d×%d%s%d=%d。\n"
                   "所以 a_%d=%d。\n"
                   "注意：n 是序号，代入时不要漏掉常数项。") % (
            k, expr, p, k, "+" if q >= 0 else "−", abs(q), answer, k, answer)
        return as_item(rng, stem, answer, explain)
    p = rng.randint(1, 4)
    q = rng.randint(-3, 3)
    terms = [p * n + q for n in range(1, 5)]
    text = ",".join(str(x) for x in terms)
    answer = ("%dn" % p) if q == 0 else ("%dn%s%d" % (p, "+" if q >= 0 else "−", abs(q)))
    stem = "数列 %s,… 的通项公式是" % text
    explain = ("观察相邻两项的差，都是 %d，说明是一次型通项。\n"
               "设 a_n=%dn+b，代入 n=1 得 %d+b=%d，所以 b=%d。\n"
               "因此通项是 %s。\n"
               "注意：代 n=1、n=2 检查，能快速确认通项。") % (
        p, p, p, terms[0], q, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_sequence_sum(rng):
    mode = rng.choice(["natural", "odd", "even"])
    n = rng.randint(5, 20)
    if mode == "natural":
        answer = n * (n + 1) // 2
        stem = "1+2+3+…+%d 等于" % n
        explain = ("这是首项 1、末项 %d、共 %d 项的等差数列。\n"
                   "S=n(首项+末项)/2=%d×(%d+1)/2=%d。\n"
                   "所以和是 %d。\n"
                   "注意：项数是 %d，不是 %d−1。") % (
            n, n, n, n, answer, answer, n, n)
        return as_item(rng, stem, answer, explain)
    if mode == "odd":
        answer = n * n
        stem = "1+3+5+…+%d 等于" % (2 * n - 1)
        explain = ("这是前 %d 个奇数的和。\n"
                   "前 n 个奇数之和等于 n²，所以和是 %d²=%d。\n"
                   "注意：项数是 (末项+1)/2=%d。") % (n, n, answer, n)
        return as_item(rng, stem, answer, explain)
    answer = n * (n + 1)
    stem = "2+4+6+…+%d 等于" % (2 * n)
    explain = ("这是首项 2、末项 %d、共 %d 项的等差数列。\n"
               "S=%d×(%d+%d)/2=%d。\n"
               "也可以提公因数 2：2×(1+2+…+%d)=2×%d=%d。\n"
               "注意：项数是 %d，不是 %d。") % (
        n * 2, n, n, n * 2, 2, answer, n, n * (n + 1) // 2, answer, n, n * 2)
    return as_item(rng, stem, answer, explain)


def gen_derivative(rng):
    mode = rng.choice(["power", "poly", "basic"])
    if mode == "power":
        n = rng.randint(2, 6)
        answer = ("%dx^%d" % (n, n - 1)) if n - 1 != 1 else ("%dx" % n)
        stem = "(x^%d)'=" % n
        explain = ("幂函数求导公式：(x^n)'=n·x^(n−1)。\n"
                   "这里 n=%d，所以 (x^%d)'=%d·x^%d。\n"
                   "所以结果是 %s。\n"
                   "注意：指数先乘到前面，再减 1。") % (n, n, n, n - 1, answer)
        return as_item(rng, stem, answer, explain, integer_choice=False)
    if mode == "poly":
        a = rng.randint(1, 4)
        b = rng.randint(-5, 5)
        c = rng.randint(-5, 5)
        answer = "%dx%s%d" % (2 * a, "+" if b >= 0 else "−", abs(b))
        stem = "(%dx²%s%dx%s%d)'=" % (
            a, "+" if b >= 0 else "−", abs(b), "+" if c >= 0 else "−", abs(c))
        explain = ("逐项求导：ax² 的导数是 2ax，bx 的导数是 b，常数的导数是 0。\n"
                   "这里 a=%d，b=%d，所以结果是 %s。\n"
                   "注意：常数项求导后消失。") % (a, b, answer)
        return as_item(rng, stem, answer, explain, integer_choice=False)
    cases = [
        ("(sinx)'", "cosx", "正弦的导数是余弦。注意：不要写成 −cosx。"),
        ("(cosx)'", "−sinx", "余弦的导数是负正弦。注意：负号不能丢。"),
        ("(e^x)'", "e^x", "自然指数函数的导数还是它本身。注意：不是 e^(x−1)。"),
        ("(lnx)'", "1/x", "自然对数的导数是 1/x。注意：定义域 x>0。"),
    ]
    stem, answer, note = rng.choice(cases)
    explain = ("%s\n"
               "所以结果是 %s。\n"
               "注意：这是基本求导公式，要记牢。") % (note, answer)
    return as_item(rng, stem + "=", answer, explain, integer_choice=False)


def gen_monotonic(rng):
    b = rng.choice([-6, -4, -2, 2, 4, 6])
    c = rng.randint(-5, 5)
    axis = -b // 2
    expr = quad_expr(b, c)
    if rng.random() < 0.5:
        answer = "(-∞,%d)" % axis
        stem = "f(x)=%s 的单调递减区间是" % expr
        explain = ("先求导：f'(x)=2x%s%d。\n"
                   "令 f'(x)<0，得 x<%d。\n"
                   "所以递减区间是 %s。\n"
                   "注意：开口向上，对称轴左侧递减，右侧递增。") % (
            "+" if b >= 0 else "−", abs(b), axis, answer)
    else:
        answer = "(%d,+∞)" % axis
        stem = "f(x)=%s 的单调递增区间是" % expr
        explain = ("先求导：f'(x)=2x%s%d。\n"
                   "令 f'(x)>0，得 x>%d。\n"
                   "所以递增区间是 %s。\n"
                   "注意：开口向上，对称轴右侧递增。") % (
            "+" if b >= 0 else "−", abs(b), axis, answer)
        return as_item(rng, stem, answer, explain, integer_choice=False)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_derivative_application(rng):
    if rng.random() < 0.5:
        perimeter = rng.choice([12, 16, 20, 24, 28, 32, 40])
        side = perimeter // 4
        answer = side * side
        stem = "周长为 %d 的矩形面积最大值是" % perimeter
        explain = ("设长 x、宽 y，则 2(x+y)=%d，x+y=%d。\n"
                   "面积 S=xy，由基本不等式，x=y 时最大。\n"
                   "所以正方形边长 %d，面积 %d。\n"
                   "注意：周长固定时，正方形面积最大。") % (
            perimeter, perimeter // 2, side, answer)
        return as_item(rng, stem, answer, explain)
    b = rng.choice([4, 6, 8, 10])
    c = rng.randint(0, 10)
    answer = c + b * b // 4
    stem = "利润函数 L(x)=−x²+%dx+%d 的最大值是" % (b, c)
    explain = ("对 L(x) 求导：L'(x)=−2x+%d。\n"
               "令 L'(x)=0，得 x=%d。\n"
               "开口向下，所以 x=%d 时取最大值，L(%d)=%d。\n"
               "注意：开口向下保证这个驻点是最大值。") % (
        b, b // 2, b // 2, b // 2, answer)
    return as_item(rng, stem, answer, explain)


def gen_counting(rng):
    if rng.random() < 0.5:
        classes = rng.randint(2, 3)
        counts = [rng.randint(2, 5) for _ in range(classes)]
        answer = sum(counts)
        desc = "、".join("%d 种" % c for c in counts)
        stem = "完成一件事有 %d 类互斥办法，分别有 %s，共有多少种办法" % (classes, desc)
        explain = ("分类加法：各类办法互不重叠，总数直接相加。\n"
                   "%s，和是 %d。\n"
                   "所以共有 %d 种办法。\n"
                   "注意：分类要“不重不漏”。") % (desc, answer, answer)
    else:
        steps = rng.randint(2, 3)
        counts = [rng.randint(2, 5) for _ in range(steps)]
        answer = 1
        for value in counts:
            answer *= value
        desc = "、".join("%d 种" % c for c in counts)
        stem = "完成一件事需要 %d 步，每步分别有 %s 选择，共有多少种方法" % (steps, desc)
        explain = ("分步乘法：每步的选择数相乘。\n"
                   "%s，乘积是 %d。\n"
                   "所以共有 %d 种方法。\n"
                   "注意：分步用乘法，分类用加法。") % (desc, answer, answer)
    return as_item(rng, stem, answer, explain)


def gen_arrangement(rng):
    n = rng.randint(4, 8)
    m = rng.randint(2, 4)
    answer = 1
    for i in range(m):
        answer *= (n - i)
    stem = "从 %d 个不同元素中取 %d 个排成一列，共有多少种排法" % (n, m)
    explain = ("排列与顺序有关，用排列数 A(n,m)。\n"
               "A(%d,%d)=%d×%d×…（共 %d 个数）=%d。\n"
               "所以共有 %d 种排法。\n"
               "注意：顺序不同算不同排法。") % (n, m, n, n - 1, m, answer, answer)
    return as_item(rng, stem, answer, explain)


def gen_combination(rng):
    n = rng.randint(5, 10)
    m = rng.randint(2, 4)
    answer = math.comb(n, m)
    stem = "从 %d 个不同元素中取 %d 个，共有多少种取法" % (n, m)
    explain = ("组合与顺序无关，用组合数 C(n,m)。\n"
               "C(%d,%d)=%d。\n"
               "所以共有 %d 种取法。\n"
               "注意：只选不排用组合；还要排队，才是排列。") % (n, m, answer, answer)
    return as_item(rng, stem, answer, explain)


def gen_binomial_theorem(rng):
    n = rng.randint(3, 6)
    a = rng.randint(1, 3)
    k = rng.randint(1, n - 1)
    power = n - k
    coefficient = math.comb(n, power) * (a ** power)
    stem = "(x+%d)^%d 展开式中 x^%d 的系数是" % (a, n, k)
    explain = ("通项 T_{r+1}=C(n,r)x^(n−r)a^r。\n"
               "要 x^%d，令 n−r=%d，得 r=%d。\n"
               "系数=C(%d,%d)×%d^%d=%d。\n"
               "注意：不要漏掉 a^r 这一部分。") % (
        k, k, power, n, power, a, power, coefficient)
    return as_item(rng, stem, coefficient, explain)


def gen_conditional(rng):
    pa = rng.choice([0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8])
    pb = rng.choice([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9])
    pab = round(pa * pb, 2)
    stem = "P(A)=%s，P(AB)=%s，则 P(B|A)=" % (pa, pab)
    explain = ("条件概率公式 P(B|A)=P(AB)/P(A)。\n"
               "%s÷%s=%s。\n"
               "所以 P(B|A)=%s。\n"
               "注意：分母是 P(A)，不是 P(B)。") % (pab, pa, pb, pb)
    return as_item(rng, stem, pb, explain)


def gen_distribution(rng):
    p0 = rng.choice([0.1, 0.2, 0.3])
    p1 = rng.choice([0.2, 0.3, 0.4, 0.5])
    p2 = round(1 - p0 - p1, 1)
    if p2 <= 0:
        p2 = 0.2
    if rng.random() < 0.5:
        expectation = round(0 * p0 + 1 * p1 + 2 * p2, 1)
        stem = "X 取 0、1、2，P(0)=%s，P(1)=%s，P(2)=%s，则 E(X)=" % (p0, p1, p2)
        explain = ("期望 E(X)=Σx_i·p_i。\n"
                   "E(X)=0×%s+1×%s+2×%s=%s。\n"
                   "所以 E(X)=%s。\n"
                   "注意：0 那一项也要写出来，虽然结果是 0。") % (
            p0, p1, p2, expectation, expectation)
        return as_item(rng, stem, expectation, explain)
    stem = "X 取 0、1、2，P(0)=%s，P(1)=%s，则 P(2)=" % (p0, p1)
    explain = ("分布列所有概率之和为 1。\n"
               "P(2)=1−P(0)−P(1)=1−%s−%s=%s。\n"
               "所以 P(2)=%s。\n"
               "注意：先确认随机变量只取 0、1、2 三个值。") % (p0, p1, p2, p2)
    return as_item(rng, stem, p2, explain)


def gen_binomial_distribution(rng):
    n = rng.randint(3, 8)
    p = rng.choice([0.2, 0.3, 0.4, 0.5, 0.6])
    if rng.random() < 0.5:
        answer = round(n * p, 2)
        stem = "X~B(%d,%s)，则 E(X)=" % (n, p)
        explain = ("二项分布 X~B(n,p) 的期望 E(X)=np。\n"
                   "n=%d，p=%s，所以 E(X)=%d×%s=%s。\n"
                   "注意：方差是 np(1−p)，别和期望混。") % (n, p, n, p, answer)
        return as_item(rng, stem, answer, explain)
    k = rng.randint(0, n)
    answer = round(math.comb(n, k) * (p ** k) * ((1 - p) ** (n - k)), 4)
    stem = "X~B(%d,%s)，则 P(X=%d)=" % (n, p, k)
    explain = ("二项分布 P(X=k)=C(n,k)p^k(1−p)^(n−k)。\n"
               "P(X=%d)=C(%d,%d)×%s^%d×%s^%d≈%s。\n"
               "注意：组合数 C(n,k) 不能漏。") % (
        k, n, k, p, k, round(1 - p, 2), n - k, answer)
    return as_item(rng, stem, answer, explain)


def gen_normal(rng):
    cases = [
        ("正态曲线关于哪条直线对称", ["x=μ", "x=0", "x=σ", "y 轴"], "A",
         "正态曲线是钟形，关于均值 μ 对称。\n"
         "所以对称轴是 x=μ。\n"
         "注意：σ 决定曲线的胖瘦，不决定对称轴。"),
        ("标准正态分布中 P(X<0) 等于", ["0.5", "0", "1", "0.68"], "A",
         "标准正态分布 μ=0，σ=1，关于 x=0 对称。\n"
         "所以 x<0 和 x>0 的概率各占一半。\n"
         "P(X<0)=0.5。\n注意：正态曲线下总面积为 1。"),
        ("正态分布中 σ 越大，曲线", ["越矮胖", "越瘦高", "越靠左", "越靠右"], "A",
         "σ 是标准差，衡量数据的分散程度。\n"
         "σ 越大，数据越分散，曲线越矮胖。\n"
         "注意：μ 决定中心位置，σ 决定胖瘦。"),
        ("正态分布的 3σ 原则是指约多少数据落在 μ±3σ 内", ["99.7%", "68.3%", "95.4%", "50%"], "A",
         "正态分布中，μ±σ 约占 68.3%，μ±2σ 约占 95.4%。\n"
         "μ±3σ 约占 99.7%，这就是 3σ 原则。\n"
         "注意：三个百分比不要记混。"),
    ]
    stem, options, answer, explain = rng.choice(cases)
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def gen_set_elements(rng):
    if rng.random() < 0.6:
        n = rng.randint(1, 10)
        answer = 2 * n + 1
        stem = "集合 {x∈Z | |x|≤%d} 的元素个数是" % n
        explain = ("|x|≤%d 表示 x 到原点的距离不超过 %d。\n"
                   "满足的整数从 −%d 到 %d，共 2×%d+1=%d 个。\n"
                   "注意：0 也是整数，别漏掉。") % (n, n, n, n, n, answer)
        return as_item(rng, stem, answer, explain)
    p = rng.choice([1, 4, 9, 16, 25, -1, -4])
    if p > 0:
        answer = 2
        note = "p>0，方程有两个不同的实根 ±√p。"
    elif p == 0:
        answer = 1
        note = "p=0，方程只有 x=0 一个实根。"
    else:
        answer = 0
        note = "p<0，实数的平方不可能为负，所以没有实根。"
    stem = "集合 {x | x²=%d} 的元素个数是" % p
    explain = ("集合的元素个数就是方程 x²=%d 的实根个数。\n"
               "%s\n"
               "所以元素个数是 %d。\n"
               "注意：先看 p 的正负，再决定根的个数。") % (p, note, answer)
    return as_item(rng, stem, answer, explain)


def gen_inequality_property(rng):
    cases = [
        ("若 a>b，则下列一定成立的是",
         ["a+c>b+c", "ac>bc", "a²>b²", "1/a<1/b"], "A",
         "两边同加同一个数 c，不等号方向不变，所以 a+c>b+c 一定成立。\n"
         "乘 c 要看 c 的正负；平方和取倒数在负数、0 附近都不一定成立。\n"
         "注意：不等式乘除含字母的式子，先判断正负。"),
        ("若 a>b，且 c<0，则下列正确的是",
         ["ac<bc", "ac>bc", "a+c<b+c", "a−c<b−c"], "A",
         "两边同乘负数 c，不等号方向要反转，所以 ac<bc。\n"
         "同加同减同一个数方向不变，所以 C、D 都错。\n"
         "注意：乘负数变号是易错点。"),
        ("若 a>b，则 −2a 与 −2b 的大小关系是",
         ["−2a<−2b", "−2a>−2b", "−2a=−2b", "无法确定"], "A",
         "由 a>b，两边同乘 −2。\n"
         "乘负数要变号，所以 −2a<−2b。\n"
         "注意：只乘正数才不变号。"),
        ("若 a<b，则 a−3 与 b−3 的大小关系是",
         ["a−3<b−3", "a−3>b−3", "a−3=b−3", "无法确定"], "A",
         "由 a<b，两边同减 3。\n"
         "同减同一个数，不等号方向不变，所以 a−3<b−3。\n"
         "注意：加减不变号，乘除负数才变号。"),
    ]
    stem, options, answer, explain = rng.choice(cases)
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def gen_same_function(rng):
    cases = [
        ("下列函数中与 y=x 是同一函数的是",
         ["y=x²/x", "y=√(x²)", "y=x（x∈R）", "y=(√x)²"], "C",
         "同一函数要求定义域和对应关系都相同。\n"
         "y=x²/x 定义域 x≠0；y=√(x²)=|x|；y=(√x)² 定义域 x≥0。\n"
         "只有 y=x（x∈R）与 y=x 完全一致。\n"
         "注意：先看定义域，再看化简后的式子。"),
        ("下列函数中与 y=|x| 是同一函数的是",
         ["y=x", "y=√(x²)", "y=(√x)²", "y=x²/x"], "B",
         "y=|x| 的定义域是 R，对应关系是取非负值。\n"
         "y=√(x²)=|x|，定义域和对应关系都相同。\n"
         "注意：y=x 在 x<0 时与 |x| 不同。"),
        ("y=x 与 y=(√x)² 是否同一函数",
         ["不是，定义域不同", "是，化简后相同", "不是，值域不同", "无法判断"], "A",
         "y=(√x)² 中根号要求 x≥0，定义域是 [0,+∞)。\n"
         "y=x 的定义域是 R。\n"
         "定义域不同，所以不是同一函数。\n"
         "注意：化简不能改变定义域。"),
    ]
    stem, options, answer, explain = rng.choice(cases)
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def gen_piecewise(rng):
    a = rng.randint(1, 3)
    b = rng.randint(-3, 3)
    c = rng.randint(-3, 3)
    x = rng.choice([-3, -2, -1, 0, 1, 2, 3])
    if x >= 0:
        answer = a * x + b
        branch = "x=%d≥0，用第一段 %dx%s%d" % (x, a, "+" if b >= 0 else "−", abs(b))
        calc = "%d×%d%s%d=%d" % (a, x, "+" if b >= 0 else "−", abs(b), answer)
    else:
        answer = x * x + c
        branch = "x=%d<0，用第二段 x²%s%d" % (x, "+" if c >= 0 else "−", abs(c))
        calc = "(%d)²%s%d=%d" % (x, "+" if c >= 0 else "−", abs(c), answer)
    stem = "f(x)=%dx%s%d(x≥0)，x²%s%d(x<0)，则 f(%d)=" % (
        a, "+" if b >= 0 else "−", abs(b), "+" if c >= 0 else "−", abs(c), x)
    explain = ("分段函数求值，先看 x 落在哪一段。\n"
               "%s。\n"
               "%s。\n"
               "所以 f(%d)=%d。\n"
               "注意：选对区间再代式子，不能两段都代。") % (branch, calc, x, answer)
    return as_item(rng, stem, answer, explain)


def gen_monotonic_basic(rng):
    if rng.random() < 0.5:
        k = rng.choice([-3, -2, -1, 1, 2, 3])
        b = rng.randint(-5, 5)
        increasing = k > 0
        options = ["增函数", "减函数", "先增后减", "不具备单调性"]
        answer = "A" if increasing else "B"
        stem = "f(x)=%dx%s%d 在 R 上是" % (k, "+" if b >= 0 else "−", abs(b))
        explain = ("一次函数的单调性只看一次项系数 k。\n"
                   "这里 k=%d，%s 0。\n"
                   "所以函数在 R 上是%s。\n"
                   "注意：k>0 递增，k<0 递减。") % (
            k, ">" if increasing else "<", "增函数" if increasing else "减函数")
        return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}
    b = rng.choice([-6, -4, -2, 2, 4, 6])
    c = rng.randint(-5, 5)
    axis = -b // 2
    expr = quad_expr(b, c)
    if rng.random() < 0.5:
        answer = "(-∞,%d)" % axis
        stem = "f(x)=%s 的单调递减区间是" % expr
        explain = ("f(x) 是开口向上的二次函数，对称轴是 x=%d。\n"
                   "对称轴左侧递减，所以递减区间是 %s。\n"
                   "注意：开口向上时，对称轴左侧递减、右侧递增。") % (axis, answer)
    else:
        answer = "(%d,+∞)" % axis
        stem = "f(x)=%s 的单调递增区间是" % expr
        explain = ("f(x) 是开口向上的二次函数，对称轴是 x=%d。\n"
                   "对称轴右侧递增，所以递增区间是 %s。\n"
                   "注意：开口向上时，对称轴右侧递增。") % (axis, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_power_function(rng):
    cases = [
        ("下列函数中是幂函数的是", ["y=2x²", "y=x^(−1)", "y=x²+1", "y=2^x"], "B",
         "幂函数必须写成 y=x^α，且系数为 1。\n"
         "y=2x² 系数是 2；y=x²+1 有常数项；y=2^x 是指数函数。\n"
         "只有 y=x^(−1) 符合。\n注意：系数不是 1 的都不是幂函数。"),
        ("幂函数 y=x³ 是", ["奇函数", "偶函数", "非奇非偶", "既奇又偶"], "A",
         "定义域 R 关于原点对称。\n"
         "f(−x)=(−x)³=−x³=−f(x)。\n"
         "所以是奇函数。\n注意：先看定义域对称，再代 f(−x)。"),
        ("幂函数 y=x² 的图象关于哪条线对称", ["y 轴", "x 轴", "原点", "直线 y=x"], "A",
         "x² 是偶函数：f(−x)=x²=f(x)。\n"
         "偶函数图象关于 y 轴对称。\n"
         "注意：奇函数才关于原点对称。"),
        ("幂函数 y=x^(−1) 的定义域是", ["x≠0", "R", "x>0", "x≥0"], "A",
         "y=x^(−1)=1/x。\n"
         "分母不能为 0，所以 x≠0。\n"
         "注意：负指数幂就是取倒数，分母不能为 0。"),
    ]
    stem, options, answer, explain = rng.choice(cases)
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def gen_zero_point(rng):
    b = rng.randint(-6, 6)
    c = rng.randint(-8, 8)
    discriminant = b * b - 4 * c
    if discriminant > 0:
        answer = 2
        note = "Δ=%d>0，方程有两个不同实根。" % discriminant
    elif discriminant == 0:
        answer = 1
        note = "Δ=0，方程有两个相等实根，只算一个零点。"
    else:
        answer = 0
        note = "Δ=%d<0，方程没有实根。" % discriminant
    stem = "f(x)=%s 的零点个数是" % quad_expr(b, c)
    explain = ("f(x) 的零点就是方程 f(x)=0 的实根。\n"
               "判别式 Δ=b²−4c=%d²−4×(%d)=%d。\n"
               "%s\n"
               "所以零点个数是 %d。\n"
               "注意：Δ>0 两个、Δ=0 一个、Δ<0 零个。") % (
        b, c, discriminant, note, answer)
    return as_item(rng, stem, answer, explain)


def gen_correlation(rng):
    cases = [
        ("相关系数 r 的取值范围是", ["[−1,1]", "[0,1]", "[−1,0]", "R"], "A",
         "相关系数衡量线性相关的强弱和方向。\n"
         "它的范围是 [−1,1]。\n"
         "注意：|r| 越接近 1，线性关系越强。"),
        ("相关系数 r=−0.9 表示两个变量", ["强负相关", "强正相关", "弱负相关", "无相关"], "A",
         "r 的符号表示方向，绝对值表示强弱。\n"
         "−0.9 接近 −1，说明是强负相关。\n"
         "注意：负号表示一个增大时另一个倾向减小。"),
        ("两个变量相关，就一定有因果关系吗", ["不一定", "一定", "完全不相关", "无法判断"], "A",
         "相关只说明两个变量有同向或反向变化趋势。\n"
         "可能存在共同影响因素，不一定是因果关系。\n"
         "注意：相关不等于因果。"),
        ("散点从左下向右上分布，说明两个变量", ["正相关", "负相关", "无相关", "非线性相关"], "A",
         "从左下到右上，说明 x 增大时 y 也倾向增大。\n"
         "这种关系叫正相关。\n"
         "注意：从左上到右下才是负相关。"),
    ]
    stem, options, answer, explain = rng.choice(cases)
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def gen_regression(rng):
    xbar = rng.randint(1, 5)
    ybar = rng.randint(3, 12)
    slope = rng.choice([1.5, 2, 2.5, 3])
    intercept = round(ybar - slope * xbar, 2)
    if rng.random() < 0.5:
        stem = "回归直线 ŷ=b̂x+â 经过样本中心 (%d,%d)，b̂=%s，则 â=" % (xbar, ybar, slope)
        explain = ("回归直线一定经过样本中心 (x̄,ȳ)。\n"
                   "代入 ȳ=%d，x̄=%d，b̂=%s：%d=%s×%d+â。\n"
                   "解得 â=%s。\n"
                   "注意：先算 b̂x̄，再移项求 â。") % (
            ybar, xbar, slope, ybar, slope, xbar, intercept)
        return as_item(rng, stem, intercept, explain)
    x = rng.randint(1, 8)
    prediction = round(slope * x + intercept, 2)
    stem = "回归直线 ŷ=%sx%s%s，当 x=%d 时 ŷ=" % (
        slope, "+" if intercept >= 0 else "−", abs(intercept), x)
    explain = ("把 x=%d 代入回归方程。\n"
               "ŷ=%s×%d%s%s=%s。\n"
               "所以预测值是 %s。\n"
               "注意：回归方程给出的是预测值，不是真实值。") % (
        x, slope, x, "+" if intercept >= 0 else "−", abs(intercept), prediction, prediction)
    return as_item(rng, stem, prediction, explain)


def gen_independence_test(rng):
    cases = [
        ("独立性检验中，χ² 越大，说明", ["两变量有关的把握越大", "两变量越无关", "样本越小", "数据越集中"], "A",
         "χ² 衡量观察数据与“无关”假设的偏离程度。\n"
         "χ² 越大，越有理由认为两个变量有关。\n"
         "注意：还要和临界值比较后才能下结论。"),
        ("独立性检验中，χ² 越小，说明两个变量的关联", ["越弱", "越强", "不变", "无法判断"], "A",
         "χ² 越小，数据越接近“两变量无关”的假设。\n"
         "所以关联越弱。\n"
         "注意：χ² 小不代表一定无关，只是证据不足。"),
        ("独立性检验的结论应该怎么说", ["有把握认为两变量有关", "两变量一定互为因果", "两变量一定无关", "样本一定有问题"], "A",
         "独立性检验只能说明“有关的把握大小”。\n"
         "不能直接说因果关系。\n"
         "注意：相关不等于因果。"),
        ("独立性检验中，χ² 需要和什么比较", ["临界值", "平均数", "方差", "样本量"], "A",
         "算出 χ² 后，要和临界值比较。\n"
         "超过临界值，才有把握认为两个变量有关。\n"
         "注意：不能只看 χ² 的绝对大小。"),
    ]
    stem, options, answer, explain = rng.choice(cases)
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def fmt_pi(value):
    num, den = value.numerator, value.denominator
    if num == 0:
        return "0"
    if den == 1:
        return "π" if num == 1 else "%dπ" % num
    return ("π/%d" % den) if num == 1 else ("%dπ/%d" % (num, den))


def gen_solid_shape(rng):
    n = rng.randint(3, 8)
    kind = rng.choice(["prism", "pyramid"])
    mode = rng.choice(["faces", "edges", "vertices"])
    if kind == "prism":
        if mode == "faces":
            answer = n + 2
            explain = ("%d 棱柱有两个底面，再加 %d 个侧面。\n"
                       "所以面数是 2+%d=%d。\n"
                       "注意：棱柱的两个底面都要算进去。") % (n, n, n, answer)
            stem = "%d 棱柱有几个面？" % n
        elif mode == "edges":
            answer = 3 * n
            explain = ("%d 棱柱的每个底面有 %d 条棱，两个底面共 %d 条。\n"
                       "再加 %d 条侧棱，总棱数是 %d+%d=%d。\n"
                       "注意：侧棱数等于底面边数 n。") % (n, n, 2 * n, n, 2 * n, n, answer)
            stem = "%d 棱柱有几条棱？" % n
        else:
            answer = 2 * n
            explain = ("%d 棱柱的上下底面各有 %d 个顶点。\n"
                       "所以顶点数是 2×%d=%d。\n"
                       "注意：侧棱上的点不算新的顶点。") % (n, n, n, answer)
            stem = "%d 棱柱有几个顶点？" % n
    else:
        if mode == "faces":
            answer = n + 1
            explain = ("%d 棱锥有 1 个底面和 %d 个侧面。\n"
                       "所以面数是 1+%d=%d。\n"
                       "注意：棱锥只有一个底面。") % (n, n, n, answer)
            stem = "%d 棱锥有几个面？" % n
        elif mode == "edges":
            answer = 2 * n
            explain = ("%d 棱锥的底面有 %d 条棱，侧面有 %d 条侧棱。\n"
                       "所以总棱数是 %d+%d=%d。\n"
                       "注意：侧棱都从同一个顶点出发。") % (n, n, n, n, n, answer)
            stem = "%d 棱锥有几条棱？" % n
        else:
            answer = n + 1
            explain = ("%d 棱锥的底面有 %d 个顶点，顶部还有 1 个顶点。\n"
                       "所以顶点数是 %d+1=%d。\n"
                       "注意：顶部顶点不属于底面。") % (n, n, n, answer)
            stem = "%d 棱锥有几个顶点？" % n
    return as_item(rng, stem, answer, explain)


def gen_solid_volume(rng):
    mode = rng.choice(["sphere_v", "sphere_s", "cylinder_v", "cone_v"])
    radius = rng.randint(1, 5)
    height = rng.randint(1, 6)
    if mode == "sphere_v":
        answer = fmt_pi(Fraction(4 * radius ** 3, 3))
        stem = "半径为 %d 的球体积是" % radius
        explain = ("球体积公式 V=4/3πR³。\n"
                   "R=%d，所以 V=4/3π×%d=%s。\n"
                   "注意：不要把直径当成半径代入。") % (radius, radius ** 3, answer)
    elif mode == "sphere_s":
        answer = fmt_pi(Fraction(4 * radius * radius, 1))
        stem = "半径为 %d 的球表面积是" % radius
        explain = ("球表面积公式 S=4πR²。\n"
                   "R=%d，所以 S=4π×%d=%s。\n"
                   "注意：表面积是 4πR²，体积是 4/3πR³，别混。") % (
            radius, radius * radius, answer)
    elif mode == "cylinder_v":
        answer = fmt_pi(Fraction(radius * radius * height, 1))
        stem = "底面半径为 %d、高为 %d 的圆柱体积是" % (radius, height)
        explain = ("圆柱体积公式 V=πr²h。\n"
                   "r=%d，h=%d，所以 V=π×%d×%d=%s。\n"
                   "注意：圆柱没有 1/3，锥体才有。") % (
            radius, height, radius * radius, height, answer)
    else:
        answer = fmt_pi(Fraction(radius * radius * height, 3))
        stem = "底面半径为 %d、高为 %d 的圆锥体积是" % (radius, height)
        explain = ("圆锥体积公式 V=1/3πr²h。\n"
                   "r=%d，h=%d，所以 V=1/3π×%d×%d=%s。\n"
                   "注意：圆锥比同底等高的圆柱少一个 1/3。") % (
            radius, height, radius * radius, height, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_solid_position(rng):
    cases = [
        ("空间中两条直线没有公共点，它们的位置关系是",
         ["平行或异面", "一定平行", "一定异面", "相交"], "A",
         "空间中两直线无公共点，可能平行，也可能异面。\n"
         "平行在同一平面内，异面不在同一平面内。\n"
         "所以选“平行或异面”。\n注意：平面内无公共点才是平行。"),
        ("直线在平面内时，直线与平面有几个公共点",
         ["无数个", "1 个", "0 个", "2 个"], "A",
         "直线在平面内，直线上的每个点都在平面内。\n"
         "直线有无数个点，所以公共点有无数个。\n"
         "注意：线面相交只有 1 个公共点，线面平行 0 个。"),
        ("两个平面没有公共点，它们的位置关系是",
         ["平行", "相交", "重合", "垂直"], "A",
         "空间中两个平面要么相交，要么平行。\n"
         "没有公共点就不会相交，所以平行。\n"
         "注意：平面是无限延伸的，不能只看画出的部分。"),
        ("两条异面直线",
         ["不同在任何一个平面内", "平行", "相交", "有公共点"], "A",
         "异面直线的定义就是不同在任何一个平面内。\n"
         "如果两条直线有公共点，就能确定一个平面，不再是异面。\n"
         "注意：异面直线一定没有公共点。"),
    ]
    stem, options, answer, explain = rng.choice(cases)
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def gen_solid_parallel(rng):
    cases = [
        ("线面平行的判定定理是",
         ["平面外一条直线与平面内一条直线平行", "平面内两条直线平行", "直线与平面垂直", "直线在平面内"], "A",
         "线面平行判定：平面外一条直线与平面内一条直线平行。\n"
         "“平面外”和“平面内一条线”两个条件缺一不可。\n"
         "注意：直线在平面内不是平行，是包含。"),
        ("面面平行的判定定理是",
         ["一个平面内两条相交直线都平行于另一个平面", "两个平面没有公共点", "一个平面内一条直线平行于另一个平面", "两个平面都垂直于第三个平面"], "A",
         "面面平行判定：一个平面内两条相交直线都平行于另一个平面。\n"
         "两条相交直线才能确定平面的方向。\n"
         "注意：两条平行直线不够，必须是相交直线。"),
        ("线面平行的性质是",
         ["线面平行，过该线的平面与原平面的交线平行于该线", "线面平行，线垂直于平面", "线面平行，线在平面内", "线面平行，线面有 1 个公共点"], "A",
         "线面平行的性质：过这条直线的平面与原平面相交，交线平行于原直线。\n"
         "所以选“交线平行于该线”。\n"
         "注意：性质说的是交线与原直线平行，不是垂直。"),
    ]
    stem, options, answer, explain = rng.choice(cases)
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def gen_solid_perpendicular(rng):
    cases = [
        ("线面垂直的判定条件是直线垂直于平面内",
         ["两条相交直线", "一条直线", "两条平行直线", "三条直线"], "A",
         "线面垂直判定：直线垂直于平面内两条相交直线。\n"
         "两条相交直线才能确定平面的方向。\n"
         "注意：只垂直一条或两条平行线都不够。"),
        ("面面垂直的判定定理是",
         ["一个平面经过另一个平面的垂线", "一个平面平行于另一个平面的垂线", "两个平面没有公共点", "两个平面都平行于第三个平面"], "A",
         "面面垂直判定：一个平面经过另一个平面的垂线。\n"
         "也就是说，一个平面里有另一个平面的垂线。\n"
         "注意：不是平行于垂线，而是经过垂线。"),
        ("线面垂直的性质是",
         ["垂直于同一平面的两条直线平行", "垂直于同一平面的两条直线垂直", "垂直于同一直线的两条直线平行", "平行于同一平面的两条直线平行"], "A",
         "线面垂直的性质：垂直于同一个平面的两条直线互相平行。\n"
         "可以想象两根都竖直插在地面上的杆子，它们方向一致。\n"
         "注意：垂直于同一直线的两条直线不一定平行。"),
    ]
    stem, options, answer, explain = rng.choice(cases)
    return {"type": "choice", "stem": stem, "options": options, "answer": answer, "explain": explain}


def fmt_complex(real, imag):
    if imag == 0:
        return str(real)
    if imag == 1:
        return ("%d+i" % real) if real else "i"
    if imag == -1:
        return ("%d-i" % real) if real else "-i"
    if real == 0:
        return "%s%di" % ("-" if imag < 0 else "", abs(imag))
    return "%d%s%di" % (real, "+" if imag > 0 else "-", abs(imag))


def gen_vector_ops(rng):
    mode = rng.choice(["add", "sub", "mod"])
    if mode == "mod":
        x, y, length = rng.choice([(3, 4, 5), (5, 12, 13), (8, 15, 17), (6, 8, 10), (9, 12, 15)])
        x *= rng.choice([1, -1])
        y *= rng.choice([1, -1])
        stem = "向量 a=(%d,%d)，则 |a|=" % (x, y)
        explain = ("向量模公式 |a|=√(x²+y²)。\n"
                   "|a|=√((%d)²+(%d)²)=√%d=%d。\n"
                   "所以 |a|=%d。\n"
                   "注意：模是非负数，坐标里的负号会被平方消掉。") % (x, y, x * x + y * y, length, length)
        return as_item(rng, stem, length, explain)
    x1, y1, x2, y2 = [rng.randint(-5, 5) for _ in range(4)]
    if mode == "add":
        answer = "(%d,%d)" % (x1 + x2, y1 + y2)
        stem = "a=(%d,%d)，b=(%d,%d)，则 a+b=" % (x1, y1, x2, y2)
        explain = ("向量加法按坐标分别相加。\n"
                   "横坐标：%d+%d=%d；纵坐标：%d+%d=%d。\n"
                   "所以 a+b=%s。\n"
                   "注意：是坐标分别相加，不是把向量长度相加。") % (
            x1, x2, x1 + x2, y1, y2, y1 + y2, answer)
    else:
        answer = "(%d,%d)" % (x1 - x2, y1 - y2)
        stem = "a=(%d,%d)，b=(%d,%d)，则 a−b=" % (x1, y1, x2, y2)
        explain = ("向量减法按坐标分别相减。\n"
                   "横坐标：%d−%d=%d；纵坐标：%d−%d=%d。\n"
                   "所以 a−b=%s。\n"
                   "注意：是 a 的坐标减 b 的坐标，顺序不能反。") % (
            x1, x2, x1 - x2, y1, y2, y1 - y2, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_cosine_law(rng):
    a = rng.randint(2, 8)
    b = rng.randint(2, 8)
    angle = rng.choice([60, 90, 120])
    if angle == 60:
        c2 = a * a + b * b - a * b
        calc = "c²=a²+b²−ab=%d+%d−%d" % (a * a, b * b, a * b)
        note = "cos60°=1/2，所以 2ab cos60° 正好等于 ab。"
    elif angle == 90:
        c2 = a * a + b * b
        calc = "c²=a²+b²=%d+%d" % (a * a, b * b)
        note = "cos90°=0，余弦定理退化成勾股定理。"
    else:
        c2 = a * a + b * b + a * b
        calc = "c²=a²+b²+ab=%d+%d+%d" % (a * a, b * b, a * b)
        note = "cos120°=−1/2，减负变加，所以是 a²+b²+ab。"
    stem = "在 △ABC 中，a=%d，b=%d，C=%d°，则 c²=" % (a, b, angle)
    explain = ("已知两边和夹角，用余弦定理 c²=a²+b²−2ab cosC。\n"
               "%s。\n"
               "所以 c²=%d。\n"
               "注意：%s") % (calc, c2, note)
    return as_item(rng, stem, c2, explain)


def gen_complex_concept(rng):
    a = rng.randint(-5, 5)
    b = rng.randint(-5, 5)
    z = fmt_complex(a, b)
    mode = rng.choice(["real", "imag", "conjugate"])
    if mode == "real":
        stem = "复数 z=%s 的实部是" % z
        explain = ("复数 z=a+bi 中，a 是实部，b 是虚部。\n"
                   "z=%s 中实部是 %d。\n"
                   "注意：实部是实数 a，不带 i。") % (z, a)
        return as_item(rng, stem, a, explain)
    if mode == "imag":
        stem = "复数 z=%s 的虚部是" % z
        explain = ("复数 z=a+bi 中，a 是实部，b 是虚部。\n"
                   "z=%s 中虚部是 %d。\n"
                   "注意：虚部是实数 b，不是 bi。") % (z, b)
        return as_item(rng, stem, b, explain)
    answer = fmt_complex(a, -b)
    stem = "复数 z=%s 的共轭复数是" % z
    explain = ("共轭复数只把虚部变号，实部不变。\n"
               "z=%s 的虚部是 %d，变号后是 %d。\n"
               "所以共轭复数是 %s。\n"
               "注意：实部保持原样，只改虚部的符号。") % (z, b, -b, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_complex_ops(rng):
    a, b, c, d = [rng.randint(-4, 4) for _ in range(4)]
    if rng.random() < 0.5:
        real = a + c
        imag = b + d
        stem = "(%s)+(%s)=" % (fmt_complex(a, b), fmt_complex(c, d))
        explain = ("复数加法：实部加实部，虚部加虚部。\n"
                   "实部 %d+%d=%d；虚部 %d+%d=%d。\n"
                   "所以结果是 %s。\n"
                   "注意：虚部要带 i，别把实部和虚部混在一起。") % (
            a, c, real, b, d, imag, fmt_complex(real, imag))
    else:
        real = a * c - b * d
        imag = a * d + b * c
        stem = "(%s)(%s)=" % (fmt_complex(a, b), fmt_complex(c, d))
        explain = ("复数乘法按多项式展开，并用 i²=−1。\n"
                   "实部=ac−bd=%d×%d−%d×%d=%d；\n"
                   "虚部=ad+bc=%d×%d+%d×%d=%d。\n"
                   "所以结果是 %s。\n"
                   "注意：i²=−1，最后一定要合并同类项。") % (
            a, c, b, d, real, a, d, b, c, imag, fmt_complex(real, imag))
    return as_item(rng, stem, fmt_complex(real, imag), explain, integer_choice=False)


def gen_complex_geo(rng):
    x, y, length = rng.choice([(3, 4, 5), (5, 12, 13), (8, 15, 17), (6, 8, 10), (9, 12, 15)])
    x *= rng.choice([1, -1])
    y *= rng.choice([1, -1])
    z = fmt_complex(x, y)
    if rng.random() < 0.5:
        stem = "复数 z=%s 的模是" % z
        explain = ("复数模公式 |z|=√(a²+b²)。\n"
                   "|%s|=√((%d)²+(%d)²)=√%d=%d。\n"
                   "所以模是 %d。\n"
                   "注意：模是非负数，坐标有负号也会被平方消掉。") % (
            z, x, y, x * x + y * y, length, length)
        return as_item(rng, stem, length, explain)
    if x > 0 and y > 0:
        quadrant = "第一象限"
    elif x < 0 and y > 0:
        quadrant = "第二象限"
    elif x < 0 and y < 0:
        quadrant = "第三象限"
    else:
        quadrant = "第四象限"
    stem = "复数 z=%s 对应的点位于" % z
    explain = ("复数 a+bi 对应复平面上的点 (a,b)。\n"
               "%s 对应点 (%d,%d)。\n"
               "横坐标%s、纵坐标%s，所以在%s。\n"
               "注意：实部是横坐标，虚部是纵坐标。") % (
        z, x, y, "正" if x > 0 else "负", "正" if y > 0 else "负", quadrant)
    return as_item(rng, stem, quadrant, explain, integer_choice=False)


def gen_angle_radian(rng):
    angle = rng.choice([30, 45, 60, 90, 120, 135, 150, 180, 210, 240, 270, 300, 330, 360])
    mode = rng.choice(["convert", "arc", "sector"])
    if mode == "convert":
        stem = "%d° 化为弧度是" % angle
        answer = radian_text(angle)
        explain = ("角度化弧度，乘 π/180。\n"
                   "%d°×π/180=%s。\n"
                   "所以答案是 %s。\n"
                   "注意：180°=π，弧度结果不带“度”字。") % (angle, answer, answer)
        return as_item(rng, stem, answer, explain, integer_choice=False)
    radius = rng.randint(1, 6)
    alpha = rng.randint(1, 4)
    if mode == "arc":
        answer = alpha * radius
        stem = "半径为 %d、圆心角为 %d rad 的弧长是" % (radius, alpha)
        explain = ("弧长公式 l=αr，其中 α 必须用弧度。\n"
                   "代入 α=%d，r=%d：l=%d×%d=%d。\n"
                   "所以弧长是 %d。\n"
                   "注意：如果 α 给的是角度，要先化成弧度。") % (
            alpha, radius, alpha, radius, answer, answer)
        return as_item(rng, stem, answer, explain)
    area = Fraction(alpha * radius * radius, 2)
    answer = str(area.numerator) if area.denominator == 1 else "%d/%d" % (area.numerator, area.denominator)
    stem = "半径为 %d、圆心角为 %d rad 的扇形面积是" % (radius, alpha)
    explain = ("扇形面积公式 S=1/2αr²。\n"
               "代入 α=%d，r=%d：S=1/2×%d×%d=%s。\n"
               "所以面积是 %s。\n"
               "注意：α 必须用弧度。") % (alpha, radius, alpha, radius * radius, answer, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_induction(rng):
    cases = [
        ("sin(π−α)", "sinα", "π−α 与 α 的终边关于 y 轴对称，正弦值相同。"),
        ("cos(π−α)", "−cosα", "π−α 在第二象限，余弦为负，函数名不变。"),
        ("sin(π+α)", "−sinα", "π+α 在第三象限，正弦为负，函数名不变。"),
        ("cos(π+α)", "−cosα", "π+α 在第三象限，余弦为负，函数名不变。"),
        ("sin(2π−α)", "−sinα", "2π−α 在第四象限，正弦为负，函数名不变。"),
        ("cos(2π−α)", "cosα", "2π−α 在第四象限，余弦为正，函数名不变。"),
        ("sin(π/2−α)", "cosα", "π/2 的奇数倍变名，正弦变余弦，第一象限为正。"),
        ("cos(π/2−α)", "sinα", "π/2 的奇数倍变名，余弦变正弦，第一象限为正。"),
        ("sin(π/2+α)", "cosα", "π/2 的奇数倍变名，第二象限正弦为正。"),
        ("cos(π/2+α)", "−sinα", "π/2 的奇数倍变名，第二象限余弦为负。"),
        ("sin(−α)", "−sinα", "正弦是奇函数。"),
        ("cos(−α)", "cosα", "余弦是偶函数。"),
    ]
    expr, answer, reason = rng.choice(cases)
    stem = "%s 化简后等于" % expr
    explain = ("%s\n"
               "所以结果是 %s。\n"
               "注意：奇变偶不变，符号看象限；先看函数名要不要变，再定正负。") % (reason, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_trig_period(rng):
    amplitude = rng.randint(1, 5)
    offset = rng.randint(-3, 3)
    omega = rng.randint(1, 4)
    if rng.random() < 0.5:
        answer = amplitude + offset
        stem = "函数 y=%dsin(%dx)%s%d 的最大值是" % (
            amplitude, omega, "+" if offset >= 0 else "−", abs(offset))
        explain = ("sin 的最大值是 1。\n"
                   "%dsin(...) 的最大值是 %d，再加 %d，得 %d。\n"
                   "所以最大值是 %d。\n"
                   "注意：最小值是 −%d+%d=%d。") % (
            amplitude, amplitude, offset, answer, answer,
            amplitude, offset, -amplitude + offset)
        return as_item(rng, stem, answer, explain)
    answer = "2π" if omega == 1 else "2π/%d" % omega
    stem = "函数 y=sin(%dx) 的最小正周期是" % omega
    explain = ("周期公式 T=2π/|ω|。\n"
               "这里 ω=%d，所以 T=%s。\n"
               "所以周期是 %s。\n"
               "注意：ω 越大，周期越短。") % (omega, answer, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_sum_difference(rng):
    special = [
        ("sin15°", "(√6−√2)/4", "45°−30°"),
        ("cos15°", "(√6+√2)/4", "45°−30°"),
        ("sin75°", "(√6+√2)/4", "45°+30°"),
        ("cos75°", "(√6−√2)/4", "45°+30°"),
        ("sin105°", "(√6+√2)/4", "60°+45°"),
        ("cos105°", "(√2−√6)/4", "60°+45°"),
        ("sin165°", "(√6−√2)/4", "180°−15°"),
        ("cos165°", "−(√6+√2)/4", "180°−15°"),
        ("sin195°", "−(√6−√2)/4", "180°+15°"),
        ("cos195°", "−(√6+√2)/4", "180°+15°"),
        ("sin255°", "−(√6+√2)/4", "180°+75°"),
        ("cos255°", "−(√6−√2)/4", "180°+75°"),
        ("sin285°", "−(√6+√2)/4", "360°−75°"),
        ("cos285°", "(√6−√2)/4", "360°−75°"),
        ("sin345°", "−(√6−√2)/4", "360°−15°"),
        ("cos345°", "(√6+√2)/4", "360°−15°"),
    ]
    expr, answer, split = rng.choice(special)
    stem = "%s 的值是" % expr
    explain = ("把角拆成两个特殊角的和或差：%s。\n"
               "用和差角公式展开，再代入 sin45°=cos45°=√2/2、sin30°=1/2、cos30°=√3/2。\n"
               "化简后得到 %s。\n"
               "注意：正弦差角和余弦和角中间都是减号，容易写反。") % (split, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_asin(rng):
    amplitude = rng.randint(1, 5)
    omega = rng.randint(1, 4)
    phase = rng.choice(["π/6", "π/4", "π/3", "π/2"])
    mode = rng.choice(["amplitude", "period", "phase"])
    head = "函数 y=%dsin(%dx+%s) 的" % (amplitude, omega, phase)
    if mode == "amplitude":
        answer = amplitude
        stem = head + "振幅是"
        explain = ("y=Asin(ωx+φ) 中，振幅是 |A|。\n"
                   "这里 A=%d，所以振幅是 |%d|=%d。\n"
                   "振幅决定图象上下拉伸的幅度，与周期、左右平移都无关。\n"
                   "注意：振幅只看 A 并取绝对值，不看 ω 和 φ。") % (
            amplitude, amplitude, amplitude)
        return as_item(rng, stem, answer, explain)
    if mode == "period":
        answer = "2π" if omega == 1 else "2π/%d" % omega
        stem = head + "最小正周期是"
        explain = ("周期公式 T=2π/|ω|。\n"
                   "这里 ω=%d，所以 T=%s。\n"
                   "周期表示图象重复一次所需要的 x 长度，ω 越大周期越短。\n"
                   "注意：φ 是左右平移，A 是上下拉伸，都不影响周期。") % (omega, answer)
        return as_item(rng, stem, answer, explain, integer_choice=False)
    stem = head + "初相是"
    answer = phase
    explain = ("y=Asin(ωx+φ) 中，φ 叫初相。\n"
               "这里括号里的常数项是 %s。\n"
               "所以初相是 %s，它决定图象左右平移的起点。\n"
               "注意：初相看括号中的常数项，不是振幅，也不是周期。") % (phase, phase)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def fmt_set(values):
    return "{" + ",".join(str(value) for value in values) + "}"


def shift_expr(var, value):
    if value == 0:
        return var
    return "%s%s%d" % (var, "+" if value > 0 else "−", abs(value))


def gen_subset_count(rng):
    n = rng.randint(3, 8)
    if rng.random() < 0.5:
        answer = 2 ** n
        stem = "集合 A 有 %d 个元素，则 A 的子集个数是" % n
        explain = ("集合有 %d 个元素。\n"
                   "每个元素都有“选入子集”或“不选”两种可能，所以子集总数是 2^%d=%d。\n"
                   "注意：这 %d 个里包含空集和 A 本身。") % (n, n, answer, answer)
    else:
        answer = 2 ** n - 1
        stem = "集合 A 有 %d 个元素，则 A 的真子集个数是" % n
        explain = ("先算子集总数：每个元素选/不选，共 2^%d=%d 个。\n"
                   "真子集不能等于 A 本身，所以去掉 1 个。\n"
                   "真子集个数=%d−1=%d。\n"
                   "注意：空集也是真子集（A 非空时）。") % (n, 2 ** n, 2 ** n, answer)
    return as_item(rng, stem, answer, explain)


def gen_set_operation(rng):
    universe = list(range(1, 11))
    left = sorted(rng.sample(universe, rng.randint(3, 5)))
    right = sorted(rng.sample(universe, rng.randint(3, 5)))
    mode = rng.choice(["intersection", "union", "complement"])
    if mode == "intersection":
        result = sorted(set(left) & set(right))
        answer = fmt_set(result) if result else "∅"
        stem = "A=%s，B=%s，则 A∩B=" % (fmt_set(left), fmt_set(right))
        explain = ("交集取两个集合都有的元素。\n"
                   "A 有 %s，B 有 %s，公共元素是 %s。\n"
                   "所以 A∩B=%s。\n"
                   "注意：只属于一个集合的元素不能写进交集。") % (
            fmt_set(left), fmt_set(right), answer, answer)
    elif mode == "union":
        result = sorted(set(left) | set(right))
        answer = fmt_set(result)
        stem = "A=%s，B=%s，则 A∪B=" % (fmt_set(left), fmt_set(right))
        explain = ("并集把两个集合的元素合在一起，并去掉重复。\n"
                   "A 有 %s，B 有 %s，合并后是 %s。\n"
                   "所以 A∪B=%s。\n"
                   "注意：重复元素只写一次。") % (
            fmt_set(left), fmt_set(right), answer, answer)
    else:
        result = sorted(set(universe) - set(left))
        answer = fmt_set(result)
        stem = "全集 U={1,2,3,4,5,6,7,8,9,10}，A=%s，则 ∁U A=" % fmt_set(left)
        explain = ("补集是全集里不属于 A 的元素。\n"
                   "从 1 到 10 中去掉 A 的 %s，剩下 %s。\n"
                   "所以 ∁U A=%s。\n"
                   "注意：补集必须对照全集来求。") % (
            fmt_set(left), answer, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_interval(rng):
    a, b = sorted(rng.sample(range(-5, 7), 2))
    left_closed = rng.random() < 0.5
    right_closed = rng.random() < 0.5
    left_symbol = "[" if left_closed else "("
    right_symbol = "]" if right_closed else ")"
    left_op = "≤" if left_closed else "<"
    right_op = "≤" if right_closed else "<"
    stem = "用区间表示集合 {x | %d%sx%s%d}" % (a, left_op, right_op, b)
    answer = "%s%d,%d%s" % (left_symbol, a, b, right_symbol)
    explain = ("集合表示 %d 到 %d 之间的数。\n"
               "左端 %d %s取到，用 %s；右端 %d %s取到，用 %s。\n"
               "所以写成 %s。\n"
               "注意：端点开闭只看能不能取到。") % (
        a, b, a, "能" if left_closed else "不能", left_symbol,
        b, "能" if right_closed else "不能", right_symbol, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_basic_inequality(rng):
    if rng.random() < 0.5:
        k = rng.choice([1, 4, 9, 16, 25, 36])
        root = int(math.isqrt(k))
        answer = 2 * root
        stem = "x>0 时，x+%d/x 的最小值是" % k
        explain = ("x>0，两项都为正，可以直接用基本不等式。\n"
                   "x+%d/x≥2√(x·%d/x)=2√%d=%d。\n"
                   "等号在 x=%d/x，即 x=%d 时取到。\n"
                   "所以最小值是 %d。\n"
                   "注意：先确认两项为正，再检查等号能否取到。") % (
            k, k, k, answer, k, root, answer)
    else:
        total = rng.choice([4, 6, 8, 10, 12])
        answer = total * total // 4
        stem = "a,b>0 且 a+b=%d，则 ab 的最大值是" % total
        explain = ("用基本不等式：ab≤((a+b)/2)²。\n"
                   "代入 a+b=%d，得 ab≤(%d/2)²=%d。\n"
                   "当且仅当 a=b=%d 时取等号。\n"
                   "所以最大值是 %d。\n"
                   "注意：和固定时积有最大值，积固定时和有最小值。") % (
            total, total, answer, total // 2, answer)
    return as_item(rng, stem, answer, explain)


def gen_domain(rng):
    a = rng.randint(-5, 5)
    kind = rng.choice(["frac", "sqrt", "frac_sqrt", "sqrt_negative"])
    inner = shift_expr("x", -a)
    if kind == "frac":
        stem = "函数 f(x)=1/(%s) 的定义域是" % inner
        answer = "x≠%d" % a
        explain = ("分母不能为 0。\n"
                   "令 %s≠0，得 x≠%d。\n"
                   "所以定义域是 x≠%d。\n"
                   "注意：定义域要写成集合或区间。") % (inner, a, a)
    elif kind == "sqrt":
        stem = "函数 f(x)=√(%s) 的定义域是" % inner
        answer = "x≥%d" % a
        explain = ("偶次根号下必须大于等于 0。\n"
                   "令 %s≥0，解得 x≥%d。\n"
                   "所以定义域是 x≥%d。\n"
                   "注意：根号在分母上时要改成大于 0。") % (inner, a, a)
    elif kind == "frac_sqrt":
        stem = "函数 f(x)=1/√(%s) 的定义域是" % inner
        answer = "x>%d" % a
        explain = ("根号在分母上，要求根号内严格大于 0。\n"
                   "令 %s>0，解得 x>%d。\n"
                   "所以定义域是 x>%d。\n"
                   "注意：分母不能为 0，不能取等号。") % (inner, a, a)
    else:
        limit = rng.randint(1, 8)
        stem = "函数 f(x)=√(%d−x) 的定义域是" % limit
        answer = "x≤%d" % limit
        explain = ("偶次根号下必须大于等于 0。\n"
                   "令 %d−x≥0，移项得 x≤%d。\n"
                   "所以定义域是 x≤%d。\n"
                   "注意：移项时不要漏掉负号。") % (limit, limit, limit)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_range(rng):
    if rng.random() < 0.5:
        k = rng.choice([2, 3, 4])
        b = rng.randint(-5, 5)
        start = rng.randint(-3, 0)
        end = start + rng.randint(1, 4)
        low = k * start + b
        high = k * end + b
        answer = "[%d,%d]" % (low, high)
        stem = "f(x)=%dx%s%d，x∈[%d,%d]，求值域" % (
            k, "+" if b >= 0 else "−", abs(b), start, end)
        explain = ("f(x)=%dx%s%d 是一次函数，斜率 %d>0，在区间上单调递增。\n"
                   "最小值在左端点：f(%d)=%d；最大值在右端点：f(%d)=%d。\n"
                   "所以值域是 %s。\n"
                   "注意：闭区间上的最值在两端取到。") % (
            k, "+" if b >= 0 else "−", abs(b), k,
            start, low, end, high, answer)
    else:
        a = rng.randint(-3, 3)
        c = rng.randint(-5, 5)
        vertex_value = c - a * a
        expr = quad_expr(-2 * a, c)
        answer = "[%d,+∞)" % vertex_value
        stem = "f(x)=%s，x∈R，求值域" % expr
        explain = ("先配方：%s=(x−(%d))²+%d。\n"
                   "平方项 (x−(%d))²≥0，所以整个式子最小为 %d。\n"
                   "因此值域是 %s。\n"
                   "注意：配方后看平方项的最小值，不要直接代端点。") % (
            expr, a, vertex_value, a, vertex_value, answer)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_parity(rng):
    n = rng.choice([2, 3, 4, 5])
    c = rng.choice([0, 0, 1, 2])
    if c == 0:
        result = "奇函数" if n % 2 == 1 else "偶函数"
    elif n % 2 == 0:
        result = "偶函数"
    else:
        result = "非奇非偶"
    expr = "x^%d" % n + ("+%d" % c if c else "")
    options = ["奇函数", "偶函数", "非奇非偶", "既奇又偶"]
    rng.shuffle(options)
    letter = chr(65 + options.index(result))
    if c == 0:
        explain = ("先看 f(−x)：f(−x)=(−x)^%d。\n"
                   "指数 %d 是%s数，所以 (−x)^%d=%s。\n"
                   "因此 f(−x)=%sf(x)，函数是%s。\n"
                   "注意：先确认定义域 R 关于原点对称。") % (
            n, n, "奇" if n % 2 else "偶", n,
            "−x^%d" % n if n % 2 else "x^%d" % n,
            "−" if result == "奇函数" else "", result)
    elif n % 2 == 0:
        explain = ("f(−x)=(−x)^%d+%d=x^%d+%d=f(x)。\n"
                   "满足 f(−x)=f(x)，所以是偶函数。\n"
                   "注意：偶函数图象关于 y 轴对称。") % (n, c, n, c)
    else:
        explain = ("f(−x)=(−x)^%d+%d=−x^%d+%d。\n"
                   "它既不等于 f(x)，也不等于 −f(x)。\n"
                   "所以是非奇非偶函数。\n"
                   "注意：奇函数要求 f(−x)=−f(x)，多一个常数项通常就被破坏。") % (n, c, n, c)
    return {"type": "choice", "stem": "f(x)=%s 是" % expr, "options": options, "answer": letter, "explain": explain}


def gen_exp_property(rng):
    mode = rng.choice(["fixed", "mono", "range"])
    if mode == "fixed":
        return {
            "type": "choice",
            "stem": "指数函数 y=a^x（a>0，a≠1）恒过定点",
            "options": ["(0,1)", "(1,0)", "(0,0)", "(1,1)"],
            "answer": "A",
            "explain": ("指数函数中令 x=0。\n"
                        "a⁰=1（a≠0），所以 y=1。\n"
                        "因此恒过点 (0,1)。\n"
                        "注意：不是 (1,0)，那是对数函数的定点。")
        }
    base = rng.choice(["2", "3", "1/2", "1/3"])
    if mode == "mono":
        increasing = base in ("2", "3")
        return {
            "type": "choice",
            "stem": "函数 y=%s^x 在 R 上" % base,
            "options": ["单调递增", "单调递减", "先增后减", "不具备单调性"],
            "answer": "A" if increasing else "B",
            "explain": ("指数函数 y=a^x 的单调性看底数 a。\n"
                        "这里 a=%s，%s。\n"
                        "所以函数在 R 上%s。\n"
                        "注意：a>1 递增，0<a<1 递减。") % (
                base, "大于 1" if increasing else "在 0 和 1 之间",
                "单调递增" if increasing else "单调递减")
        }
    return {
        "type": "choice",
        "stem": "函数 y=%s^x 的值域是" % base,
        "options": ["(0,+∞)", "[0,+∞)", "R", "(−∞,0)"],
        "answer": "A",
        "explain": ("指数函数 y=a^x 的图象都在 x 轴上方。\n"
                    "无论 x 取什么实数，a^x 都大于 0。\n"
                    "所以值域是 (0,+∞)。\n"
                    "注意：值域不包括 0，不能用方括号。")
    }


def gen_log_property(rng):
    base = rng.choice([2, 3, 5, 10])
    b = rng.randint(-5, 5)
    inner = shift_expr("x", -b)
    mode = rng.choice(["domain", "fixed"])
    if mode == "domain":
        stem = "函数 y=log%s(%s) 的定义域是" % (SUBSCRIPT[str(base)], inner)
        answer = "x>%d" % b
        explain = ("对数真数必须大于 0。\n"
                   "令 %s>0，解得 x>%d。\n"
                   "所以定义域是 x>%d。\n"
                   "注意：底数 %d 已满足大于 0 且不等于 1。") % (inner, b, b, base)
    else:
        stem = "函数 y=log%s(%s) 恒过定点" % (SUBSCRIPT[str(base)], inner)
        answer = "(%d,0)" % (b + 1)
        explain = ("对数函数 log_a(X) 在 X=1 时为 0。\n"
                   "令 %s=1，解得 x=%d。\n"
                   "所以恒过点 (%d,0)。\n"
                   "注意：对数函数的定点是 (1,0) 平移后的结果。") % (inner, b + 1, b + 1)
    return as_item(rng, stem, answer, explain, integer_choice=False)


def gen_sufficient_condition(rng):
    a, b = rng.sample(range(-3, 6), 2)
    if a > b:
        result = "充分不必要条件"
        explain = ("x>%d 的范围比 x>%d 小。\n"
                   "小范围能推出大范围，所以 x>%d 是 x>%d 的充分条件。\n"
                   "反过来大范围推不出小范围，所以不是必要条件。\n"
                   "因此是充分不必要条件。") % (a, b, a, b)
    else:
        result = "必要不充分条件"
        explain = ("x>%d 的范围比 x>%d 大。\n"
                   "大范围推不出小范围，所以不是充分条件。\n"
                   "但 x>%d 能推出 x>%d，所以是必要条件。\n"
                   "因此是必要不充分条件。") % (a, b, b, a)
    options = ["充分不必要条件", "必要不充分条件", "充要条件", "既不充分也不必要"]
    letter = chr(65 + options.index(result))
    return {
        "type": "choice",
        "stem": "“x>%d”是“x>%d”的什么条件" % (a, b),
        "options": options,
        "answer": letter,
        "explain": explain
    }


GENERATORS = {
    "K1.2": gen_subset_count,
    "K1.3": gen_set_operation,
    "K1.4": gen_interval,
    "K1.5": gen_sufficient_condition,
    "K2.2": gen_basic_inequality,
    "K2.3": gen_quadratic_inequality,
    "K3.2": gen_domain,
    "K3.3": gen_range,
    "K3.6": gen_parity,
    "K4.1": gen_exponent,
    "K4.2": gen_exp_property,
    "K4.3": gen_logarithm,
    "K4.4": gen_log_property,
    "K5.1": gen_angle_radian,
    "K5.2": gen_trig_identity,
    "K5.3": gen_induction,
    "K5.4": gen_trig_period,
    "K5.5": gen_sum_difference,
    "K5.6": gen_asin,
    "K6.1": gen_vector_ops,
    "K6.2": gen_dot_product,
    "K6.3": gen_cosine_law,
    "K7.1": gen_complex_concept,
    "K7.2": gen_complex_ops,
    "K8.1": gen_solid_shape,
    "K8.2": gen_solid_volume,
    "K8.3": gen_solid_position,
    "K8.4": gen_solid_parallel,
    "K8.5": gen_solid_perpendicular,
    "K9.1": gen_sampling,
    "K9.2": gen_histogram,
    "K9.3": gen_central_tendency,
    "K9.4": gen_variance,
    "K10.1": gen_probability_basic,
    "K10.2": gen_classical,
    "K10.3": gen_independent,
    "K10.4": gen_frequency,
    "K11.1": gen_space_vector,
    "K11.2": gen_space_basis,
    "K11.3": gen_space_angle,
    "K12.1": gen_slope,
    "K12.2": gen_line_equation,
    "K12.3": gen_line_relation,
    "K12.5": gen_chord,
    "K13.2": gen_hyperbola,
    "K13.3": gen_parabola,
    "K13.4": gen_conic_position,
    "K14.1": gen_sequence_concept,
    "K14.4": gen_sequence_sum,
    "K15.1": gen_derivative,
    "K15.2": gen_monotonic,
    "K15.4": gen_derivative_application,
    "K16.1": gen_counting,
    "K16.2": gen_arrangement,
    "K16.3": gen_combination,
    "K16.4": gen_binomial_theorem,
    "K17.1": gen_conditional,
    "K17.2": gen_distribution,
    "K17.3": gen_binomial_distribution,
    "K17.4": gen_normal,
    "K18.1": gen_correlation,
    "K18.2": gen_regression,
    "K18.3": gen_independence_test,
    "K1.1": gen_set_elements,
    "K2.1": gen_inequality_property,
    "K3.1": gen_same_function,
    "K3.4": gen_piecewise,
    "K3.5": gen_monotonic_basic,
    "K3.7": gen_power_function,
    "K4.5": gen_zero_point,
    "K7.3": gen_complex_geo,
    "K12.4": gen_circle,
    "K13.1": gen_ellipse,
    "K14.2": gen_arithmetic,
    "K14.3": gen_geometric,
    "K15.3": gen_extremum,
}


def load_known_stems():
    stems = set()
    text = open(os.path.join(BASE, "data.base.js"), encoding="utf-8").read()
    base = json.loads(text[text.index("{"):text.rindex("}") + 1])
    stems.update(item["stem"].strip() for item in base["items"])
    for path in sorted(glob.glob(os.path.join(BASE, "content", "part*.json"))):
        extra = json.load(open(path, encoding="utf-8"))
        stems.update(item["stem"].strip() for item in extra.get("items", []))
    return stems


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--per-kp", type=int, default=25, help="每个考点生成数量")
    parser.add_argument("--seed", type=int, default=20261111)
    parser.add_argument("--output", default=OUT)
    args = parser.parse_args()

    rng = random.Random(args.seed)
    items = []
    seen = set()
    known = load_known_stems()

    for kp_id, generator in GENERATORS.items():
        count = 0
        attempts = 0
        while count < args.per_kp and attempts < args.per_kp * 40:
            attempts += 1
            item = generator(rng)
            key = item["stem"]
            if key in seen or key in known:
                continue
            seen.add(key)
            item["id"] = "q_gen_%s_%03d" % (kp_id.replace(".", "_"), count + 1)
            item["kpId"] = kp_id
            item.setdefault("explain", "")
            items.append(item)
            count += 1
        if count < args.per_kp:
            print("提示：%s 生成 %d 道（参数空间已用尽）" % (kp_id, count))

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump({"items": items}, handle, ensure_ascii=False, indent=2)

    types = {}
    for item in items:
        types[item["type"]] = types.get(item["type"], 0) + 1
    avg = sum(len(item.get("explain", "")) for item in items) / max(1, len(items))
    print("已生成 %d 道题 -> %s" % (len(items), args.output))
    print("题型分布：%s；解析平均 %.0f 字" % (types, avg))


if __name__ == "__main__":
    main()