"""青柚学伴 · 综合验收

用法：
  python3 verify.py                                   # 多文件开发版
  python3 verify.py --url http://127.0.0.1:8000/      # 分包部署版
  python3 verify.py --url https://xxx --slow          # 公网隧道
"""

import argparse
import sys

from playwright.sync_api import sync_playwright

EXE = "/root/.cache/ms-playwright/chromium-1243/chrome-linux/chrome"
DEFAULT_URL = "file:///workspace/qingyou/index.html"

STATE_EMPTY = "localStorage.clear();"

results = []


def ok(name, detail=""):
    results.append((True, name))
    print("  OK  %s%s" % (name, (" — " + detail) if detail else ""))


def fail(name, detail):
    results.append((False, name))
    print("  FAIL %s: %s" % (name, detail))


def wait_bulk(page):
    """等待题库全量就绪（分包部署时生成题是异步合并的）。"""
    try:
        page.wait_for_function(
            "() => window.QY_DATA && window.QY_DATA.items && window.QY_DATA.items.length >= 1815",
            timeout=90000)
    except Exception:
        pass


def goto(page, url, slow):
    timeout = 180000 if slow else 30000
    page.goto(url, timeout=timeout, wait_until="load")
    page.wait_for_timeout(700 if slow else 350)
    wait_bulk(page)


# ---------------- 数学排版 ----------------
MATH_CASES = [
    ("分数", "f(x)=1/x，x∈[1,4]", 1, 0),
    ("区间端点分数", "值域是 [1/4,1]", 1, 0),
    ("根号", "函数 f(x)=√(2x−6) 的定义域", 0, 1),
    ("上标含分数", "8^(2/3) 的值是", 1, 0),
    ("下标", "若 a_n=2n，则 a_5 等于", 0, 0),
    ("负数上标分数", "(1/4)^(−1/2) 的值是", 2, 0),
    ("区间分数", "值域是 [1/4,1]", 1, 0),
    ("根号除式", "f(x)=√(x+1)/(x−2)", 0, 1),
    ("无分数干扰", "若 a,b>0 且 a+b=4，则 ab 的最大值是", 0, 0),
    ("纯中文", "下列函数中是幂函数的是", 0, 0),
    ("除法非分数", "把 12 个球平均分给 3 人，每人几个", 0, 0),
]


def check_math(page):
    if page.evaluate("typeof window.QY_MATH") != "function":
        fail("数学排版", "调试钩子未导出")
        return
    page.evaluate("""() => {
      const box = document.createElement('div');
      box.id = 'math-probe';
      box.style.cssText = 'position:fixed;left:-99999px;top:0';
      document.body.appendChild(box);
    }""")
    for _, text, _, _ in MATH_CASES:
        page.evaluate("""(t) => {
          const row = document.createElement('div');
          row.appendChild(window.QY_MATH(t));
          document.getElementById('math-probe').appendChild(row);
        }""", text)
    counts = page.evaluate("""() => [...document.getElementById('math-probe').children].map(r => ({
      frac: r.querySelectorAll('.math-frac').length,
      sqrt: r.querySelectorAll('.math-sqrt').length,
      sup: r.querySelectorAll('sup').length,
      sub: r.querySelectorAll('sub').length
    }))""")
    bad = []
    for (name, _, nfrac, nsqrt), row in zip(MATH_CASES, counts):
        if row["frac"] != nfrac or row["sqrt"] != nsqrt:
            bad.append("%s(分数%s/%s, 根号%s/%s)" % (name, row["frac"], nfrac, row["sqrt"], nsqrt))
    if counts[3]["sup"] != 1 or counts[3]["frac"] != 1:
        bad.append("8^(2/3) 上标内分数")
    if counts[4]["sub"] != 2:
        bad.append("a_n/a_5 下标")
    if bad:
        fail("数学排版", "; ".join(bad))
    else:
        ok("数学排版", "%d 组写法" % len(MATH_CASES))


# ---------------- 答案白名单 ----------------
ANSWER_CASES = [
    ("∅", "空集", True), ("∅", "{}", True), ("∅", "{ }", True),
    ("(1,3]", "1<x≤3", True), ("(1,3]", "3≥x>1", True),
    ("[2,+∞)", "x≥2", True), ("x>1", "(1,+∞)", True), ("x>1", "1<x", True),
    ("(-∞,3)", "x<3", True), ("{2,4}", "{4,2}", True),
    ("1/2", "0.5", True), ("-1/2", "-0.5", True),
    ("{x | x ≠ 3}", "x≠3", True), ("[2,∞)", "[2,+∞)", True),
    ("x>1", "x大于1", True),
    ("(1,3]", "[1,3]", False), ("{2,4}", "{2,4,5}", False),
    ("1/2", "0.4", False), ("x>1", "x≥1", False), ("∅", "0", False),
    ("[2,+∞)", "x>2", False), ("5", "5.1", False),
]


def check_answer(page):
    if page.evaluate("typeof window.QY_ANSWER") != "object":
        fail("答案白名单", "判定钩子未导出")
        return
    bad = []
    for answer, user, expect in ANSWER_CASES:
        got = page.evaluate("""([a, u]) => window.QY_ANSWER.correct({answer:a, type:'fill'}, u)""", [answer, user])
        if got != expect:
            bad.append("%r⇐%r→%s" % (answer, user, got))
    if not page.evaluate("""() => window.QY_ANSWER.correct({answer:'2', type:'fill', accept:['2','2.0','两']}, '2.0')"""):
        bad.append("accept 白名单未生效")
    if not page.evaluate("""() => window.QY_ANSWER.correct({answer:'AB', type:'multi'}, 'A,B')"""):
        bad.append("多选逗号")
    if bad:
        fail("答案白名单", "; ".join(bad[:4]))
    else:
        ok("答案白名单", "%d 组等价/防误伤" % (len(ANSWER_CASES) + 2))


def check_answer_data(page):
    res = page.evaluate("""() => {
      const items = window.QY_DATA.items;
      const bad = [];
      for (const it of items) {
        if (!window.QY_ANSWER.correct(it, it.answer)) bad.push(it.id);
      }
      return {total: items.length, badCount: bad.length, sample: bad.slice(0, 5)};
    }""")
    if res["badCount"]:
        fail("题库自反", "%s/%s 题用标准答案判错 %s" % (res["badCount"], res["total"], res["sample"]))
    else:
        ok("题库自反", "%d 题全部判对" % res["total"])

    res2 = page.evaluate("""() => {
      const items = window.QY_DATA.items.filter(it => ['fill','solve'].includes(it.type) && /\\d/.test(String(it.answer)));
      const sample = items.filter((_, i) => i % 5 === 0).slice(0, 300);
      const wrong = [];
      for (const it of sample) {
        const a = String(it.answer);
        const m = a.match(/^(.*?)(\\d+)(\\D*)$/);
        if (!m) continue;
        const disturbed = m[1] + String(Number(m[2]) + 7) + m[3];
        if (disturbed !== a && window.QY_ANSWER.correct(it, disturbed)) wrong.push(it.id);
      }
      return {sample: sample.length, wrongCount: wrong.length};
    }""")
    if res2["wrongCount"]:
        fail("防误判", "%s 道改数字后仍判对" % res2["wrongCount"])
    else:
        ok("防误判", "%s 道改数字全部判错" % res2["sample"])


# ---------------- 错题台 ----------------
SEED = """() => {
  const d = window.QY_DATA; const byKp = {};
  for (const it of d.items) if (['fill','choice'].includes(it.type)) (byKp[it.kpId] = byKp[it.kpId] || []).push(it);
  const kps = Object.keys(byKp).filter(k => byKp[k].length >= 2).slice(0, 3);
  const pad = n => String(n).padStart(2, '0');
  const day = o => { const t = new Date(); const x = new Date(t.getFullYear(), t.getMonth(), t.getDate() + o);
    return x.getFullYear() + '-' + pad(x.getMonth() + 1) + '-' + pad(x.getDate()); };
  const records = [], history = []; let n = 0;
  const add = (kp, item, stage, due, layer) => { n += 1; records.push({ id:'r'+n, itemId:item, kpId:kp,
    at:new Date().toISOString(), correct: stage === 'mastered', layer: layer || '', ef:2.5, interval:1,
    dueAt: due, stage: stage, reviews:1, streak:0, lastVariantId:'' }); };
  add(kps[0], byKp[kps[0]][0].id, 'new', day(-1), 'L1');
  add(kps[0], byKp[kps[0]][1].id, 'scheduled', day(2), 'L1');
  history.push({id:'h1', itemId:byKp[kps[0]][0].id, kpId:kps[0], at:new Date().toISOString(), correct:false, layer:'L1', hintUsed:false});
  history.push({id:'h2', itemId:byKp[kps[0]][1].id, kpId:kps[0], at:new Date().toISOString(), correct:false, layer:'L1', hintUsed:false});
  add(kps[1], byKp[kps[1]][0].id, 'new', day(0), 'L0');
  history.push({id:'h3', itemId:byKp[kps[1]][0].id, kpId:kps[1], at:new Date().toISOString(), correct:false, layer:'L0', hintUsed:false});
  add(kps[2], byKp[kps[2]][0].id, 'mastered', day(5), '');
  const profileList = JSON.parse(localStorage.getItem('qingyou_profiles_v1') || 'null');
  const stateKey = 'qingyou_state_v1:' + (profileList ? profileList.active : '');
  localStorage.setItem(stateKey, JSON.stringify({version:1, profile:{}, records, history}));
}"""


def check_board(page):
    page.evaluate(STATE_EMPTY)
    page.reload()
    page.wait_for_timeout(350)
    page.evaluate(SEED)
    page.reload()
    page.wait_for_timeout(500)
    wait_bulk(page)
    page.locator('.tab[data-view="board"]').click()
    page.wait_for_timeout(400)

    problems = []
    if page.locator('.kp-board-card').count() != 3:
        problems.append("聚合卡 %s != 3" % page.locator('.kp-board-card').count())
    first = page.locator('.kp-board-card').first
    if '待复习 2 道' not in first.locator('.kp-board-meta').inner_text():
        problems.append("排序不对")
    if page.locator('.kp-urgent-list li').count() != 2:
        problems.append("最该先补数量不对")
    if '方法想不到' not in first.locator('.kp-board-layer').inner_text():
        problems.append("主要错因缺失")
    if '建议' not in first.locator('.kp-board-advice').inner_text():
        problems.append("建议文案缺失")
    first.locator('button', has_text='道原题').click()
    page.wait_for_timeout(250)
    if first.locator('.board-card').count() != 2:
        problems.append("展开原题条数不对")
    first.locator('button', has_text='练 2 道').click()
    page.wait_for_timeout(500)
    if page.locator('.quiz-stem').count() != 1:
        problems.append("练 2 道未打开题目")
    page.keyboard.press('Escape')
    page.wait_for_timeout(250)
    page.locator('.board-mode-btn', has_text='按题目').click()
    page.wait_for_timeout(300)
    if page.locator('.board-column').count() != 3:
        problems.append("按题目视图列数不对")
    if page.locator('.board-card').count() != 4:
        problems.append("按题目视图卡片数不对")
    if problems:
        fail("错题台聚合", "; ".join(problems))
    else:
        ok("错题台聚合", "3 考点/排序/先补提示/错因建议/展开/练题/双视图")


# ---------------- 概念卡 / 答题 ----------------
def check_cards(page):
    page.evaluate(STATE_EMPTY)
    page.reload()
    page.wait_for_timeout(400)
    wait_bulk(page)
    page.locator('.tab[data-view="cards"]').click()
    page.wait_for_timeout(350)

    problems = []
    if page.locator('.card').count() != 76:
        problems.append("默认卡片 %s != 76" % page.locator('.card').count())

    page.locator('.card-search').click()
    for ch in ['定', '义', '域']:
        page.keyboard.type(ch)
        page.wait_for_timeout(200)
        if page.evaluate("document.activeElement && document.activeElement.id") != 'card-search':
            problems.append("实时搜索导致失焦")
            break
    page.wait_for_timeout(300)
    if page.locator('.card').count() != 5:
        problems.append("搜索命中 %s != 5" % page.locator('.card').count())
    if page.locator('.kw-hit').count() < 5:
        problems.append("关键词高亮缺失")
    if '命中 5' not in page.locator('#card-toolbar-count').inner_text():
        problems.append("命中计数不对")

    page.locator('.card-favorite').first.click()
    page.wait_for_timeout(250)
    fav_title = page.locator('.card').first.locator('.card-title').inner_text().strip()
    page.reload()
    page.wait_for_timeout(450)
    wait_bulk(page)
    page.locator('.tab[data-view="cards"]').click()
    page.wait_for_timeout(350)
    page.locator('button', has_text='只看收藏').click()
    page.wait_for_timeout(300)
    if page.locator('.card').count() != 1 or page.locator('.card-title').inner_text().strip() != fav_title:
        problems.append("收藏未持久化")

    page.locator('.card-search').fill('不存在xyz')
    page.wait_for_timeout(350)
    if page.locator('#card-results .empty-title').count() != 1:
        problems.append("空状态缺失")
    page.locator('button', has_text='清空搜索').click()
    page.wait_for_timeout(300)
    if page.locator('#card-results .empty-title').count() != 0:
        problems.append("清空搜索无效")

    page.locator('button', has_text='只看收藏').click()
    page.wait_for_timeout(300)
    page.locator('.card-summary').first.click()
    page.wait_for_timeout(250)
    page.locator('button', has_text='去练 2 道').first.click()
    page.wait_for_timeout(600)
    if page.locator('.quiz-stem').count() != 1:
        problems.append("答题弹窗未打开")
    else:
        if page.locator('.option-btn').count() > 0:
            page.locator('.option-btn').first.click()
        else:
            page.locator('#quiz-answer-input').fill('0')
        page.wait_for_timeout(150)
        page.locator('button', has_text='提交答案').click()
        page.wait_for_timeout(400)
        if page.locator('.quiz-result').count() != 1:
            problems.append("提交后无结果")
    page.keyboard.press('Escape')
    page.wait_for_timeout(200)

    if problems:
        fail("概念卡/答题", "; ".join(problems))
    else:
        ok("概念卡/答题", "全部/实时搜索/高亮/收藏/空态/答题闭环")


def check_layout(page, label):
    sw = page.evaluate("document.documentElement.scrollWidth")
    vw = page.evaluate("window.innerWidth")
    if sw > vw + 1:
        fail("%s 布局" % label, "横向溢出 %s > %s" % (sw, vw))
    else:
        ok("%s 布局" % label, "无横向溢出（%spx）" % vw)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default=DEFAULT_URL)
    parser.add_argument("--slow", action="store_true")
    args = parser.parse_args()

    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=EXE)
        page = browser.new_page(viewport={"width": 1280, "height": 950})
        page.add_init_script("window.QY_DEBUG = true;")
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        goto(page, args.url, args.slow)

        print("== 桌面 1280 ==")
        check_math(page)
        check_answer(page)
        check_answer_data(page)
        check_board(page)
        check_cards(page)
        check_layout(page, "桌面")

        mobile = browser.new_page(viewport={"width": 375, "height": 812}, is_mobile=True, has_touch=True)
        mobile.add_init_script("window.QY_DEBUG = true;")
        merrors = []
        mobile.on("pageerror", lambda e: merrors.append(str(e)))
        goto(mobile, args.url, args.slow)
        print("== 手机 375 ==")
        check_board(mobile)
        check_cards(mobile)
        check_layout(mobile, "手机")

        browser.close()

        if errors or merrors:
            fail("控制台", "桌面 %s 手机 %s" % (errors[:2], merrors[:2]))

    total = len(results)
    passed = sum(1 for flag, _ in results if flag)
    print("\n=== %s/%s 通过 ===" % (passed, total))
    sys.exit(0 if passed == total else 1)


if __name__ == "__main__":
    main()