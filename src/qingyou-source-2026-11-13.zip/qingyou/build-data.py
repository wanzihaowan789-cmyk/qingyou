#!/usr/bin/env python3
"""合并 data.base.js（原始题库）与 content/*.json（扩充分批），生成 data.js。"""

import glob
import json
import os
import re
import subprocess
import sys

from math_equiv import accept_list


def normalize_math_text(value):
    """补集符号改写为可渲染的下标形式；负号保持数据原样（审计正则依赖 ASCII）。"""
    if not isinstance(value, str):
        return value
    return value.replace("∁U", "∁_U")


TEXT_FIELDS = ("title", "oneLine", "whereFrom", "trap", "stem", "answer", "explain", "q", "a")
LIST_FIELDS = ("points", "options", "accept")


def normalize_entry(entry):
    """递归规范化所有展示文本；answers 也一起处理（判定层会再做归一化）。"""
    if isinstance(entry, list):
        return [normalize_entry(element) for element in entry]
    if isinstance(entry, dict):
        result = {}
        for key, value in entry.items():
            if key in TEXT_FIELDS and isinstance(value, str):
                result[key] = normalize_math_text(value)
            elif key in LIST_FIELDS and isinstance(value, list):
                result[key] = [normalize_math_text(v) if isinstance(v, str) else normalize_entry(v)
                               for v in value]
            elif isinstance(value, (dict, list)):
                result[key] = normalize_entry(value)
            else:
                result[key] = value
        return result
    return entry

BASE = os.path.dirname(os.path.abspath(__file__))


def read_json_object(path):
    text = open(path, encoding="utf-8").read()
    start = text.index("{")
    end = text.rindex("}")
    return json.loads(text[start:end + 1])


def main():
    data = read_json_object(os.path.join(BASE, "data.base.js"))
    data.setdefault("knowledge", [])
    data.setdefault("cards", [])
    data.setdefault("items", [])

    seen_kp = {entry["id"] for entry in data["knowledge"]}
    seen_card = {entry["id"] for entry in data["cards"]}
    seen_item = {entry["id"] for entry in data["items"]}

    for path in sorted(glob.glob(os.path.join(BASE, "content", "*.json"))):
        extra = json.load(open(path, encoding="utf-8"))
        for entry in extra.get("knowledge", []):
            if entry["id"] not in seen_kp:
                data["knowledge"].append(entry)
                seen_kp.add(entry["id"])
        for entry in extra.get("cards", []):
            if entry["id"] not in seen_card:
                data["cards"].append(entry)
                seen_card.add(entry["id"])
        for entry in extra.get("items", []):
            if entry["id"] not in seen_item:
                data["items"].append(entry)
                seen_item.add(entry["id"])

    weight_path = os.path.join(BASE, "content", "config", "weights.json")
    if os.path.exists(weight_path):
        weights = json.load(open(weight_path, encoding="utf-8"))
        for kp in data["knowledge"]:
            if kp["id"] in weights:
                kp["weight"] = weights[kp["id"]]
        print("考点权重：覆盖 %d 个考点" % len(weights))

    examples = {}
    for examples_path in sorted(glob.glob(os.path.join(BASE, "content", "examples*.json"))):
        examples.update(json.load(open(examples_path, encoding="utf-8")))
    if examples:
        for card in data["cards"]:
            if card["kpId"] in examples:
                card["example"] = examples[card["kpId"]]
        print("例题：覆盖 %d 个考点" % len(examples))

    patches = {}
    for patch_path in sorted(glob.glob(os.path.join(BASE, "content", "patches", "*.json"))):
        patches.update(json.load(open(patch_path, encoding="utf-8")))
    if patches:
        for item in data["items"]:
            if item["id"] in patches:
                item["explain"] = patches[item["id"]]
        print("解析补丁：覆盖 %d 道题" % len(patches))

    for kp in data["knowledge"]:
        human = [item for item in data["items"]
                 if item["kpId"] == kp["id"] and not item["id"].startswith("q_gen_")]
        for index, item in enumerate(human):
            # 题目自带 level 时以人工标注为准，否则沿用“前 2 道基础、其余中档”
            if item.get("type") == "solve":
                item["level"] = 2
                continue
            if item.get("level") in (1, 2):
                continue
            item["level"] = 1 if index < 2 else 2
    for item in data["items"]:
        if item["id"].startswith("q_gen_"):
            item["level"] = 1

    # 为答案生成显式等价白名单（与 app.js 判定规则同源，作为数据层兜底）
    accept_filled = 0
    for item in data["items"]:
        if item.get("type") not in ("fill", "solve") or item.get("accept"):
            continue
        extras = accept_list(item.get("answer", ""))
        if extras:
            item["accept"] = extras
            accept_filled += 1
    print("答案白名单：%d 道题补齐等价写法" % accept_filled)

    # 统一数学写法：负号用 −、补集 ∁_U（只改展示，不影响判分归一化）
    for item in data["items"]:
        item.update(normalize_entry(item))
    for card in data["cards"]:
        card.update(normalize_entry(card))

    header = "// 青柚学伴 · 内置数据（由 data.base.js + content/*.json 自动合并生成，勿手改）\n"
    header += "// 题数：%d  卡片：%d  考点：%d\n" % (
        len(data["items"]), len(data["cards"]), len(data["knowledge"]))
    body = json.dumps(data, ensure_ascii=False, indent=1)
    with open(os.path.join(BASE, "data.js"), "w", encoding="utf-8") as handle:
        handle.write(header + "window.QY_DATA = " + body + ";\n")

    print("data.js: 题数 %d / 卡片 %d / 考点 %d" % (
        len(data["items"]), len(data["cards"]), len(data["knowledge"])))

    audit_path = os.path.join(BASE, "audit-items.py")
    if os.path.exists(audit_path):
        result = subprocess.run(
            [sys.executable, audit_path, "--quiet"],
            capture_output=True, text=True)
        print(result.stdout.strip())
        if result.returncode != 0:
            print("题库审计未通过，请先修复以上问题，再打包单文件。")
            sys.exit(1)


if __name__ == "__main__":
    main()
