#!/usr/bin/env python3
"""按“权重 × 生成题占比 × 难度覆盖”排出人工重写优先级，输出 Markdown。"""

import json
import os
from collections import defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))


def load_data():
    text = open(os.path.join(BASE, "data.js"), encoding="utf-8").read()
    return json.loads(text[text.index("{"):text.rindex("}") + 1])


def main():
    data = load_data()
    kps = {k["id"]: k for k in data["knowledge"]}
    stats = defaultdict(lambda: {"total": 0, "gen": 0, "human": 0, "level2": 0,
                                 "types": defaultdict(int), "explain": []})
    for item in data["items"]:
        kp = item.get("kpId")
        if kp not in kps:
            continue
        row = stats[kp]
        row["total"] += 1
        if item["id"].startswith("q_gen_"):
            row["gen"] += 1
        else:
            row["human"] += 1
        if (item.get("level") or 1) >= 2:
            row["level2"] += 1
        row["types"][item.get("type", "fill")] += 1
        row["explain"].append(len(item.get("explain", "")))

    rows = []
    for kp_id, kp in kps.items():
        row = stats[kp_id]
        if not row["total"]:
            continue
        gen_ratio = row["gen"] / row["total"]
        weight = kp.get("weight", 0)
        type_count = len([t for t, c in row["types"].items() if c >= 2])
        avg_explain = sum(row["explain"]) / max(1, len(row["explain"]))
        # 优先级：高频 + 生成题多 + 题型单一 + 缺中档题
        score = weight * 2.0 + gen_ratio * 3.0 + (2.0 if type_count <= 2 else 0) + (1.5 if row["level2"] < 3 else 0)
        rows.append({
            "id": kp_id, "name": kp["name"], "chapter": kp.get("chapter", ""),
            "weight": weight, "total": row["total"], "gen": row["gen"], "human": row["human"],
            "gen_ratio": gen_ratio, "level2": row["level2"], "type_count": type_count,
            "avg_explain": avg_explain, "score": score,
            "types": dict(row["types"])
        })

    rows.sort(key=lambda r: -r["score"])
    lines = ["# 人工重写优先级清单", "",
             "排序依据：考点权重 × 生成题占比 × 题型单一度 × 中档题缺口。",
             "生成题是参数化变式，同一模板换数字；对 0 基础学生同质化偏高。", "",
             "| 排名 | 考点 | 权重 | 总题 | 生成题 | 占比 | 中档题 | 题型数 | 平均解析 |",
             "|---|---|---|---|---|---|---|---|---|"]
    for i, r in enumerate(rows[:20], 1):
        lines.append("| %d | %s | %d | %d | %d | %d%% | %d | %d | %d 字 |" % (
            i, r["name"], r["weight"], r["total"], r["gen"], round(r["gen_ratio"] * 100),
            r["level2"], r["type_count"], r["avg_explain"]))

    lines += ["", "## 建议做法", "",
              "1. 每个高优先级考点补 2~3 道“有具体情境”的基础题（不是换数字）",
              "2. 补 1 道中档题，让学生看到同一概念的不同问法",
              "3. 解析沿用现有风格：分步 + 一句易错提醒", ""]

    out = os.path.join(BASE, "docs", "priority-rewrite.md")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, "w", encoding="utf-8").write("\n".join(lines))
    print("\n".join(lines[:26]))
    print("\n已写入 %s" % out)


if __name__ == "__main__":
    main()
