#!/usr/bin/env python3
"""校验外部题库 JSON，避免把坏题、重复题、未知考点导入网站。

用法：python3 validate-items.py <题库.json>

支持两种格式：
  1. 直接是题目数组：[{...}, {...}]
  2. { "items": [{...}, {...}] }

校验项：必填字段、考点是否存在、题型、选项数量、答案字母范围、ID/题干重复。
退出码 0 表示全部通过，1 表示存在问题。
"""

import json
import os
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
TYPES = {"choice", "judge", "multi", "fill", "solve"}
OPTION_TYPES = {"choice", "judge", "multi"}


def load_base():
    text = open(os.path.join(BASE, "data.js"), encoding="utf-8").read()
    return json.loads(text[text.index("{"):text.rindex("}") + 1])


def main():
    if len(sys.argv) < 2:
        print("用法：python3 validate-items.py <题库.json>")
        return 1

    base = load_base()
    kp_ids = {item["id"] for item in base["knowledge"]}
    known_ids = {item["id"] for item in base["items"] if not item["id"].startswith("q_gen_")}
    known_stems = {item["stem"].strip() for item in base["items"] if not item["id"].startswith("q_gen_")}

    with open(sys.argv[1], encoding="utf-8") as handle:
        raw = json.load(handle)
    items = raw if isinstance(raw, list) else raw.get("items", [])
    if not isinstance(items, list):
        print("X 题库格式错误：应为数组或 {items:[...]}")
        return 1

    errors = []
    warnings = []
    seen_ids = set()
    seen_stems = set()
    valid = 0

    for index, item in enumerate(items, 1):
        label = "第 %d 条" % index
        if not isinstance(item, dict):
            errors.append(label + "：不是对象")
            continue

        item_id = item.get("id")
        kp_id = item.get("kpId")
        item_type = item.get("type", "fill")
        stem = item.get("stem")
        answer = item.get("answer")

        if not item_id:
            errors.append(label + "：缺少 id")
        elif item_id in known_ids:
            errors.append(label + "：id 与现有题库重复（%s）" % item_id)
        elif item_id in seen_ids:
            errors.append(label + "：本批内 id 重复（%s）" % item_id)
        else:
            seen_ids.add(item_id)

        if not kp_id:
            errors.append(label + "：缺少 kpId")
        elif kp_id not in kp_ids:
            errors.append(label + "：未知考点 %s" % kp_id)

        if item_type not in TYPES:
            errors.append(label + "：未知题型 %s" % item_type)

        if not stem:
            errors.append(label + "：缺少 stem")
        else:
            normalized = stem.strip()
            if normalized in known_stems:
                errors.append(label + "：题干与现有题目重复")
            elif normalized in seen_stems:
                errors.append(label + "：本批内题干重复")
            else:
                seen_stems.add(normalized)

        if answer is None or answer == "":
            errors.append(label + "：缺少 answer")

        if item_type in OPTION_TYPES:
            options = item.get("options")
            if not isinstance(options, list) or len(options) < 2:
                errors.append(label + "：%s 题至少需要 2 个选项" % item_type)
            elif isinstance(answer, str) and answer.isalpha():
                letters = set(answer.upper()) if item_type == "multi" else {answer.upper()}
                upper_bound = chr(ord("A") + len(options) - 1)
                for letter in letters:
                    if letter < "A" or letter > upper_bound:
                        errors.append(label + "：答案 %s 不在选项范围内" % letter)
                if item_type == "judge" and answer.upper() not in {"A", "B"}:
                    errors.append(label + "：判断题答案只能是 A 或 B")
        elif item_type == "fill" and not isinstance(answer, str):
            warnings.append(label + "：填空题 answer 建议用字符串")

        if not item.get("explain"):
            warnings.append(label + "：缺少 explain，学生看不到解析")
        elif len(item.get("explain", "")) < 40:
            warnings.append(label + "：解析较短（少于 40 字），建议补成步骤")

        if not any(message.startswith(label) for message in errors):
            valid += 1

    for message in errors:
        print("X " + message)
    for message in warnings:
        print("! " + message)

    print("---")
    print("总数 %d / 可用 %d / 错误 %d / 提醒 %d" % (
        len(items), valid, len(errors), len(warnings)))
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())