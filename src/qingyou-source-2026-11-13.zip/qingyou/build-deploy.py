#!/usr/bin/env python3
"""生成线上部署包（deploy/）：题库拆成 core + bulk，首屏只加载人工题。

  data.core.js  考点 + 概念卡 + 例题 + 337 道人工题（首屏）
  data.bulk.js  1466 道参数化生成题（load 后异步加载，静默合并）

单文件版（qingyou-standalone.html）仍由 build-standalone.py 生成，保持自包含。
"""

import gzip
import json
import os
import shutil

BASE = os.path.dirname(os.path.abspath(__file__))
DEPLOY = os.path.join(BASE, "deploy")

BULK_LOADER = """
  <script>
    /* 生成题在首屏渲染完成后再加载，避免拖慢打开速度 */
    window.addEventListener('load', function () {
      var script = document.createElement('script');
      script.src = 'data.bulk.js';
      script.async = true;
      script.onload = function () {
        if (window.QY_ABSORB_BULK) {
          window.QY_ABSORB_BULK();
        }
      };
      document.body.appendChild(script);
    });
  </script>
"""


def load_data():
    text = open(os.path.join(BASE, "data.js"), encoding="utf-8").read()
    return json.loads(text[text.index("{"):text.rindex("}") + 1])


def write_js(path, prefix, payload):
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    text = prefix + body + ";\n"
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)
    return text


def size_report(label, text):
    raw = text.encode("utf-8")
    packed = gzip.compress(raw, 6)
    print("  %-14s %7.1f KB（gzip %5.1f KB）" % (label, len(raw) / 1024.0, len(packed) / 1024.0))
    return len(raw), len(packed)


def main():
    data = load_data()
    human = [item for item in data["items"] if not item["id"].startswith("q_gen_")]
    bulk = [item for item in data["items"] if item["id"].startswith("q_gen_")]

    core = {
        "version": data.get("version", 1),
        "knowledge": data["knowledge"],
        "cards": data["cards"],
        "items": human,
    }

    os.makedirs(DEPLOY, exist_ok=True)
    core_text = write_js(os.path.join(DEPLOY, "data.core.js"), "window.QY_DATA=", core)
    bulk_text = write_js(os.path.join(DEPLOY, "data.bulk.js"), "window.QY_DATA_BULK=", bulk)
    core_size = len(core_text.encode("utf-8"))
    bulk_size = len(bulk_text.encode("utf-8"))

    for name in ("style.css", "app.js"):
        shutil.copyfile(os.path.join(BASE, name), os.path.join(DEPLOY, name))

    html = open(os.path.join(BASE, "index.html"), encoding="utf-8").read()
    if '<script src="data.js"></script>' not in html:
        raise SystemExit("index.html 里没找到 data.js 引用，拆分脚本需要更新")
    html = html.replace('<script src="data.js"></script>', '<script src="data.core.js"></script>')
    html = html.replace("data.js 与 index.html", "data.core.js 与 index.html")
    html = html.replace("</body>", BULK_LOADER + "</body>")
    with open(os.path.join(DEPLOY, "index.html"), "w", encoding="utf-8") as handle:
        handle.write(html)

    print("部署包已生成：%s" % DEPLOY)
    print("  考点 %d / 概念卡 %d / 首屏题 %d / 懒加载题 %d" % (
        len(core["knowledge"]), len(core["cards"]), len(human), len(bulk)))
    size_report("data.core.js", core_text)
    size_report("data.bulk.js", bulk_text)
    app_size = len(open(os.path.join(DEPLOY, "app.js"), "rb").read())
    css_size = len(open(os.path.join(DEPLOY, "style.css"), "rb").read())
    html_size = len(open(os.path.join(DEPLOY, "index.html"), "rb").read())
    first = app_size + css_size + html_size + core_size
    first_gz = sum(len(gzip.compress(open(os.path.join(DEPLOY, name), "rb").read(), 6))
                   for name in ("index.html", "style.css", "app.js", "data.core.js"))
    print("  首屏合计 %.1f KB（gzip %.1f KB）；生成题 %.1f KB 后台加载" % (
        first / 1024.0, first_gz / 1024.0, bulk_size / 1024.0))


if __name__ == "__main__":
    main()