#!/usr/bin/env python3
"""带 gzip 与缓存的静态服务，用于公网隧道前的本地托管。"""

import gzip
import http.server
import os
import socketserver
import sys

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
ROOT = sys.argv[2] if len(sys.argv) > 2 else "/workspace/qingyou/deploy"
COMPRESSIBLE = (".html", ".js", ".css", ".json", ".svg", ".txt")


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def do_GET(self):
        if self.path in ("/", ""):
            self.path = "/index.html"
        path = self.translate_path(self.path)
        accepts_gzip = "gzip" in self.headers.get("Accept-Encoding", "")
        if (accepts_gzip and os.path.isfile(path)
                and path.lower().endswith(COMPRESSIBLE)):
            try:
                with open(path, "rb") as handle:
                    payload = handle.read()
                body = gzip.compress(payload, 6)
                self.send_response(200)
                self.send_header("Content-Type", self.guess_type(path))
                self.send_header("Content-Encoding", "gzip")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "public, max-age=600")
                self.send_header("Vary", "Accept-Encoding")
                self.end_headers()
                self.wfile.write(body)
                return
            except OSError:
                pass
        super().do_GET()

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    with Server(("0.0.0.0", PORT), Handler) as httpd:
        httpd.serve_forever()