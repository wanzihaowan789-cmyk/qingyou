﻿# 青柚学伴 · 本地预览（带 gzip 的静态服务）
# 用法：powershell -ExecutionPolicy Bypass -File .\serve.ps1
#       powershell -ExecutionPolicy Bypass -File .\serve.ps1 -Port 9000
param([int]$Port = 8123)

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

if (-not (Test-Path (Join-Path $PSScriptRoot 'deploy\index.html'))) {
    Write-Host '缺少 deploy/index.html，先跑一次 build.ps1' -ForegroundColor Yellow
    exit 1
}

Write-Host "预览地址：http://127.0.0.1:$Port/" -ForegroundColor Green
Write-Host '按 Ctrl+C 停止' -ForegroundColor DarkGray
python serve.py $Port (Join-Path $PSScriptRoot 'deploy')