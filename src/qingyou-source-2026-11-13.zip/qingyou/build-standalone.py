#!/usr/bin/env python3
"""把 index.html + style.css + data.js + app.js 合并成单文件 qingyou-standalone.html。

用法：python3 build-standalone.py
修改源码（style.css / data.js / app.js / index.html）后运行一次即可。
"""

import os

BASE = os.path.dirname(os.path.abspath(__file__))


def read(name):
    with open(os.path.join(BASE, name), encoding="utf-8") as handle:
        return handle.read()


def main():
    html = read("index.html")
    css = read("style.css")
    data = read("data.js")
    app = read("app.js")

    for chunk, name in ((css, "style.css"), (data, "data.js"), (app, "app.js")):
        lowered = chunk.lower()
        if "</style" in lowered or "</script" in lowered:
            raise SystemExit("%s 中含有结束标签，不能直接内联" % name)

    html = html.replace(
        '<link rel="stylesheet" href="style.css">',
        "<style>\n" + css + "\n  </style>",
    )
    html = html.replace(
        '<script src="data.js"></script>\n  <script src="app.js"></script>',
        "<script>\n" + data + "\n  </script>\n  <script>\n" + app + "\n  </script>",
    )

    banner = "<!-- 青柚学伴 · 单文件版（由 index.html + style.css + data.js + app.js 合并生成，双击即用） -->\n"
    html = banner + html

    out = os.path.join(BASE, "qingyou-standalone.html")
    with open(out, "w", encoding="utf-8") as handle:
        handle.write(html)
    print("已生成 %s（%d 字节）" % (out, len(html.encode("utf-8"))))


if __name__ == "__main__":
    main()